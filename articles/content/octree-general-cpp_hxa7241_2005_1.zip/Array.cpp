/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "Array.hpp"
