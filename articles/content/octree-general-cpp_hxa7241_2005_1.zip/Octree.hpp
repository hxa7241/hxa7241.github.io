/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Octree_h
#define Octree_h


#include "OctreeAuxiliary.hpp"
#include "OctreeImplementation.hpp"
#include <iosfwd>




#include "hxa7241_graphics.hpp"
namespace hxa7241_graphics
{
	using hxa7241_graphics::Vector3f;


/**
 * visitor abstract base, for client use with Octree.<br/><br/>
 *
 * client of Octree must define a concrete derivative of
 * OctreeVisitorT<ItemType>.<br/><br/>
 *
 * this is an extension of the Visitor pattern with two roles: first to act as an
 * intermediary for an octree to query its typeless subject items when inserting or
 * removing. second (more conventionally), to read tree nodes and items when
 * visiting.<br/><br/>
 *
 * the ___V methods simply apply a type cast to void*s and forward to their
 * abstract counterparts.<br/><br/>
 *
 * the overlap methods are to determine an items relation to a cell or cells, for
 * insertion or removal. the visit methods are to read tree nodes for the visit
 * operation.<br/><br/>
 *
 * return value of getSubcellOverlaps is 8 bits, each bit is a bool
 * corresponding to a subcell, the high bit for subcell 7, the low bit for
 * subcell 0.<br/><br/>
 *
 * subcell numbering:
 * <pre>
 * 		y z           110 111
 * 		|/   010 011  100 101
 * 		 -x  000 001
 * </pre>
 *
 * @implementation
 * an octree requires its contained items to provide positional info. but
 * requiring the item classes to implement an OctreeItem interface would
 * impose a direct interface change on every prospective item type, and enlarge
 * their instances with a vptr.<br/><br/>
 *
 * instead, this visitor transfers the octree related interface/implementation
 * away from the item type into a separate class. the octree can now hold void
 * pointers to items and call the visitor to supply info about them.<br/><br/>
 *
 * the second purpose of the visitor is the conventional one of defining an
 * externalised operation on the main data structure, except that the octree is
 * constant and the visitor is the object modified.
 *
 * a plausible refactoring would be to separate this into two classes: one for the
 * overlap interface, one for the visit interface.
 */
template<class TYPE>
class OctreeVisitorT
	: public OctreeVisitor
{
/// standard object services -----------------------------------------------------------------------
protected:
	         OctreeVisitorT() {}
public:
	virtual ~OctreeVisitorT() {}
private:
	         OctreeVisitorT( const OctreeVisitorT& );
	OctreeVisitorT& operator=( const OctreeVisitorT& );


/// void-to-type forwarders
public:
/// commands ---------------------------------------------------------------------------------------
	virtual void  visitRootV  ( const OctreeCell* pRootCell,
	                            const OctreeData& octreeData );
	virtual void  visitBranchV( const OctreeCell* subCells[8],
	                            const OctreeData& octreeData );
	virtual void  visitLeafV  ( const Array<const void*>& items,
	                            const OctreeData&         octreeData );


/// queries ----------------------------------------------------------------------------------------
	virtual bool  isOverlappingCellV ( const void*     pItem,
	                                   const Vector3f& lowerCorner,
	                                   const Vector3f& upperCorner )                       const;
	virtual dword getSubcellOverlapsV( const void*     pItem,
	                                   const Vector3f& lower,
	                                   const Vector3f& middle,
	                                   const Vector3f& upper )                             const;


/// abstract interface
protected:
/// commands ---------------------------------------------------------------------------------------
	virtual void  visitRoot  ( const OctreeCell* pRootCell,
	                           const OctreeData& octreeData )                                    =0;
	virtual void  visitBranch( const OctreeCell* subCells[8],
	                           const OctreeData& octreeData )                                    =0;
	virtual void  visitLeaf  ( const Array<const TYPE*>& items,
	                           const OctreeData&         octreeData )                            =0;


/// queries ----------------------------------------------------------------------------------------
	virtual bool  isOverlappingCell ( const TYPE&     item,
	                                  const Vector3f& lowerCorner,
	                                  const Vector3f& upperCorner )                        const =0;
	virtual dword getSubcellOverlaps( const TYPE&     item,
	                                  const Vector3f& lower,
	                                  const Vector3f& middle,
	                                  const Vector3f& upper )                              const =0;
};




/// void-to-type forwarders
template<class TYPE>
inline
void OctreeVisitorT<TYPE>::visitRootV
(
	const OctreeCell* pRootCell,
	const OctreeData& octreeData
)
{
	visitRoot( pRootCell, octreeData );
}


template<class TYPE>
inline
void OctreeVisitorT<TYPE>::visitBranchV
(
	const OctreeCell* subCells[8],
	const OctreeData& octreeData
)
{
	visitBranch( subCells, octreeData );
}


template<class TYPE>
inline
void OctreeVisitorT<TYPE>::visitLeafV
(
	const Array<const void*>& items,
	const OctreeData&         octreeData
)
{
	visitLeaf( reinterpret_cast<const Array<const TYPE*>&>( items ), octreeData );
}


template<class TYPE>
inline
bool OctreeVisitorT<TYPE>::isOverlappingCellV
(
	const void*     pItem,
	const Vector3f& lowerCorner,
	const Vector3f& upperCorner
) const
{
	bool is = false;

	if( pItem != 0 )
	{
		is = isOverlappingCell( *reinterpret_cast<const TYPE*>( pItem ), lowerCorner, upperCorner );
	}

	return is;
}


template<class TYPE>
inline
dword OctreeVisitorT<TYPE>::getSubcellOverlapsV
(
	const void*     pItem,
	const Vector3f& lower,
	const Vector3f& middle,
	const Vector3f& upper
) const
{
	dword ov = ALL_OUTSIDE;

	if( pItem != 0 )
	{
		ov = getSubcellOverlaps( *reinterpret_cast<const TYPE*>( pItem ), lower, middle, upper );
	}

	return ov;
}








/**
 * octree based spatial index.<br/><br/>
 *
 * client must define a concrete derivative of OctreeVisitorT<ItemType>.
 * <br/><br/>
 *
 * maxElementCountPerCell is ignored where maxLevelCount is reached.<br/><br/>
 *
 * the octree is cubical and axis aligned, partitions are axis aligned,
 * partitions divide in half, each level partitions the previous level in all
 * three axiss.<br/><br/>
 *
 * storage is contracted (partially) as well as expanded as needed by item
 * insertion and removal.<br/><br/>
 *
 * (occupies, very approximately, 20 bytes per point item. maybe...)
 *
 * @see OctreeVisitorT
 *
 * @implementation
 * the octree structure follows the Composite pattern.<br/><br/>
 *
 * this template wrapper ensures the items indexed by the octree and the visitors
 * used when accessing them are of matching types. all algorithmic work is
 * delegated to OctreeRoot and OctreeCell derivatives in OctreeImplementation,
 * which work with abstract base interfaces and void pointers.<br/><br/>
 *
 * the visitor usage is an extension of the Visitor pattern. rather than
 * performing an operation on an Octree instance, the visitors do two different
 * things: for the insertion and removal commands, the (const) visitor provides an
 * interface for the octree to query the typeless item, and for the visitItems
 * query, the (non const) visitor provides callbacks to read tree nodes for
 * carrying out the visit operation.
 */
template<class TYPE>
class Octree
{
/// standard object services -----------------------------------------------------------------------
public:
	         Octree( const Vector3f& positionOfLowerCorner,
	                 float           sizeOfCube,
	                 dword           maxElementCountPerCell,
	                 dword           maxLevelCount );

	virtual ~Octree();
	         Octree( const Octree& );
	Octree& operator=( const Octree& );


/// commands ---------------------------------------------------------------------------------------
	virtual bool  insertItem( const TYPE&                 item,
	                          const OctreeVisitorT<TYPE>& visitor );
	virtual bool  removeItem( const TYPE&                 item,
	                          const OctreeVisitorT<TYPE>& visitor );


/// queries ----------------------------------------------------------------------------------------
	virtual void  visitItems( OctreeVisitorT<TYPE>& visitor )                                 const;

	virtual bool  isEmpty()                                                                   const;
	virtual void  getInfo( dword& byteSize,
	                       dword& leafCount,
	                       dword& elementCount,
	                       dword& maxDepth )                                                  const;
	virtual std::ostream& streamOut( std::ostream& )                                          const;

	virtual const Vector3f& getPosition()                                                     const;
	virtual float           getSize()                                                         const;
	virtual dword           getMaxElementCountPerCell()                                       const;
	virtual dword           getMaxLevelCount()                                                const;


/// fields -----------------------------------------------------------------------------------------
private:
	OctreeRoot root_m;
};




/// test ///
void test_Octree();




/// streaming ///
template<class TYPE>
inline
std::ostream& operator<<( std::ostream& out, const Octree<TYPE>& obj )
{
	return obj.streamOut( out );
}




/// templates ///

/// standard object services -----------------------------------------------------------------------
template<class TYPE>
inline
Octree<TYPE>::Octree
(
	const Vector3f& position,
	const float     sizeOfCube,
	const dword     maxElementCountPerCell,
	const dword     maxLevelCount
)
 :	root_m( position, sizeOfCube, maxElementCountPerCell, maxLevelCount )
{
}


template<class TYPE>
inline
Octree<TYPE>::~Octree()
{
}


template<class TYPE>
inline
Octree<TYPE>::Octree
(
	const Octree& other
)
 :	root_m( other.root_m )
{
}


template<class TYPE>
inline
Octree<TYPE>& Octree<TYPE>::operator=
(
	const Octree& other
)
{
	root_m = other.root_m;

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
template<class TYPE>
inline
bool Octree<TYPE>::insertItem
(
	const TYPE&                 item,
	const OctreeVisitorT<TYPE>& visitor
)
{
	return root_m.insertItem( &item, visitor );
}


template<class TYPE>
inline
bool Octree<TYPE>::removeItem
(
	const TYPE&                 item,
	const OctreeVisitorT<TYPE>& visitor
)
{
	return root_m.removeItem( &item, visitor );
}




/// queries ----------------------------------------------------------------------------------------
template<class TYPE>
inline
void Octree<TYPE>::visitItems
(
	OctreeVisitorT<TYPE>& visitor
) const
{
	root_m.visitItems( visitor );
}


template<class TYPE>
inline
bool Octree<TYPE>::isEmpty() const
{
	return root_m.isEmpty();
}


template<class TYPE>
inline
void Octree<TYPE>::getInfo
(
	dword& byteSize,
	dword& leafCount,
	dword& elementCount,
	dword& maxDepth
) const
{
	root_m.getInfo( sizeof(*this), byteSize, leafCount, elementCount, maxDepth );
}


template<class TYPE>
inline
std::ostream& Octree<TYPE>::streamOut
(
	std::ostream& out
) const
{
	return root_m.streamOut( sizeof(*this), out );
}


template<class TYPE>
inline
const Vector3f& Octree<TYPE>::getPosition() const
{
	return root_m.getPosition();
}


template<class TYPE>
inline
float Octree<TYPE>::getSize() const
{
	return root_m.getSize();
}


template<class TYPE>
inline
dword Octree<TYPE>::getMaxElementCountPerCell() const
{
	return root_m.getMaxElementCountPerCell();
}


template<class TYPE>
inline
dword Octree<TYPE>::getMaxLevelCount() const
{
	return root_m.getMaxLevelCount();
}


}//namespace




#endif//Octree_h
