/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef OctreeAuxiliary_h
#define OctreeAuxiliary_h


#include "Vector3f.hpp"
#include "Array.hpp"




#include "hxa7241_graphics.hpp"
namespace hxa7241_graphics
{
	using hxa7241_graphics::Vector3f;
	using hxa7241_general::Array;

	class OctreeRoot;
	class OctreeCell;


/**
 * global octree data.
 */
class OctreeDimensions
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeDimensions( const Vector3f& positionOfLowerCorner,
	                           float           size,
	                           dword           maxElementCountPerCell,
	                           dword           maxLevelCount );

	        ~OctreeDimensions();
	         OctreeDimensions( const OctreeDimensions& );
	OctreeDimensions& operator=( const OctreeDimensions& );


/// queries ----------------------------------------------------------------------------------------
	        const Vector3f& getPosition()                                                     const;
	        float           getSize()                                                         const;
	        dword           getMaxElementCountPerCell()                                       const;
	        dword           getMaxLevelCount()                                                const;

	        bool            isSubdivide( dword elementCount,
	                                     dword level )                                        const;


/// fields -----------------------------------------------------------------------------------------
private:
	Vector3f positionOfLowerCorner_m;
	float    size_m;
	dword    maxElementsPerCell_m;
	dword    maxLevel_m;

	static const dword MAX_LEVEL;
};




/**
 * geometric data for the bound of an octree cell.<br/><br/>
 *
 * radius is that of the circumsphere.<br/><br/>
 *
 * subcell numbering:
 * <pre>
 * 		y z           110 111
 * 		|/   010 011  100 101
 * 		 -x  000 001
 * </pre>
 */
class OctreeBound
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeBound();
	         OctreeBound( const Vector3f& positionOfLowerCorner,
	                      float           size );
	         OctreeBound( const OctreeBound& parentCellBound,
	                      dword              subCellIndex );

	        ~OctreeBound();
	         OctreeBound( const OctreeBound& );
	OctreeBound& operator=( const OctreeBound& );


/// queries ----------------------------------------------------------------------------------------
	        const Vector3f& getLowerCorner()                                                  const;
	        const Vector3f& getUpperCorner()                                                  const;
	        const Vector3f& getCenter()                                                       const;
	        float           getRadius()                                                       const;


/// fields -----------------------------------------------------------------------------------------
private:
	Vector3f positionOfLowerCorner_m;
	Vector3f positionOfUpperCorner_m;
	Vector3f center_m;
	float    circumSphereRadius_m;
};




/**
 * global and local octree cell data.<br/><br/>
 *
 * to be made during each level of tree descent, so storage is avoided, except to
 * hold one at the root.<br/><br/>
 *
 * subcell numbering:
 * <pre>
 * 		y z           110 111
 * 		|/   010 011  100 101
 * 		 -x  000 001
 * </pre>
 */
class OctreeData
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeData( const OctreeDimensions& dimensions );
	         OctreeData( const OctreeData& parentCellData,
	                     dword             subCellIndex );
	         OctreeData( const OctreeData&,
	                     const OctreeDimensions& );

	        ~OctreeData();
private:
	         OctreeData( const OctreeData& );
	OctreeData& operator=( const OctreeData& );


/// commands ---------------------------------------------------------------------------------------
public:
	        OctreeData& assign( const OctreeData&,
	                            const OctreeDimensions& );


/// queries ----------------------------------------------------------------------------------------
	        const OctreeBound& getBound()                                                     const;
	        dword              getLevel()                                                     const;

	        bool               isSubdivide( dword elementCount )                              const;


/// fields -----------------------------------------------------------------------------------------
private:
	/// local to cell
	OctreeBound bound_m;
	dword       level_m;

	/// global for octree
	const OctreeDimensions* pDimensions_m;
};




/**
 * visitor abstract base, for Octree implementation use.<br/><br/>
 *
 * return value of getSubcellOverlapsV is 8 bits, each bit is a bool
 * corresponding to a subcell, the high bit for subcell 7, the low bit for
 * subcell 0.<br/><br/>
 *
 * subcell numbering:
 * <pre>
 * 		y z           110 111
 * 		|/   010 011  100 101
 * 		 -x  000 001
 * </pre>
 *
 * @see OctreeCell
 * @see OctreeBranch
 * @see OctreeLeaf
 */
class OctreeVisitor
{
/// standard object services -----------------------------------------------------------------------
protected:
	         OctreeVisitor() {}
public:
	virtual ~OctreeVisitor() {}
private:
	         OctreeVisitor( const OctreeVisitor& );
	OctreeVisitor& operator=( const OctreeVisitor& );


/// commands ---------------------------------------------------------------------------------------
public:
	virtual void  visitRootV  ( const OctreeCell* pRootCell,
	                            const OctreeData& octreeData )                                   =0;
	virtual void  visitBranchV( const OctreeCell* subCells[8],
	                            const OctreeData& octreeData )                                   =0;
	virtual void  visitLeafV  ( const Array<const void*>& items,
	                            const OctreeData&         octreeData )                           =0;


/// queries ----------------------------------------------------------------------------------------
	virtual bool  isOverlappingCellV ( const void*     pItem,
	                                   const Vector3f& lowerCorner,
	                                   const Vector3f& upperCorner )                       const =0;
	virtual dword getSubcellOverlapsV( const void*     pItem,
	                                   const Vector3f& lower,
	                                   const Vector3f& middle,
	                                   const Vector3f& upper )                             const =0;


/// constants --------------------------------------------------------------------------------------
	static const dword ALL_INSIDE  = 0x0000FFFF;
	static const dword ALL_OUTSIDE = 0x00000000;
};








/// inlines ///

/// OctreeDimensions -------------------------------------------------------------------------------
inline
const Vector3f& OctreeDimensions::getPosition() const
{
	return positionOfLowerCorner_m;
}


inline
float OctreeDimensions::getSize() const
{
	return size_m;
}


inline
dword OctreeDimensions::getMaxElementCountPerCell() const
{
	return maxElementsPerCell_m;
}


inline
dword OctreeDimensions::getMaxLevelCount() const
{
	return maxLevel_m + 1;
}




/// OctreeBound ------------------------------------------------------------------------------------
inline
const Vector3f& OctreeBound::getLowerCorner() const
{
	return positionOfLowerCorner_m;
}


inline
const Vector3f& OctreeBound::getUpperCorner() const
{
	return positionOfUpperCorner_m;
}


inline
const Vector3f& OctreeBound::getCenter() const
{
	return center_m;
}


inline
float OctreeBound::getRadius() const
{
	return circumSphereRadius_m;
}




/// OctreeData -------------------------------------------------------------------------------------
inline
const OctreeBound& OctreeData::getBound() const
{
	return bound_m;
}


inline
dword OctreeData::getLevel() const
{
	return level_m;
}


inline
bool OctreeData::isSubdivide
(
	const dword elementCount
) const
{
	return pDimensions_m->isSubdivide( elementCount, level_m );
}


}//namespace




#endif//OctreeAuxiliary_h
