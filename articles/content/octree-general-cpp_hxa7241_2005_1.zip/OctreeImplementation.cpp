/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "Vector3f.hpp"
#include <iostream>

#include "OctreeImplementation.hpp"   /// own header is included last


using namespace hxa7241_graphics;




/// OctreeRoot /////////////////////////////////////////////////////////////////////////////////////


/// standard object services -----------------------------------------------------------------------
OctreeRoot::OctreeRoot
(
	const Vector3f& position,
	const float     sizeOfCube,
	const dword     maxElementsPerCell,
	const dword     maxLevelCount
)
 :	dimensions_m( position, sizeOfCube, maxElementsPerCell, maxLevelCount )
 ,	pRootCell_m ( 0 )
{
}


OctreeRoot::~OctreeRoot()
{
	delete pRootCell_m;
}


OctreeRoot::OctreeRoot
(
	const OctreeRoot& other
)
 :	dimensions_m( other.dimensions_m )
 ,	pRootCell_m ( OctreeCell::cloneNonZero( other.pRootCell_m ) )
{
}


OctreeRoot& OctreeRoot::operator=
(
	const OctreeRoot& other
)
{
	if( &other != this )
	{
		delete pRootCell_m;
		pRootCell_m = 0;
		pRootCell_m = OctreeCell::cloneNonZero( other.pRootCell_m );

		dimensions_m = other.dimensions_m;
	}

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
bool OctreeRoot::insertItem
(
	const void* const    pItem,
	const OctreeVisitor& visitor
)
{
	bool isInserted = false;

	/// make data
	const OctreeData data( dimensions_m );

	/// check if item overlaps root cell
	if( visitor.isOverlappingCellV( pItem, data.getBound().getLowerCorner(), data.getBound().getUpperCorner() ) )
	{
		OctreeLeaf::insertItemMaybeCreate( data, pRootCell_m, pItem, visitor );

		isInserted = true;
	}

	return isInserted;
}


bool OctreeRoot::removeItem
(
	const void* const    pItem,
	const OctreeVisitor& //visitor
)
{
	bool isRemoved = false;

	if( pRootCell_m != 0 )
	{
		isRemoved = pRootCell_m->removeItem( pRootCell_m, pItem );
	}

	return isRemoved;
}




/// queries ----------------------------------------------------------------------------------------
void OctreeRoot::visitItems
(
	OctreeVisitor& visitor
) const
{
	/// make data
	const OctreeData data( dimensions_m );

	visitor.visitRootV( pRootCell_m, data );
}


bool OctreeRoot::isEmpty() const
{
	return pRootCell_m == 0;
}


void OctreeRoot::getInfo
(
	const dword rootWrapperByteSize,
	dword&      byteSize,
	dword&      leafCount,
	dword&      elementCount,
	dword&      maxDepth
) const
{
	byteSize     = 0;
	leafCount    = 0;
	elementCount = 0;
	maxDepth     = 0;

	if( pRootCell_m != 0 )
	{
		pRootCell_m->getInfo( byteSize, leafCount, elementCount, maxDepth );
	}

	byteSize += rootWrapperByteSize;
}


std::ostream& OctreeRoot::streamOut
(
	const dword   rootWrapperByteSize,
	std::ostream& out
) const
{
	{
		dword byteSize;
		dword leafCount;
		dword elementCount;
		dword maxDepth;
		getInfo( rootWrapperByteSize, byteSize, leafCount, elementCount, maxDepth );

		out << "\nOctree " << this <<
		       "\nposition: " << getPosition() << "  size: " << getSize() <<
		       "  maxElementCountPerCell: " << getMaxElementCountPerCell() << "  maxLevelCount: " << getMaxLevelCount() <<
		       "\nbytes: " << byteSize << ", leafs: " << leafCount << ", elements: " << elementCount << ", depth: " << maxDepth << "\n{ ";
	}

	if( pRootCell_m != 0 )
	{
		/// make data
		const OctreeData data( dimensions_m );

		pRootCell_m->streamOut( data, 1, out );
	}
	else
	{
		out << "empty ";
	}

	out << "} ";

	return out;
}


const Vector3f& OctreeRoot::getPosition() const
{
	return dimensions_m.getPosition();
}


float OctreeRoot::getSize() const
{
	return dimensions_m.getSize();
}


dword OctreeRoot::getMaxElementCountPerCell() const
{
	return dimensions_m.getMaxElementCountPerCell();
}


dword OctreeRoot::getMaxLevelCount() const
{
	return dimensions_m.getMaxLevelCount();
}








/// OctreeCell /////////////////////////////////////////////////////////////////////////////////////


/// statics ----------------------------------------------------------------------------------------
OctreeCell* OctreeCell::cloneNonZero
(
	const OctreeCell* pOriginal
)
{
	return (pOriginal != 0) ? pOriginal->clone() : 0;
}


std::ostream& OctreeCell::streamOutDataAndInfo
(
	const OctreeCell& cell,
	const OctreeData& cellData,
	std::ostream&     out
)
{
	/// do data
	out << "(" << cellData.getLevel() << "# " <<
	       cellData.getBound().getLowerCorner() << " " << cellData.getBound().getUpperCorner() << " " <<
	       cellData.getBound().getCenter() << " " << cellData.getBound().getRadius() << ")  ";

	/// do info
	dword byteSize     = 0;
	dword leafCount    = 0;
	dword elementCount = 0;
	dword maxDepth     = 0;
	cell.getInfo( byteSize, leafCount, elementCount, maxDepth );

	out << "bytes: " << byteSize << ", leafs: " << leafCount << ", elements: " << elementCount << ", depth: " << maxDepth << "  ";

	return out;
}








/// OctreeBranch ///////////////////////////////////////////////////////////////////////////////////


/// standard object services -----------------------------------------------------------------------
OctreeBranch::OctreeBranch()
{
	OctreeBranch::zeroSubCells();
}


OctreeBranch::OctreeBranch
(
	const OctreeData&         thisData,
	const Array<const void*>& items,
	const void* const         pItem,
	const OctreeVisitor&      visitor
)
{
	OctreeBranch::zeroSubCells();

	try
	{
		OctreeCell* pNotUsed = 0;

		/// insert items
		for( int j = items.getLength();  j-- > 0; )
		{
			OctreeBranch::insertItem( thisData, pNotUsed, items[j], visitor );
		}

		OctreeBranch::insertItem( thisData, pNotUsed, pItem, visitor );
	}
	catch( ... )
	{
		/// delete any allocated cells
		this->~OctreeBranch();

		throw;
	}
}


OctreeBranch::~OctreeBranch()
{
	for( int i = 8;  i-- > 0; )
	{
		delete subCells_m[i];
	}
}


OctreeBranch::OctreeBranch
(
	const OctreeBranch& other
)
 :	OctreeCell()
{
	OctreeBranch::zeroSubCells();

	try
	{
		for( int i = 8;  i-- > 0; )
		{
			subCells_m[i] = OctreeCell::cloneNonZero( other.subCells_m[i] );
		}
	}
	catch( ... )
	{
		/// delete any allocated cells
		this->~OctreeBranch();

		throw;
	}
}


OctreeBranch& OctreeBranch::operator=
(
	const OctreeBranch& other
)
{
	if( &other != this )
	{
		for( int i = 8;  i-- > 0; )
		{
			delete subCells_m[i];
			subCells_m[i] = 0;
			subCells_m[i] = OctreeCell::cloneNonZero( other.subCells_m[i] );
		}
	}

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
void OctreeBranch::insertItem
(
	const OctreeData&    thisData,
	OctreeCell*&         ,//pThis,
	const void* const    pItem,
	const OctreeVisitor& visitor
)
{
	/// get subcell-item overlaps flags
	const OctreeBound& bound    = thisData.getBound();
	const dword        overlaps = visitor.getSubcellOverlapsV( pItem, bound.getLowerCorner(), bound.getCenter(), bound.getUpperCorner() );

	/// loop through sub cells
	for( int i = 8;  i-- > 0; )
	{
		/// check if sub cell is overlapped by item
		if( (overlaps >> i) & 1 )
		{
			/// make sub cell data
			const OctreeData subCellData( thisData, i );

			/// add item to sub cell
			OctreeLeaf::insertItemMaybeCreate( subCellData, subCells_m[i], pItem, visitor );
		}
	}
}


bool OctreeBranch::removeItem
(
	OctreeCell*&       pThis,
	const void* const  pItem
)
{
	bool isRemoved  = false;
	bool isAllEmpty = true;

	/// loop through sub cells
	for( int i = 8;  i-- > 0; )
	{
		OctreeCell*& pSubCell = subCells_m[i];
		if( pSubCell != 0 )
		{
			/// remove item from sub cell
			isRemoved |= pSubCell->removeItem( pSubCell, pItem );
		}

		isAllEmpty &= (pSubCell == 0);
	}

	/// check if branch has no sub cells
	if( isAllEmpty )
	{
		/// delete this branch
		delete pThis;
		pThis = 0;
	}

	return isRemoved;
}




/// queries ----------------------------------------------------------------------------------------
void OctreeBranch::visitItems
(
	const OctreeData& thisData,
	OctreeVisitor&    visitor
) const
{
	visitor.visitBranchV( const_cast<const OctreeCell**>(subCells_m), thisData );
}


OctreeCell* OctreeBranch::clone() const
{
	return new OctreeBranch( *this );
}


void OctreeBranch::getInfo
(
	dword& byteSize,
	dword& leafCount,
	dword& elementCount,
	dword& maxDepth
) const
{
	byteSize += sizeof(*this);

	const dword thisDepth = maxDepth + 1;

	for( int i = 8;  i-- > 0; )
	{
		const OctreeCell*const pSubCell = subCells_m[i];
		if( pSubCell != 0 )
		{
			dword depth = thisDepth;
			pSubCell->getInfo( byteSize, leafCount, elementCount, depth );

			if( maxDepth < depth )
			{
				maxDepth = depth;
			}
		}
	}
}


std::ostream& OctreeBranch::streamOut
(
	const OctreeData& thisData,
	const dword       indent,
	std::ostream&     out
) const
{
	OctreeCell::streamOutDataAndInfo( *this, thisData, out );

	for( int i = 0;  i < 8;  ++i )
	{
		out << "\n";
		for( dword j = indent;  j-- > 0; )
		{
			out << "\t";
		}
		out << "[" << i << " ";

		const OctreeCell*const pSubCell = subCells_m[i];
		if( pSubCell != 0 )
		{
			const OctreeData subCellData( thisData, i );

			pSubCell->streamOut( subCellData, indent + 1, out );
		}
		else
		{
			out << "empty ";
		}

		out << "] ";
	}
	out << "\n";
	for( dword i = indent - 1;  i-- > 0; )
	{
		out << "\t";
	}

	return out;
}




/// implementation ---------------------------------------------------------------------------------
void OctreeBranch::zeroSubCells()
{
	for( int i = 8;  i-- > 0; )
	{
		subCells_m[i] = 0;
	}
}








/// OctreeLeaf /////////////////////////////////////////////////////////////////////////////////////


/// standard object services -----------------------------------------------------------------------
OctreeLeaf::OctreeLeaf()
 :	items_m()
{
}


OctreeLeaf::OctreeLeaf
(
	const void* pItem
)
 :	items_m()
{
	items_m.append( pItem );
}


OctreeLeaf::~OctreeLeaf()
{
}


OctreeLeaf::OctreeLeaf
(
	const OctreeLeaf& other
)
 :	OctreeCell()
 ,	items_m( other.items_m )
{
}


OctreeLeaf& OctreeLeaf::operator=
(
	const OctreeLeaf& other
)
{
	items_m = other.items_m;

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
void OctreeLeaf::insertItem
(
	const OctreeData&    thisData,
	OctreeCell*&         pThis,
	const void* const    pItem,
	const OctreeVisitor& visitor
)
{
	/// check if item already present
	bool isAlreadyPresent = false;
	for( int i = items_m.getLength();  (i-- > 0) & !isAlreadyPresent; )
	{
		isAlreadyPresent |= (items_m[i] == pItem);
	}

	/// only insert if item not already present
	if( !isAlreadyPresent )
	{
		/// check if leaf should be subdivided
		if( !thisData.isSubdivide( items_m.getLength() + 1 ) )
		{
			/// append item to collection
			items_m.append( pItem );
		}
		else
		{
			/// subdivide by making branch and adding items to it
			OctreeCell*const pBranch = new OctreeBranch( thisData, items_m, pItem, visitor );

			/// replace this with branch
			delete pThis;
			pThis = pBranch;
		}
	}
}


bool OctreeLeaf::removeItem
(
	OctreeCell*&       pThis,
	const void* const  pItem
)
{
	bool isRemoved = false;

	/// loop through items
	for( int i = 0;  i < items_m.getLength(); )
	{
		/// check if item is present
		if( items_m[i] == pItem )
		{
			/// remove item
			items_m.remove( i );
			isRemoved = true;
		}
		else
		{
			++i;
		}
	}

	/// check if leaf is now empty
	if( items_m.isEmpty() )
	{
		/// remove this leaf
		delete pThis;
		pThis = 0;
	}

	return isRemoved;
}




/// queries ----------------------------------------------------------------------------------------
void OctreeLeaf::visitItems
(
	const OctreeData& thisData,
	OctreeVisitor&    visitor
) const
{
	visitor.visitLeafV( items_m, thisData );
}


OctreeCell* OctreeLeaf::clone() const
{
	return new OctreeLeaf( *this );
}


void OctreeLeaf::getInfo
(
	dword& byteSize,
	dword& leafCount,
	dword& elementCount,
	dword& maxDepth
) const
{
	byteSize  += sizeof(*this) + (items_m.getLength() * sizeof(void*));
	++leafCount;
	elementCount += items_m.getLength();
	++maxDepth;
}


std::ostream& OctreeLeaf::streamOut
(
	const OctreeData& thisData,
	const dword       ,//indent,
	std::ostream&     out
) const
{
	OctreeCell::streamOutDataAndInfo( *this, thisData, out );

	const void** pItem = items_m.getMemory();
	const void** pEnd  = pItem + items_m.getLength();

	for( ;  pItem < pEnd;  ++pItem )
	{
		out << "<" << *pItem << "> ";
	}

	return out;
}




/// statics ----------------------------------------------------------------------------------------
void OctreeLeaf::insertItemMaybeCreate
(
	const OctreeData&    cellData,
	OctreeCell*&         pCell,
	const void* const    pItem,
	const OctreeVisitor& visitor
)
{
	/// check cell exists
	if( pCell == 0 )
	{
		/// make leaf, adding item
		OctreeCell*const pLeaf = new OctreeLeaf( pItem );

		/// replace cell with leaf
		delete pCell;
		pCell = pLeaf;
	}
	else
	{
		/// forward to existing cell
		pCell->insertItem( cellData, pCell, pItem, visitor );
	}
}
