/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef OctreeImplementation_h
#define OctreeImplementation_h


#include "OctreeAuxiliary.hpp"
#include "Array.hpp"
#include <iosfwd>




#include "hxa7241_graphics.hpp"
namespace hxa7241_graphics
{
	using hxa7241_graphics::Vector3f;
	using hxa7241_general::Array;
	class OctreeCell;


/**
 * implementation class for the Octree template.
 *
 * @invariants
 * pRootCell_m can be null, or point to an OctreeCell instance.<br/><br/>
 *
 * at construction, pRootCell_m is set to a legal value.<br/>
 * at destruction, pRootCell_m is deleted.<br/>
 * whenever pRootCell_m is modified, it must be deleted then set to a legal value.
 * <br/>
 * a legal value is: either 0, or the value from invocation of 'new'.
 */
class OctreeRoot
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeRoot( const Vector3f& position,
	                     float           sizeOfCube,
	                     dword           maxElementsPerCell,
	                     dword           maxLevelCount );

	        ~OctreeRoot();
	         OctreeRoot( const OctreeRoot& );
	OctreeRoot& operator=( const OctreeRoot& );


/// commands ---------------------------------------------------------------------------------------
	        bool  insertItem( const void*          pItem,
	                          const OctreeVisitor& visitor );
	        bool  removeItem( const void*          pItem,
	                          const OctreeVisitor& visitor );


/// queries ----------------------------------------------------------------------------------------
	        void  visitItems( OctreeVisitor& )                                                const;

	        bool  isEmpty()                                                                   const;
	        void  getInfo( dword  rootWrapperByteSize,
	                       dword& byteSize,
	                       dword& leafCount,
	                       dword& elementCount,
	                       dword& maxDepth )                                                  const;
	        std::ostream& streamOut( dword rootWrapperByteSize,
	                                 std::ostream& )                                          const;

	        const Vector3f& getPosition()                                                     const;
	        float           getSize()                                                         const;
	        dword           getMaxElementCountPerCell()                                       const;
	        dword           getMaxLevelCount()                                                const;


/// fields -----------------------------------------------------------------------------------------
private:
	OctreeDimensions dimensions_m;
	OctreeCell*      pRootCell_m;
};




/**
 * abstract base for Composite types, for implementing Octree nodes.
 *
 * @implementation
 * subcell numbering:
 * <pre>
 * 		y z           110 111
 * 		|/   010 011  100 101
 * 		 -x  000 001
 * </pre>
 */
class OctreeCell
{
/// standard object services -----------------------------------------------------------------------
protected:
	         OctreeCell() {}
public:
	virtual ~OctreeCell() {}
private:
	         OctreeCell( const OctreeCell& );
	OctreeCell& operator=( const OctreeCell& );


/// commands ---------------------------------------------------------------------------------------
public:
	virtual void  insertItem( const OctreeData&    thisData,
	                          OctreeCell*&         pThis,
	                          const void*          pItem,
	                          const OctreeVisitor& visitor )                                     =0;
	virtual bool  removeItem( OctreeCell*&         pThis,
	                          const void*          pItem )                                       =0;


/// queries ----------------------------------------------------------------------------------------
	virtual void  visitItems( const OctreeData& thisData,
	                          OctreeVisitor&    visitor )                                  const =0;

	virtual OctreeCell* clone()                                                            const =0;

	virtual void  getInfo( dword& byteSize,
	                       dword& leafCount,
	                       dword& elementCount,
	                       dword& maxDepth )                                               const =0;
	virtual std::ostream& streamOut( const OctreeData& thisData,
	                                 dword             indent,
	                                 std::ostream& )                                       const =0;


/// statics ----------------------------------------------------------------------------------------
	static  OctreeCell*   cloneNonZero( const OctreeCell* );
	static  std::ostream& streamOutDataAndInfo( const OctreeCell&,
	                                            const OctreeData&,
	                                            std::ostream& );
};




/**
 * inner node implementation of an octree cell.<br/><br/>
 *
 * stores pointers to eight child cells.
 *
 * @invariants
 * subCells_m elements can be null, or point to an OctreeCell instance.
 */
class OctreeBranch
	: public OctreeCell
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeBranch();
	         OctreeBranch( const OctreeData&         thisData,
	                       const Array<const void*>& items,
	                       const void* const         pItem,
	                       const OctreeVisitor&      visitor );

	virtual ~OctreeBranch();
	         OctreeBranch( const OctreeBranch& );
	OctreeBranch& operator=( const OctreeBranch& );


/// commands ---------------------------------------------------------------------------------------
	virtual void  insertItem( const OctreeData&    thisData,
	                          OctreeCell*&         pThis,
	                          const void*          pItem,
	                          const OctreeVisitor& visitor );
	virtual bool  removeItem( OctreeCell*&         pThis,
	                          const void*          pItem );


/// queries ----------------------------------------------------------------------------------------
	virtual void  visitItems( const OctreeData& thisData,
	                          OctreeVisitor&    visitor )                                     const;

	virtual OctreeCell* clone()                                                               const;

	virtual void  getInfo( dword& byteSize,
	                       dword& leafCount,
	                       dword& elementCount,
	                       dword& maxDepth )                                                  const;
	virtual std::ostream& streamOut( const OctreeData& thisData,
	                                 dword             indent,
	                                 std::ostream& )                                          const;


/// implementation ---------------------------------------------------------------------------------
protected:
	virtual void  zeroSubCells();


/// fields -----------------------------------------------------------------------------------------
private:
	OctreeCell* subCells_m[8];
};




/**
 * outer node implementation of an octree cell.<br/><br/>
 *
 * stores pointers to items.
 */
class OctreeLeaf
	: public OctreeCell
{
/// standard object services -----------------------------------------------------------------------
public:
	         OctreeLeaf();
private:
	explicit OctreeLeaf( const void* pItem );

public:
	virtual ~OctreeLeaf();
	         OctreeLeaf( const OctreeLeaf& );
	OctreeLeaf& operator=( const OctreeLeaf& );


/// commands ---------------------------------------------------------------------------------------
	virtual void  insertItem( const OctreeData&    thisData,
	                          OctreeCell*&         pThis,
	                          const void*          pItem,
	                          const OctreeVisitor& visitor );
	virtual bool  removeItem( OctreeCell*&         pThis,
	                          const void*          pItem );


/// queries ----------------------------------------------------------------------------------------
	virtual void  visitItems( const OctreeData& thisData,
	                          OctreeVisitor&    visitor )                                     const;

	virtual OctreeCell* clone()                                                               const;

	virtual void  getInfo( dword& byteSize,
	                       dword& leafCount,
	                       dword& elementCount,
	                       dword& maxDepth )                                                  const;
	virtual std::ostream& streamOut( const OctreeData& thisData,
	                                 dword             indent,
	                                 std::ostream& )                                          const;


/// statics ----------------------------------------------------------------------------------------
	static  void  insertItemMaybeCreate( const OctreeData&    cellData,
	                                     OctreeCell*&         pCell,
	                                     const void*          pItem,
	                                     const OctreeVisitor& visitor );


/// fields -----------------------------------------------------------------------------------------
private:
	Array<const void*> items_m;
};


}//namespace




#endif//OctreeImplementation_h
