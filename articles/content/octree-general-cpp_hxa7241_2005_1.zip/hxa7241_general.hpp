/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef hxa7241_general_p
#define hxa7241_general_p


#include "Primitives.hpp"




namespace hxa7241_general
{
	using namespace hxa7241;

	//template<class T> class Array;
}




#endif//hxa7241_general_p
