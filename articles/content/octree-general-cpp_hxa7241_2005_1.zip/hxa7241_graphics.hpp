/*--------------------------------------------------------------------

   Perceptuum3 renderer, version 1.0
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef hxa7241_graphics_p
#define hxa7241_graphics_p


#include "Primitives.hpp"




namespace hxa7241_graphics
{
	using namespace hxa7241;

	//template<class T> class Octree;
	//template<class T> class OctreeVisitorT;
	class Vector3f;
}




#endif//hxa7241_graphics_p
