#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




class Object

  def cloneDeep?

    Marshal.load( Marshal.dump( self ) )

  end

end




class Array

	def to_s

		self.join( "\n" ) + "\n"

	end

end




class Hash

	def to_s

		s = ''
		each do |key, value|
			s += "#{key} => #{value}\n"
		end
		s

	end

end




#class Float
#
#	alias to_s_old to_s
#
#	def to_s( precision=-1 )
#		if -1 == precision
#			to_s_old
#		else
#			(((to_f * (10 ** precision)).to_i).to_f / (10 ** precision)).to_s
#		end
#	end
#
#end




module Hxa7241

	# logging

	@@logLevel = 0


	def Hxa7241.getLogLevel?
		@@logLevel
	end


	def Hxa7241.setLogLevel!( level )
		@@logLevel = level
	end


	def Hxa7241.log( item, level=0 )

		if level <= @@logLevel
			print item
		end

	end


	# math

	FLOAT_MIN        = -2.0 ** 128.0
	FLOAT_MAX        = +2.0 ** 128.0
	FLOAT_EPSILON    =  2.0 ** -32.0
	FLOAT_ALMOST_ONE =  1.0 - FLOAT_EPSILON


	# general

	def Hxa7241.copy?( object )

		object ? object.class.new( object ) : nil

	end

end
