#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'
require 'OctreeAuxiliary'
require 'OctreeImplementation'




module Hxa7241_Graphics


# The client needs to prepare two classes to use #Octree:
#
# ==item class
# Client needs to extend the item class with two methods:
#
# ===isOverlappingCell?
# Called by octree to get relation of item to cell.
# Taking parameters:
# * cellLowerCorner: #Vector3fc
# * CellUpperCorner: #Vector3fc
#
# ===getSubcellOverlaps?
# Called by octree to get relation of item to subcell octants.
# (Allows more efficent calculation, since boundaries are shared. But client
# could implement by delegating to isOverlappingCell.)
# Taking parameters:
# * cellsLowerPos:  #Vector3fc
# * cellsMiddlePos: #Vector3fc
# * cellsUpperPos:  #Vector3fc
# Return:
# 8 bits, each a bool corresponding to a subcell, the high bit for subcell
# 7, the low bit for subcell 0.
# Subcell numbering:
#    y z       6 7
#    |/   2 3  4 5
#     -x  0 1
# in binary:
#    y z           110 111
#    |/   010 011  100 101
#     -x  000 001
# eg: subcell (high x, high y, low z) is number 3, and flagged in bit 3
#
# ==visitor class
# Client needs to provide a visitor class.
#
# This is a reversal of the Visitor pattern: it allows an operation to be
# performed with the octree, except the octree is merely read from and it is
# the visitor that is modified.
#
# The visit methods are called by the tree nodes during the visit operation.
# The parameters supply the cell and boundary info. The implementation can
# call visit on the supplied cell.
#
# The implementation of #visitBranch! needs to make the #OctreeData to be given
# in each call of visit.
#
# Subcell numbering:
#    y z       6 7
#    |/   2 3  4 5
#     -x  0 1
# in binary:
#    y z           110 111
#    |/   010 011  100 101
#     -x  000 001
# eg: subcell (high x, high y, low z) is number 3, and flagged in bit 3
#
# The visitor class must have three methods:
#
# ===visitRoot!
# Called by #Octree when visit traversal is at the root.
# To continue deeper, implementation calls visit on rootCell, supplying
# octreeData and self as arguments.
# Taking parameters:
# * octreeData: #OctreeData
# * rootCell: #OctreeCell/#OctreeBranch/#OctreeLeaf
#
# ===visitBranch!
# Called by #Octree when visit traversal is at a branch.
# To continue deeper, implementation calls visit on any/all subcells,
# supplying a new octreeData and self as arguments. The new octreeData is
# made with its constructor that will take the original octreeData and the
# subcell index. Check subcell values before use, since they can be nil.
# Taking parameters:
# * octreeData: #OctreeData
# * subCells: #Array, length 8, of #OctreeCell/#OctreeBranch/#OctreeLeaf or nil
#
# ===visitLeaf!
# Taking parameters:
# Called by #Octree when visit traversal is at a leaf.
# * octreeData: #OctreeData
# * items: #Array, of items




# An octree volume spatial index.
#
# client must define an visitor class, and methods for item class.
#
# In construction, max items per cell is ignored where max levels is reached.
#
# The octree is cubical and axis aligned, partitions are axis aligned,
# partitions divide in half, each level partitions the previous level in all
# three axiss.
#
# Storage is contracted or expanded as needed by item insertion and removal.
#
# ===implementation
# The octree structure follows the Composite pattern.
#
# For the visit query, the visitor provides callbacks to read tree nodes for
# carrying out the visit operation.
#
# ===invariants
# * dimensions is an #OctreeDimensions (owned)
# * rootCell can be nil, or an #OctreeCell derivative
#
class Octree

	# Constructs a particular format of octree.
	# ===parameters options
	# * #Vector3fc position, Numeric size,
	#   Integer max item refs per cell, Integer max depth of tree
	# * #Octree (copy)
	#
	def initialize( *args )

		# specify
		if 4 == args.length &&
		   args[0].kind_of?(Vector3fc) &&
		   args[1].kind_of?(Numeric)   &&
		   args[2].kind_of?(Integer)   &&
		   args[3].kind_of?(Integer)
			position, sizeOfCube, maxItemsPerCell, maxLevelCount = args

			@dimensions = OctreeDimensions.new( position, sizeOfCube,
			                                    maxItemsPerCell, maxLevelCount )
			@rootCell   = nil

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(Octree)
			other = args[0]

			@dimensions = OctreeDimensions.new( other.dimensions )
			@rootCell   = Hxa7241.copy?( other.rootCell )

		else
			throw "invalid arguments"

		end

	end


	attr_reader :dimensions, :rootCell
	protected   :dimensions, :rootCell


#-- commands -------------------------------------------------------------------

	# Add ref(s) to the item to the octree.
	# (If an item has non-zero volume, it may have refs in multiple cells.)
	# ===return is the item inserted -- false if item not inside root bound
	# ===see #removeItem!
	def insertItem!( item )

		# make data
		data = OctreeData.new( @dimensions )

		# check if item overlaps root cell
		if item.isOverlappingCell?( data.bound.positionOfLowerCorner,
		                            data.bound.positionOfUpperCorner )
			@rootCell = Hxa7241_Graphics::insertItem_( @rootCell, data, item )
		end

		nil

	end


	# Removes ref(s) to the item from the octree.
	# (If an item has non-zero volume, it may have refs in multiple cells.)
	# ===return is the item removed -- false if item wasn't present
	# ===see #insertItem!
	def removeItem!( item )

		if @rootCell
			@rootCell = @rootCell.removeItem!( @dimensions.maxItemsPerCell,
			                                   [0], item )
		end

		nil

	end


#-- queries --------------------------------------------------------------------

	# Execute a visit query operation.
	#
	def visit?( visitor )

		octreeData = OctreeData.new( @dimensions )

		visitor.visitRoot!( octreeData, @rootCell )

	end


	# Provides stats on the octree.
	# ===return
	# A #Hash containing:
	# * 'leafCount' => number of leafs in octree
	# * 'itemRefCount' => number of item references (not always equal to the
	#   number of different items -- since, if the items are not points,
	#   multiple leafs may refer to the same item)
	# * 'depthLargest' => largest depth of octree
	#
	def getInfo?

		info = { 'leafCount'    => 0,
		         'itemRefCount' => 0,
		         'depthLargest' => 0 }

		@rootCell.getInfo?( info ) if @rootCell

		info

	end


	# Reports if the octree is empty.
	#
	def isEmpty?

		nil == @rootCell

	end


	# Gives the position supplied at construction.
	#
	def position

		@dimensions.positionOfLowerCorner

	end


	# Gives the size supplied at construction.
	#
	def size

		@dimensions.size

	end


	# Gives the leaf pointer limit supplied at construction.
	#
	def maxItemCountPerCell

		@dimensions.maxItemsPerCell

	end


	# Gives the depth limit supplied at construction.
	#
	def maxLevelCount

		@dimensions.maxLevelCount

	end

end


end # module Hxa7241_Graphics
