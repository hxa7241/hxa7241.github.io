#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'
require 'Vector3fc'




module Hxa7241_Graphics


# Global octree data.
#
# Constant.
#
# ===invariants
# * positionOfLowerCorner is a #Vector3fc (owned)
# * size is a Float, positive
# * maxItemsPerCell is a Integer, >= 1
# * maxLevel is a Integer, positive
#
class OctreeDimensions

	# ===parameters options:
	# * #Vector3fc positionOfLowerCorner, Numeric size,
	#   Integer max items per cell, Integer max levels
	# * #OctreeDimensions (copy)
	#
	def initialize( *args )

		# specify
		if 4 == args.length &&
		   args[0].kind_of?(Vector3fc) &&
		   args[1].kind_of?(Numeric)   &&
		   args[2].kind_of?(Integer)   &&
		   args[3].kind_of?(Integer)
		   positionOfLowerCorner, size,
		   maxItemsPerCell, maxLevelCount = args

			@positionOfLowerCorner = Vector3fc.new( positionOfLowerCorner )
			@size                  = size.abs.to_f
			@maxItemsPerCell       = maxItemsPerCell > 0 ? maxItemsPerCell    : 1
			@maxLevel              = maxLevelCount   > 0 ? maxLevelCount - 1  : 0

			@maxLevel = MAX_LEVEL if @maxLevel > MAX_LEVEL

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(OctreeDimensions)
			other = args[0]

			@positionOfLowerCorner = Vector3fc.new( other.positionOfLowerCorner )
			@size                  = other.size
			@maxItemsPerCell       = other.maxItemsPerCell
			@maxLevel              = other.maxLevel

		else
			throw "invalid arguments"

		end

	end


#-- queries --------------------------------------------------------------------

	attr_reader :positionOfLowerCorner,
	            :size,
	            :maxItemsPerCell,
	            :maxLevel
	protected   :maxLevel


	def maxLevelCount

		@maxLevel + 1

	end


	# Says whether to subdivide a leaf.
	# ===parameters
	# * itemCount: Integer
	# * level: Integer
	# ===return true or false
	#
	def isSubdivide?( itemCount, level )

		(itemCount > @maxItemsPerCell) && (level < @maxLevel)

	end


	def to_s

		"{ #{@positionOfLowerCorner}, #{@size}, " +
		"#{@maxItemsPerCell}, #{@maxLevel} }"

	end


#-- constants ------------------------------------------------------------------

	MAX_LEVEL = 23

end




# Geometric data for the bound of an octree cell.
#
# Constant.
#
# Subcell numbering:
#    y z           110 111
#    |/   010 011  100 101
#     -x  000 001
#
# ===invariants
# * positionOfLowerCorner is a #Vector3fc (owned)
# * positionOfUpperCorner is a #Vector3fc (owned)
# * center is a #Vector3fc (owned), midway between
#   positionOfLowerCorner and positionOfUpperCorner
# * circumSphereRadius is a Float, positive
#
class OctreeBound

	# ===parameters options:
	# * #Vector3fc positionOfLowerCorner, Numeric size
	# * #OctreeBound parentCellBound, Integer subCellIndex (quasi-copy)
	# * #OctreeBound (copy)
	# * none (default)
	#
	def initialize( *args )

		# specify
		if 2 == args.length &&
		   args[0].kind_of?(Vector3fc) &&
		   args[1].kind_of?(Numeric)
			positionOfLowerCorner, size = args

			@positionOfLowerCorner = Vector3fc.new( positionOfLowerCorner )
			@positionOfUpperCorner = positionOfLowerCorner + Vector3fc.new(size)
			@center                =
				(@positionOfLowerCorner + @positionOfUpperCorner) * 0.5
			@circumSphereRadius    = (Vector3fc::HALF * size).length?

		# quasi-copy
		elsif 2 == args.length &&
		   args[0].kind_of?(OctreeBound) &&
		   args[1].kind_of?(Integer)
			parentCellBound, subCellIndex = args

			lowMidHighPoints = [ parentCellBound.positionOfLowerCorner,
			                     parentCellBound.center,
			                     parentCellBound.positionOfUpperCorner ]

			@positionOfLowerCorner =
				Vector3fc.new( lowMidHighPoints[ subCellIndex       & 1].x,
				               lowMidHighPoints[(subCellIndex >> 1) & 1].y,
				               lowMidHighPoints[(subCellIndex >> 2) & 1].z )
			@positionOfUpperCorner =
				Vector3fc.new( lowMidHighPoints[( subCellIndex       & 1) +1].x,
				               lowMidHighPoints[((subCellIndex >> 1) & 1) +1].y,
				               lowMidHighPoints[((subCellIndex >> 2) & 1) +1].z )

			@center = (@positionOfLowerCorner + @positionOfUpperCorner) * 0.5
			@circumSphereRadius = parentCellBound.circumSphereRadius * 0.5

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(OctreeBound)
			other = args[0]

			@positionOfLowerCorner = Vector3fc.new( other.positionOfLowerCorner )
			@positionOfUpperCorner = Vector3fc.new( other.positionOfUpperCorner )
			@center                = Vector3fc.new( other.center )
			@circumSphereRadius    = other.circumSphereRadius

		# default
		elsif args.empty?
			@positionOfLowerCorner = Vector3fc.new( Vector3fc.ZERO )
			@positionOfUpperCorner = Vector3fc.new( Vector3fc.ONE )
			@center                = Vector3fc.new( Vector3fc.HALF )
			@circumSphereRadius    = Vector3fc.HALF.length

		else
			throw "invalid arguments"

		end

	end


#-- queries --------------------------------------------------------------------

	attr_reader :positionOfLowerCorner,
	            :positionOfUpperCorner,
	            :center,
	            :circumSphereRadius


	def to_s

		"{ #{@positionOfLowerCorner}, " + "
		"#{@positionOfUpperCorner}, #{@center}, #{@circumSphereRadius} }"

	end

end




# Global and local octree cell data.
#
# To be made during each level of tree descent, so storage is avoided, except to
# hold one at the root.
#
# Constant.
#
# Subcell numbering:
#    y z           110 111
#    |/   010 011  100 101
#     -x  000 001
#
# ===invariants
# * bound is a #OctreeBound (owned)
# * level is a Integer, positive
# * dimensions is a #OctreeDimensions
#
class OctreeData

	# ===parameters options:
	# * #OctreeDimensions
	# * #OctreeData parentCellData, Integer subCellIndex (quasi-copy)
	# * #OctreeData, #OctreeDimensions (quasi-copy)
	#
	def initialize( *args )

		if 1 == args.length &&
		   args[0].kind_of?(OctreeDimensions)
			dimensions = args[0]

			@bound      = OctreeBound.new( dimensions.positionOfLowerCorner,
			                               dimensions.size )
			@level      = 0
			@dimensions = dimensions

		# quasi-copy
		elsif 2 == args.length &&
		   args[0].kind_of?(OctreeData) &&
		   args[1].kind_of?(Integer)
			parentCellData, subCellIndex = args

			@bound      = OctreeBound.new( parentCellData.bound, subCellIndex )
			@level      = parentCellData.level + 1
			@dimensions = parentCellData.dimensions

		# quasi-copy
		elsif 2 == args.length &&
		   args[0].kind_of?(OctreeData) &&
		   args[1].kind_of?(OctreeDimensions)
			other, dimensions = args

			@bound      = OctreeBound.new( other.bound )
			@level      = other.level
			@dimensions = dimensions

		else
			throw "invalid arguments"

		end

	end


#-- queries --------------------------------------------------------------------

	attr_reader :bound,
	            :level,
	            :dimensions


	# Says whether to subdivide a leaf.
	# ===parameters
	# * itemCount: Integer
	# ===return true or false
	#
	def isSubdivide?( itemCount )

		@dimensions.isSubdivide?( itemCount, @level )

	end


	def to_s

		"{ #{@bound}, #{@level}, #{@dimensions.object_id} }"

	end

end


end # module Hxa7241_Graphics
