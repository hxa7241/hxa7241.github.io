#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Octree'



# ==steps
# 1. Extend your Item class with the methods to calculate if an item
# overlaps a cell, or subcells.
#
# 2. Write a visitor class, to perform an operations with an octree.
#
# 3. Write code to make items, make octrees, make visitors, add/remove items
# to octrees, execute operations on octrees.
#
# ==file contents
#
# ===classes
# * Block class: an example item
# * OctreeVisitorExample class: an example visitor using the item
# ===functions
# * main function: code to make some items, make an octree, and use the
#   visitor.




#-- Block --####################################################################

# A minimal axis-aligned 3D block: position and dimensions.
#
# Client-written item class.
#
class Block

	def initialize( *args )

		# specify
		if 2 == args.length &&
		   args[0].kind_of?(Vector3fc)
		   args[1].kind_of?(Vector3fc)
			@position   = Vector3fc.new( args[0] )
			@dimensions = Vector3fc.new( args[1] )

		elsif 1 == args.length &&
		   args[0].kind_of?(Vector3fc)
			@position   = Vector3fc.new( args[0] )
			@dimensions = Vector3fc.new( Vector3fc::ZERO )

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(Block)
			@position   = Vector3fc.new( other.position )
			@dimensions = Vector3fc.new( other.dimensions )

		# default
		else
			@position   = Vector3fc.new( Vector3fc::ZERO )
			@dimensions = Vector3fc.new( Vector3fc::ZERO )

		end

	end


#-- queries --------------------------------------------------------------------

	def position
		Vector3fc.new( @position )
	end


	def dimensions
		Vector3fc.new( @dimensions )
	end


#-- octree required methods

	def isOverlappingCell?( cellLower, cellUpper )
		itemLower = @position
		itemUpper = @position + @dimensions

		# check the two ranges overlap in every dimension
		Vector3fc::ONE == (itemLower < cellUpper) &&
		Vector3fc::ONE == (itemUpper > cellLower)
	end


	def getSubcellOverlaps?( cellsLower, cellsMiddle, cellsUpper )
		# efficiency could (probably) be improved by doing minimal necessary checks
		# against the dividing bounds, instead of repeatedly delegating to
		# isOverlappingCell?().

		flags = 0

		lowMidPoints  = [ cellsLower, cellsMiddle ]
		midHighPoints = [ cellsMiddle, cellsUpper ]

		8.times do |i|
			lowerCorner = Vector3fc.new( lowMidPoints[ i       & 1].x,
			                             lowMidPoints[(i >> 1) & 1].y,
			                             lowMidPoints[(i >> 2) & 1].z )
			upperCorner = Vector3fc.new( midHighPoints[ i       & 1].x,
			                             midHighPoints[(i >> 1) & 1].y,
			                             midHighPoints[(i >> 2) & 1].z )
			flags |= (isOverlappingCell?( lowerCorner, upperCorner ) ? 1 : 0) << i
		end

		flags
	end

end








#-- OctreeVisitorExample --#####################################################

# An example Octree visitor, for writing out leaf content.
#
# Client must write a visitor with these methods; to define an operation on the
# client's items through octree.
#
class OctreeVisitorExample

	def initialize
	end


#-- commands -------------------------------------------------------------------
#-- octree visitor overrides

	def visitRoot!( octreeData, rootCell )

			rootCell.visit?( octreeData, self ) if rootCell

	end


	def visitBranch!( octreeData, subCells )

		# step through subcells (can be in any order)
		# subcell numbering:
		#    y z       6 7
		#   |/   2 3  4 5
		#     -x  0 1
		#
		# (in binary:)
		#    y z           110 111
		#    |/   010 011  100 101
		#     -x  000 001
		#
		8.times do |i|
			subCell = subCells[i]

			# avoid null subcells
			if subCell
				# make subcell OctreeData: using octreeData argument and subcell
				# index
				subCellData = OctreeData.new( octreeData, i )
				# continue visit traversal (can choose not to)
				subCell.visit?( subCellData, self )
			end
		end

	end


	def visitLeaf!( octreeData, items )

		# make some short aliases
		lower = octreeData.bound.positionOfLowerCorner
		upper = octreeData.bound.positionOfUpperCorner

		# write leaf bound
		$defout << "leaf: level(" << octreeData.level << ") "
		$defout << "lower(" << lower.x << ", " <<
		                       lower.y << ", " <<
		                       lower.z << ") "
		$defout << "upper(" << upper.x << ", " <<
		                       upper.y << ", " <<
		                       upper.z << ")\n"

		# write items
		items.each do |item|
			# make some short aliases
			lower = item.position
			upper = item.position + item.dimensions

			# write item
			$defout << "   item: "
			$defout << "lower(" << lower.x <<
			               ", " << lower.y <<
			               ", " << lower.z << ") "
			$defout << "upper(" << upper.x <<
			               ", " << upper.y <<
			               ", " << upper.z << ")\n"
		end

		$defout << "\n"

	end


	#-- any other commands ...


#-- queries --------------------------------------------------------------------
	#-- any queries ...

end








#-- main --#####################################################################

def main

	include Hxa7241_Graphics


	# make some items
	blocks = Array.new
	8.times do |i|
		# one in the middle of each octant
		blocks.push(
			Block.new( Vector3fc.new( (i & 1).to_f        + 0.25,
			                          ((i >> 1) & 1).to_f + 0.25,
			                          ((i >> 2) & 1).to_f + 0.25 ),
			           Vector3fc.new(0.5, 0.5, 0.5) ) )
	end

	# make an octree:
	# position (0,0,0), size 2, max items per leaf 4, max depth 4
	octree = Octree.new( Vector3fc::ZERO, 2.0, 4, 4 )


	# add items to octree
	blocks.each do |block|
		octree.insertItem!( block )
	end


	# make a visitor (as many concrete variants, and instances of those as
	# wanted)
	visitor = OctreeVisitorExample.new

	# execute visitor
	octree.visit?( visitor )

end




# run
main
