#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'
require 'OctreeAuxiliary'




module Hxa7241_Graphics


private


# Base for implementing Octree nodes, in a Composite pattern.
#
# Currently empty...
#
class OctreeCell

#-- commands to implement
	# insertItem!( octreeData, item )
	# removeItem!( maxItemsPerCell, itemCount, item )

#-- queries to implement
	# visit?( octreeData, visitor )
	# getInfo?( info )

end




def Hxa7241_Graphics.insertItem_( octreeCell, octreeData, item )

	# either forward to current cell, or make a new leaf
	if octreeCell
		octreeCell.insertItem!( octreeData, item )
	else
		OctreeLeaf.new.insertItem!( octreeData, item )
	end

end




# Inner node octree cell.
#
# Stores eight child cells.
#
# Subcell numbering:
#    y z           110 111
#    |/   010 011  100 101
#     -x  000 001
#
# ===invariants
# * subCells is an Array (owned), length 8, of #OctreeCell derived or nil
#
class OctreeBranch < OctreeCell

	# ===parameters options:
	# * #OctreeData, Array items
	# * #OctreeBranch (copy)
	# * none (default)
	#
	def initialize( *args )

		# specify
		if 2 == args.length &&
		   args[0].kind_of?(OctreeData) &&
		   args[1].kind_of?(Array)
			octreeData, items = args

			@subCells = Array.new( 8 )

			# insert items
			items.each do |item|
				insertItem!( octreeData, item )
			end

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(OctreeBranch)
			other = args[0]

			@subCells = other.subCells.collect do |subCell|
				Hxa7241.copy?( subCell )
			end

		# default
		elsif args.empty?
			@subCells = Array.new( 8 )

		else
			throw "invalid arguments"

		end

	end


	attr_reader :subCells
	protected   :subCells


#-- commands -------------------------------------------------------------------

	# ===return
	# a replacement object for itself (always self)
	#
	def insertItem!( octreeData, item )

		# get subcell-item overlaps flags
		bound    = octreeData.bound
		overlaps = item.getSubcellOverlaps?( bound.positionOfLowerCorner,
		                               bound.center, bound.positionOfUpperCorner )

		# loop through sub cells
		8.times do |i|

			# check if sub cell is overlapped by item
			if 0 != (overlaps >> i) & 1
				# make sub cell data
				subCellData = OctreeData.new( octreeData, i )

				# add item to sub cell
				@subCells[i] = Hxa7241_Graphics::insertItem_( @subCells[i],
				                                              subCellData, item )
			end

		end

		# always return self, since branchs cannot morph on insertion
		self

	end


	# ===return
	# a replacement object for itself (self, or new Leaf, or nil)
	#
	def removeItem!( maxItemsPerCell, itemCount, item )

		branchItemCount = [0]

		# remove from non-nil sub cells
		8.times do |i|
			if @subCells[i]
				@subCells[i] = @subCells[i].removeItem!( maxItemsPerCell,
				                                         branchItemCount, item )
			end
		end

		itemCount[0] += branchItemCount[0]

		# decide whether to collapse this branch
		if branchItemCount[0] > 0

			# collapse to leaf
			if branchItemCount[0] <= maxItemsPerCell
				# all subcells *will* be leafs!
				# because:
				# a) if a branch has below it less item refs than the threshold,
				#    it collapses to a leaf (this method!)
				# b) the total of item refs below this branch in the tree is less
				#    than the threshold
				# c) therefore the number of item refs in any branch below this
				#    cell will be less than the threshold
				# d) branchs below this cell will be collapsed before this branch,
				#    because the recursive 'removeItem' call is before the
				#    collapsing code
				# so: if this branch will collapse to a leaf, then all its sub
				# branchs (direct and indirect) will collapse to leafs, and that
				# will happen before this branch.
				leaf = OctreeLeaf.new( @subCells.compact )

			# dont collapse
			else
				self

			end
		end

	end


#-- queries --------------------------------------------------------------------

	def visit?( octreeData, visitor )

		visitor.visitBranch!( octreeData, @subCells )

	end


	def getInfo?( info )

		# most of info is just passed through to subcells, but the
		# 'depthLargest' property must be set to the maximum found in
		# the subcells

		thisDepth    = info['depthLargest'] + 1
		depthLargest = thisDepth

		@subCells.compact.each do |subCell|
			info['depthLargest'] = thisDepth
			subCell.getInfo?( info )

			if depthLargest < info['depthLargest']
				depthLargest = info['depthLargest']
			end
		end

		info['depthLargest'] = depthLargest

		info

	end

end




# Outer node octree cell.
#
# Stores item references.
#
# ===invariants
# * items is a Array (owned), of item objects
#
class OctreeLeaf < OctreeCell

	# ===parameters options:
	# * Array of #OctreeLeaf (copy plural)
	# * #OctreeLeaf (copy)
	# * none (default)
	#
	def initialize( *args )

		# copy plural
		if 1 == args.length &&
		   args[0].kind_of?(Array)
			others = args[0]

			@items = Array.new
			others.each do |other|
				throw "invalid arguments" unless other.kind_of?(OctreeLeaf)

				@items.concat( other.items )
			end

		# copy
		elsif 1 == args.length &&
		   args[0].kind_of?(OctreeLeaf)
			other = args[0]

			@items = other.items.clone

		# default
		elsif args.empty?
			@items = Array.new

		else
			throw "invalid arguments"

		end

	end


	attr_reader :items
	protected   :items


#-- commands -------------------------------------------------------------------

	# ===return
	# a replacement object for itself (self, or new #OctreeBranch)
	#
	def insertItem!( octreeData, item )

		# only insert if item not already present
		unless @items.include?( item )

			# check if leaf should be subdivided
			unless octreeData.isSubdivide?( @items.length + 1 )
				# append item to collection
				@items.push( item )

				self
			else
				# subdivide by making branch and adding items to it
				OctreeBranch.new( octreeData, @items + [item] )
			end

		else

			self

		end

	end


	# ===return
	# a replacement object for itself (self, or nil)
	#
	def removeItem!( maxItemsPerCell, itemCount, item )

		# remove
		@items.delete( item )

		itemCount[0] += @items.length

		# check if leaf is now empty, so this leaf can be garbaged
		@items.empty? ? nil : self

	end


#-- queries --------------------------------------------------------------------

	def visit?( octreeData, visitor )

		visitor.visitLeaf!( octreeData, @items )

	end


	def getInfo?( info )

		info['leafCount']    += 1
		info['itemRefCount'] += @items.length
		info['depthLargest'] += 1

		info

	end

end


end # module Hxa7241_Graphics
