#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'
require 'Octree'




module Hxa7241_Graphics


# Visitor to stream out an octree into human-readable text.
#
class OctreeVisitorStreamOut

	# @parameters options:
	# * IO: target out-stream
	# * boolean: long format
	#
	def initialize( *args )

		@ostream      = args[0]
		@isLongFormat = args[1] ? true : false

		@octreeCell = nil
		@indent     = 0

	end


#-- commands -------------------------------------------------------------------

	# ===parameters
	# * octreeData: #OctreeData
	# * octreeCell: #OctreeCell/#OctreeBranch/#OctreeLeaf
	#
	def visitRoot!( octreeData, octreeRoot )

		info = { 'leafCount'    => 0,
		         'itemRefCount' => 0,
		         'depthLargest' => 0 }
		octreeRoot.getInfo?( info ) if octreeRoot


		dimensions = octreeData.dimensions
		@ostream << "\nOctree " <<
		            "\nposition: "        << dimensions.positionOfLowerCorner <<
		            "  size: "            << sprintf( "%g", dimensions.size ) <<
		            "  maxItemsPerCell: " << dimensions.maxItemsPerCell       <<
		            "  maxLevelCount: "   << dimensions.maxLevelCount         <<
		            "\n(leafs: "          << info['leafCount']                <<
		            ", items: "           << info['itemRefCount']             <<
		            ", depth: "           << info['depthLargest']             <<
		            ")\n{ "

		if octreeRoot
			# continue visit traversal
			@octreeCell = octreeRoot
			@indent     = 1
			octreeRoot.visit?( octreeData, self )
		else
			@ostream << 'empty '
		end

		@ostream << "}\n"

	end


	# ===parameters
	# * octreeData #OctreeData
	# * subCells: Array, length 8, of #OctreeCell/#OctreeBranch/#OctreeLeaf or
	#   nil
	#
	def visitBranch!( octreeData, subCells )

		OctreeVisitorStreamOut.writeDataAndInfo( @octreeCell, octreeData,
		                                         @ostream )

		# step through subcells
		8.times do |i|
			@ostream << "\n" << ("\t" * @indent)
			@ostream << '['  << i << ' '

			subCell = subCells[i]
			if subCell
				@octreeCell = subCell
				@indent    += 1

				# continue visit traversal
				subCellData = OctreeData.new( octreeData, i )
				subCell.visit?( subCellData, self )

				@indent -= 1
			else
				@ostream << 'empty '
			end

			@ostream << '] '
		end

		@ostream << "\n" << ("\t" * (@indent-1))

	end


	# ===parameters
	# * octreeData #OctreeData
	# * items: Array, of items
	#
	def visitLeaf!( octreeData, items )

		OctreeVisitorStreamOut.writeDataAndInfo( @octreeCell, octreeData,
		                                         @ostream )

		@ostream << "\n" << ("\t" * @indent)

		if @isLongFormat
			@ostream << "<"

			items.each do |item|
				@ostream << "\n" << ("\t" * (@indent+1))
				@ostream << "id:" << item.object_id << ": " << item
			end

			@ostream << "\n" << ("\t" * (@indent)) << '>'
			@ostream << "\n" << ("\t" * (@indent-1))
		else
			items.each do |item|
				@ostream << '<' << "id:" << item.object_id << ": " << item << '> '
			end
		end

	end


#-- implementation -------------------------------------------------------------
protected

	def OctreeVisitorStreamOut.writeDataAndInfo( octreeCell, octreeData, ostream)

		# do octreeData
		ostream << 'level(' << octreeData.level                      << ') lo'  <<
		        octreeData.bound.positionOfLowerCorner               << ' hi'   <<
		        octreeData.bound.positionOfUpperCorner               << ' ctr'  <<
		        octreeData.bound.center                              << ' sph(' <<
		        sprintf( "%g", octreeData.bound.circumSphereRadius ) << ')  '

		# do info
		info = { 'leafCount'    => 0,
					'itemRefCount' => 0,
					'depthLargest' => 0 }
		octreeCell.getInfo?( info )

		ostream << '(leafs: '  << info['leafCount']    <<
					  ', items: ' << info['itemRefCount'] <<
					  ', depth: ' << info['depthLargest'] << ')  '

	end

end


end # module Hxa7241_Graphics
