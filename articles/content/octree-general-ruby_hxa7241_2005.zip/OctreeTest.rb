#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Octree'
require 'OctreeStreamOut'




module Hxa7241_Graphics


private


# An axis-aligned box, for octree testing.
#
# Also, an example of how to write an item for use with Octree.
#
class OctreeItemTest

	# ===parameter options:
	# * #Vector3fc position
	# * #Vector3fc dimension (optional, defaults to zero)
	# * Object payload/data (optional)
	#
	def initialize( *args )

		@position  = args[0]
		@dimension = args[1] ? args[1].abs? : Vector3fc::ZERO

		@payload   = args[2]

	end


#-- queries --------------------------------------------------------------------
#-- octree required methods

	# ===parameters
	# * cellLowerCorner: #Vector3fc
	# * CellUpperCorner: #Vector3fc
	#
	def isOverlappingCell?( cellLowerCorner, cellUpperCorner )

		OctreeItemTest.isOverlapping?( @position, @position + @dimension,
		                               cellLowerCorner, cellUpperCorner )

	end


	# ===parameters
	# * cellsLowerPos: #Vector3fc
	# * cellsMiddlePos: #Vector3fc
	# * cellsUpperPos:  #Vector3fc
	#
	# ===return
	# An integer containing eight bit flags showing which subcell is
	# overlapped.
	# Subcell numbering:
	#    y z           110 111
	#    |/   010 011  100 101
	#     -x  000 001
	# eg: subcell (high x, high y, low z) is number 3, and flagged in bit 3
	#
	def getSubcellOverlaps?( cellsLowerPos, cellsMiddlePos, cellsUpperPos )

		flags = 0

		lowMidPoints  = [ cellsLowerPos, cellsMiddlePos ]
		midHighPoints = [ cellsMiddlePos, cellsUpperPos ]

		8.times do |i|
			lowerCorner = Vector3fc.new(  lowMidPoints[ i       & 1].x,
			                              lowMidPoints[(i >> 1) & 1].y,
			                              lowMidPoints[(i >> 2) & 1].z )
			upperCorner = Vector3fc.new( midHighPoints[ i       & 1].x,
			                             midHighPoints[(i >> 1) & 1].y,
			                             midHighPoints[(i >> 2) & 1].z )
			flags |= (isOverlappingCell?( lowerCorner, upperCorner ) ? 1 : 0) << i
		end

		flags

	end


#-- not octree required methods

	def OctreeItemTest.isOverlapping?( itemLower, itemUpper,
	                                   cellLower, cellUpper )

		# check the two ranges overlap in every dimension
		Vector3fc::ONE == (itemLower < cellUpper) &&
		Vector3fc::ONE == (itemUpper > cellLower)

	end


	def to_s
		"{#{@position} #{@dimension}}"
	end


	def lowerCorner
		@position
	end


	def upperCorner
		@position + @dimension
	end


	attr_reader :payload

end




# A simple traversal inspection, for octree testing.
#
# Also, an example of how to write a visitor for use with Octree.
#
class OctreeVisitorTest

	def initialize( octree )

		# to record object_ids of octree structural objects
		@ids = Array.new
		@ids << octree.object_id

		# to record, for each leaf, its OctreeData and items Array
		@leafs = Array.new

	end


#-- commands -------------------------------------------------------------------
#-- octree required methods

	def visitRoot!( octreeData, octreeRoot )

		if octreeRoot
			@ids << octreeRoot.object_id

			octreeRoot.visit?( octreeData, self )
		end

	end


	def visitBranch!( octreeData, subCells )

		@ids << subCells.object_id

		# step through subcells
		8.times do |i|

			subCell = subCells[i]
			if subCell
				@ids << subCell.object_id

				# continue visit traversal
				subCellData = OctreeData.new( octreeData, i )
				subCell.visit?( subCellData, self )
			end

		end

	end


	def visitLeaf!( octreeData, items )

		@ids << items.object_id

		@leafs.push( [octreeData, items.clone] )

	end


#-- queries --------------------------------------------------------------------
#-- not octree required methods

	attr_reader :ids,
	            :leafs

end




class Octree

	def Octree.preTest

		position  = Vector3fc.new( 0 )
		size      = 5
		maxItems  = 1
		maxLevels = 4

		o1 = Octree.new( position, size, maxItems, maxLevels )

		o1.insertItem!( OctreeItemTest.new( Vector3fc.new( 1, 1, 1 ) ) )
		o1.insertItem!( OctreeItemTest.new( Vector3fc.new( 3, 3, 3 ) ) )
		o1.insertItem!( OctreeItemTest.new( Vector3fc.new( 4, 4, 4 ) ) )

		#o1.streamOut?( $defout )
		#$defout << "\n"

		vso = OctreeVisitorStreamOut.new( $defout, true )
		o1.visit?( vso )

		nil

	end


	# ===return
	# true for succeeded, false for failed
	#
	def Octree.test( outstream=nil, verbose=false, seed=0 )

		seed = rand(2**31) if 0 == seed

		testConstruction(outstream, verbose, seed) &&
		testCommands(outstream, verbose, seed)

#		testConstruction(outstream, 1600267359)

	end


	def Octree.testConstruction( outstream=nil, verbose=false, seed=0 )

		# Copying:
		#
		# Generate some random octrees. Copy each and check it is identical to
		# its original in value, and check all octree object ids are different.

		isOk = true

		random = RandomSimpleCpp.new( seed )
		outstream << "\nseed= #{random.getDword?}\n" if outstream

		# loop
		10.times do |i|
			o1 = makeRandomFilledOctree( random, 30 )['octree']

			if outstream && verbose
				vso = OctreeVisitorStreamOut.new( outstream, true )
				o1.visit?( vso )
				outstream << "\n"
			end

			# make copy octree
			o2 = Octree.new( o1 )

			# stream out each to array
			a1 = Array.new
			v1 = OctreeVisitorStreamOut.new( a1 )
			o1.visit?( v1 )
			a2 = Array.new
			v2 = OctreeVisitorStreamOut.new( a2 )
			o2.visit?( v2 )

			# compare arrays
			isOk &= a1 == a2

			# make arrays of octree object ids
			v1 = OctreeVisitorTest.new( o1 )
			o1.visit?( v1 )
			v2 = OctreeVisitorTest.new( o2 )
			o2.visit?( v2 )

			isOk &= v1.ids.length == v2.ids.length
			# check set intersection of ids is empty
			isOk &= (v1.ids & v2.ids).empty?

			outstream << "#{i} #{isOk}\n" if outstream
		end

		outstream << "\n--- testConstruction: #{isOk}\n" if outstream

		isOk

	end


	def Octree.testCommands( outstream=nil, verbose=false, seed=0 )

		testCommands1(outstream, verbose, seed) &&
		testCommands2(outstream, verbose, seed) &&
		testCommands3(outstream, verbose, seed)

	end


	def Octree.testCommands1( outstream=nil, verbose=false, seed=0 )

		# simple structural test:
		#
		# 1) make octree with four item per leaf limit
		# 2) add an item in each octant
		# 3) check each item is in the correct octant

		isOk = true

		outstream << "\n\n" if outstream

		# make octree
		o1 = Octree.new( Vector3fc::ZERO, 2, 4, 4 )

		# add item in each octant
		8.times do |i|
			position = Vector3fc.new( (i & 1).to_f        + 0.25,
			                          ((i >> 1) & 1).to_f + 0.25,
			                          ((i >> 2) & 1).to_f + 0.25 )
			item = OctreeItemTest.new( position, Vector3fc.new(0.5), i )
			o1.insertItem!( item )

			outstream << "item #{i} :  #{item}\n" if outstream && verbose
		end
		outstream << "\n" if outstream && verbose

		if outstream && verbose
			vso = OctreeVisitorStreamOut.new( outstream, true )
			o1.visit?( vso )
			outstream << "\n"
		end

		# make info from octree
		v1 = OctreeVisitorTest.new( o1 )
		o1.visit?( v1 )

		v1.leafs.each do |leaf|
			cellLower = leaf[0].bound.positionOfLowerCorner
			cellUpper = leaf[0].bound.positionOfUpperCorner

			leaf[1].each do |item|
				itemLower = item.lowerCorner
				itemUpper = item.upperCorner

				# check item is overlapping its leaf cell
				is = OctreeItemTest.isOverlapping?( itemLower, itemUpper,
				                                    cellLower, cellUpper )
				isOk &= is
				outstream << "overlap #{is} :  #{itemLower}  #{itemUpper}  " <<
				             "#{cellLower}  #{cellUpper}\n" if outstream && verbose

				# check item is in correct leaf cell
				octantIndex = item.payload
				octantLower = Vector3fc.new( octantIndex & 1,
				                             (octantIndex >> 1) & 1,
				                             (octantIndex >> 2) & 1 )
				octantUpper = octantLower + Vector3fc::ONE
				isOk &= cellLower == octantLower
				isOk &= cellUpper == octantUpper

				if outstream
					if verbose
						outstream << "\toctant match #{(cellLower == octantLower)}" <<
						             " :  #{cellLower}  #{octantLower}\n"
						outstream << "\toctant match #{(cellUpper == octantUpper)}" <<
						             " :  #{cellUpper}  #{octantUpper}\n"
					else
						outstream << isOk << "\n"
					end
				end
			end
		end

		outstream << "\n--- testCommands1: #{isOk}\n" if outstream

		isOk

	end


	def Octree.testCommands2( outstream=nil, verbose=false, seed=0 )

		# basic insert/remove test:
		#
		# insert a lot, visit to collect all items, check they are all there
		# remove them all, get counts to check they all came out

		isOk = true

		outstream << "\n\n" if outstream

		random = RandomSimpleCpp.new( seed )
		outstream << "\nseed= #{random.getDword?}\n\n" if outstream

		10.times do |j|
			# make octree with items
			a = makeRandomFilledOctree( random, 100 )
			o1 = a['octree']
			i1 = a['items']

			#o1.visit?( OctreeVisitorStreamOut.new( outstream, true )
			#         ) if outstream
			#outstream << "\n#{i1}\n" if outstream

			# collect leafs items
			v1 = OctreeVisitorTest.new( o1 )
			o1.visit?( v1 )

			info = o1.getInfo?

			# check collection length equals info leaf count
			isOk &= v1.leafs.length == info['leafCount']

			# compare items list to leafs collection
			i2 = v1.leafs.collect do |i| i[1] end.flatten.uniq
			i2s = i2.collect do |i| i.object_id end
			i1s = i1.collect do |i| i.object_id end
			isOk &= (i2s.sort == i1s.sort)
			#common = i2 & i1
			#isOk &= (common.length == i2.length)
			#isOk &= (common.length == i1.length)

			# remove items
			i1.each do |i|
				o1.removeItem!( i )

				#o1.visit?( OctreeVisitorStreamOut.new( outstream, true )
				#         ) if outstream
			end

			# check octree info data is all 'zero'
			info = o1.getInfo?
			isOk &= info['leafCount'] == 0
			isOk &= info['itemRefCount'] == 0
			isOk &= info['depthLargest'] == 0
			isOk &= o1.isEmpty?

			outstream << "#{j} #{isOk}\n" if outstream
		end


		outstream << "\n--- testCommands2: #{isOk}\n" if outstream

		isOk

	end


	def Octree.testCommands3( outstream=nil, verbose=false, seed=0 )

		isOk = true

		# Structural conformance postconditions:
		#
		# Randomly insert and remove many random points, one at a time.
		# After each command, check structure of octree:
		# * after insertion, the octree is:
		#    * same, or
		#    * one leaf holding one more item, or
		#    * one leaf has changed to a branch containing 1-8 leafs and 0-7
		#      nils
		#    * one leaf has changed to 0-n levels of branchs of one subcell,
		#      and either 2-8 leafs, or one leaf at max level
		# * after removal, the octree is:
		#    * same, or
		#    * one leaf holding one less item, or
		#    * one leaf has changed to nil, or
		#    * eight leafs have disappeared, and their direct parent branch has
		#      changed to a leaf, or
		#    * one leaf has disappeared, one of its parent branchs has changed
		#      to nil, and any branchs between have disappeared

#		outstream << "\n\n" if outstream
#
#		random = RandomSimpleCpp.new( seed )
#		outstream << "\nseed= #{random.getDword?}\n" if outstream


#		outstream << "\n--- testCommands3: #{isOk}\n" if outstream

		isOk

	end


#-------------------------------------------------------------------------------
private

	class RandomSimpleCpp

		def initialize( *args )

			# specify
			if 1 == args.length &&
				args[0].kind_of?(Integer)

				@random = args[0]

			# copy
			elsif 1 == args.length &&
				args[0].kind_of?(RandomSimpleCpp)

				@random = args[0].random

			# default
			else
				@random = 0

			end

		end


	#-- commands ----------------------------------------------------------------
		def setSeed!( seed )
			@random = seed if seed.kind_of?(Integer)

			self
		end


		def next!
			@random = (((1664525 * @random) & 0xFFFFFFFF) + 1013904223)& 0xFFFFFFFF

			self
		end


	#-- queries -----------------------------------------------------------------
		def getDword?
			@random >= 0x80000000 ? @random - 0x100000000 : @random
		end


		def getUdword?
			@random
		end


		def getFloat?( scale = 1.0, displace = 0.0 )
			#dword itemp = dword(0x3F800000) | (dword(0x007FFFFF) & random_m);
			#return *(reinterpret_cast<float*>(&itemp)) - 1.0f;

			((0x007FFFFF & @random).to_f / 8388608.0) * scale + displace
		end

	end


	def Octree.makeRandomFilledOctree( random, howManyItems )

		o1    = makeRandomOctree( random )
		items = makeRandomItems( random, howManyItems, o1.position, o1.size )

		items.each do |i|
			o1.insertItem!( i )
		end

		{ 'octree' => o1,
		  'items'  => items }

	end


	def Octree.makeRandomOctree( random )

		# position: random between -/+100
		position = Vector3fc.new( random.next!.getFloat?(200, -100),
		                          random.next!.getFloat?(200, -100),
		                          random.next!.getFloat?(200, -100) )

		# size: random between 0.5 and 50
		size = random.next!.getFloat?(49.5, 0.5)

		# max items: random between 1 and 8
		maxItems = (random.next!.getUdword? >> 29) + 1

		# max levels: random between bounds
		maxLevels = (random.next!.getUdword? >> 30) + 3

		# construct
		Octree.new( position, size, maxItems, maxLevels )

	end


	def Octree.makeRandomItems( random, howMany, position, size )

		items = Array.new

		howMany.times do |j|
			# make random item
			itemPosition = Vector3fc.new(random.next!.getFloat?,
			                             random.next!.getFloat?,
			                             random.next!.getFloat?) * (size * 0.99) +
								Vector3fc.new(size * 0.005) + position
			item = if random.next!.getDword? >= 0
				OctreeItemTest.new( itemPosition )
			else
				dimensions = (Vector3fc.new(random.next!.getFloat?,
				                            random.next!.getFloat?,
				                            random.next!.getFloat?) * 0.175 +
								 Vector3fc.new(0.025)) * (size / 3)
				OctreeItemTest.new( itemPosition, dimensions )
			end

			# add item
			items.push( item )
		end

		items

	end

end


end # module Hxa7241_Graphics








#-- main #######################################################################

BEGIN {
	$:.push( File.dirname( $0 ) )
}


def main

	isVerbose = ('true'.eql?( $*[0] )) ? true : false
	seed      = $*[1] ? $*[1].to_i : 0

	isOk = Hxa7241_Graphics::Octree.test( $defout, isVerbose, seed )

	puts "\n\n#{(isOk ? "---" : "***")} test_Octree: #{isOk}"

	!isOk

end


main
