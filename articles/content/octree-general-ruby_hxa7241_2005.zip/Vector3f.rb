#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'
require 'Vector3fc'




module Hxa7241_Graphics


# A subclass of non-constant methods for a 3D vector of Floats.
#
# 'unrolled' code.
# Adapted from the HXA7241 C++ version.
#
# ===see
# #Vector3fc
#
# ===invariants
# * x, y, z are Floats
#
class Vector3f < Vector3fc

	def initialize( *args )
		super
	end


#-- commands -------------------------------------------------------------------

	def set!( *args )
		super
	end


	def x=( v )
		@x = v.to_f
	end


	def y=( v )
		@y = v.to_f
	end


	def z=( v )
		@z = v.to_f
	end


	def []=( index, value )
		case index.abs.modulo( 3 )
			when 0 then @x = value.to_f
			when 1 then @y = value.to_f
			when 2 then @z = value.to_f
		end
	end


	def each!
		@x = yield( @x ).to_f
		@y = yield( @y ).to_f
		@z = yield( @z ).to_f
	end


#-- arithmetic producing vectors
#-- (unary then binary)

	def negative!
		@x = -@x
		@y = -@y
		@z = -@z

		self
	end


	def abs!
		@x = -@x if @x < 0.0
		@y = -@y if @y < 0.0
		@z = -@z if @z < 0.0

		self
	end


	def unitized!
		length = Math.sqrt( (@x * @x) +
		                    (@y * @y) +
		                    (@z * @z) )
		oneOverLength = length != 0.0 ? 1.0 / length : 0.0

		@x *= oneOverLength
		@y *= oneOverLength
		@z *= oneOverLength

		self
	end


	def cross!( v3f )
		@x, @y, @z = (@y * v3f.z) - (@z * v3f.y),
		             (@z * v3f.x) - (@x * v3f.z),
		             (@x * v3f.y) - (@y * v3f.x)

		self
	end


	def plus!( v3f )
		@x += v3f.x
		@y += v3f.y
		@z += v3f.z

		self
	end


	def minus!( v3f )
		@x -= v3f.x
		@y -= v3f.y
		@z -= v3f.z

		self
	end


	def multiply!( arg )
		if arg.kind_of?( Numeric )
			@x *= arg.to_f
			@y *= arg.to_f
			@z *= arg.to_f
		else
			@x *= arg.x
			@y *= arg.y
			@z *= arg.z
		end

		self
	end


	def divide!( arg )
		if arg.kind_of?( Numeric )
			oneOverArg = 1.0 / arg.to_f
			@x *= oneOverArg
			@y *= oneOverArg
			@z *= oneOverArg
		else
			@x /= arg.x
			@y /= arg.y
			@z /= arg.z
		end

		self
	end


	def clampToMinOf!( v3f )
		@x = v3f.x if @x < v3f.x
		@y = v3f.y if @y < v3f.y
		@z = v3f.z if @z < v3f.z

		self
	end


	def clampToMaxOf!( v3f )
		@x = v3f.x if @x > v3f.x
		@y = v3f.y if @y > v3f.y
		@z = v3f.z if @z > v3f.z

		self
	end


	def clampBetween!( min, max )
		if    @x < min.x then @x = min.x
		elsif @x > max.x then @x = max.x
		end

		if    @y < min.y then @y = min.y
		elsif @y > max.y then @y = max.y
		end

		if    @z < min.z then @z = min.z
		elsif @z > max.z then @z = max.z
		end

		self
	end


	# 0 to almost 1, ie: [0,1).
	#
	def clamp01!
		if    @x <  0.0 then @x = 0.0
		elsif @x >= 1.0 then @x = Hxa7241::FLOAT_ALMOST_ONE
		end

		if    @y <  0.0 then @y = 0.0
		elsif @y >= 1.0 then @y = Hxa7241::FLOAT_ALMOST_ONE
		end

		if    @z <  0.0 then @z = 0.0
		elsif @z >= 1.0 then @z = Hxa7241::FLOAT_ALMOST_ONE
		end

		self
	end

end




class Vector3f
#-- test -----------------------------------------------------------------------

	def Vector3f.test
		testCommands
	end


	def Vector3f.testCommands
		isOk = true

		# =, []=, each!
		v = Vector3f.new
		v.x = 1;  v.y = 2;  v.z = 3.3
		isOk &= (v.x == 1.0 && v.y == 2.0 && v.z == 3.3)
		v = Vector3f.new
		v[0] = 1;  v[1] = 2;  v[2] = 3.3
		isOk &= (v.x == 1.0 && v.y == 2.0 && v.z == 3.3)
		v = Vector3f.new( 1, 2, 3 )
		c = 10
		v.each! do |e|
			e + (c += 1)
		end
		isOk &= (v.x == 12.0 && v.y == 14.0 && v.z == 16.0)

		# set!
		v = Vector3f.new
		v.set!( Vector3f.new( 4, 44, 444 ) )
		isOk &= v.to_a == [4.0, 44.0, 444.0]
		v.set!( 1.1 )
		isOk &= v.to_a == [1.1, 1.1, 1.1]
		v.set!( 1, 22.2, 333 )
		isOk &= v.to_a == [1.0, 22.2, 333.0]
		v.set!( -1, -2 )
		isOk &= v.to_a == [-1.0, -2.0, 0.0]
		v.set!( -11, -22, -33, -44 )
		isOk &= v.to_a == [-11.0, -22.0, -33.0]
		v.set!( [44.4] )
		isOk &= v.to_a == [44.4, 44.4, 44.4]
		v.set!( [5, 66.6, 777] )
		isOk &= v.to_a == [5.0, 66.6, 777.0]
		v.set!( [-44, -55] )
		isOk &= v.to_a == [-44.0, -55.0, 0.0]
		v.set!( [-444, -555, -666, -777] )
		isOk &= v.to_a == [-444.0, -555.0, -666.0]

		# negative!, abs!, unitized!, cross!
		v1 = Vector3f.new( 1, -2, 30.7 )
		v2 = v1.negative!
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( -1, 2, -30.7 )
		v1 = Vector3f.new( 1, -2, 30.7 )
		v2 = v1.abs!
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( 1, 2, 30.7 )
		v1 = Vector3f.new( -1, 2, -30.7 )
		v2 = v1.unitized!
		isOk &= (v1.object_id == v2.object_id) && ((v1.x - -0.0324872299523).abs < 1e-12) && ((v1.y - 0.06497445990464).abs < 1e-12) && ((v1.z - -0.9973579595362).abs < 1e-12)
		v1 = Vector3f.new( Vector3f::X )
		v2 = v1.cross!( Vector3f::Y )
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f::Z

		# plus!, minus!, multiply!, divide!
		v1 = Vector3f.new(Vector3f::X)
		v2 = v1.plus!(Vector3f::Y).plus!(Vector3f::Z)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f::ONE
		v1 = Vector3f.new(Vector3f::ONE)
		v2 = v1.minus!(Vector3f::X).minus!(Vector3f::Y).minus!(Vector3f::Z)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f::ZERO
		v1 = Vector3f.new(Vector3f::HALF)
		v2 = v1.multiply!(2)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f::ONE
		v1 = Vector3f.new(Vector3f::ONE)
		v2 = v1.divide!(2)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f::HALF
		v1 = Vector3f.new( -1, 2, -30.7 )
		v2 = v1.multiply!(Vector3f::ONE * 2)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( -2, 4, -61.4 )
		v1 = Vector3f.new( -1, 2, -30.7 )
		v2 = v1.divide!(Vector3f::HALF)
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( -2, 4, -61.4 )

		# clampToMinOf!, clampToMaxOf!, clampBetween!, clamp01!
		v1 = Vector3f.new(Vector3f::ZERO)
		v2 = v1.clampToMinOf!(Vector3f.new(1,2,3))
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new(1,2,3)
		v1 = Vector3f.new( -1, 2, -30.7 )
		v2 = v1.clampToMinOf!(Vector3f.new(-1,-2,-3))
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( -1, 2, -3 )
		v1 = Vector3f.new(Vector3f::ONE)
		v2 = v1.clampToMaxOf!(Vector3f.new(-1,-2,-3))
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new(-1,-2,-3)
		v1 = Vector3f.new( -1, 2, -30.7 )
		v2 = v1.clampToMaxOf!(Vector3f.new(-1,-2,-3))
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( -1, -2, -30.7 )
		v1 = Vector3f.new( -1, 2, 30.7 )
		v2 = v1.clampBetween!( Vector3f::HALF, Vector3f.new(10,11,26) )
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new( 0.5, 2, 26 )
		v1 = Vector3f.new(-1, 0.5, 3)
		v2 = v1.clamp01!
		isOk &= (v1.object_id == v2.object_id) && v1 == Vector3f.new(0, 0.5, Hxa7241::FLOAT_ALMOST_ONE)

		isOk
	end

end


end # module Hxa7241_Graphics
