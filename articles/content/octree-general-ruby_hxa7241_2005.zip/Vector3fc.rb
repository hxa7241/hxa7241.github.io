#--------------------------------------------------------------------#
#                                                                    #
#  Octree component, version 2.0                                     #
#  Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.            #
#                                                                    #
#  http://www.hxa7241.org/                                           #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
# Copyright (c) 2004-2005, Harrison Ainsworth / HXA7241.             #
#                                                                    #
# Permission is hereby granted, free of charge, to any person        #
# obtaining a copy of this software and associated documentation     #
# files (the "Software"), to deal in the Software without            #
# restriction, including without limitation the rights to use, copy, #
# modify, merge, publish, distribute, and/or sell copies of the      #
# Software, and to permit persons to whom the Software is furnished  #
# to do so, provided that the above copyright notice(s) and this     #
# permission notice appear in all copies of the Software and that    #
# both the above copyright notice(s) and this permission notice      #
# appear in supporting documentation.                                #
#                                                                    #
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,    #
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES    #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND           #
# NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE       #
# COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR  #
# ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR    #
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR         #
# PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER     #
# TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR   #
# PERFORMANCE OF THIS SOFTWARE.                                      #
#                                                                    #
# Except as contained in this notice, the name of a copyright holder #
# shall not be used in advertising or otherwise to promote the sale, #
# use or other dealings in this Software without prior written       #
# authorization of the copyright holder.                             #
#                                                                    #
#--------------------------------------------------------------------#




require 'Hxa7241_General'




module Hxa7241_Graphics


# A constant 3D vector of Floats.
#
# 'unrolled' code.
# Adapted from the HXA7241 C++ version.
#
# ===invariants
# * x, y, z are Floats
#
class Vector3fc

	def initialize( *args )
		set!( *args )
	end


	def set!( *args )
		# default construction
		if args.empty?
			@x = @y = @z = 0.0

		# copy construction
		elsif args[0].kind_of?( Vector3fc )
			@x = args[0].x
			@y = args[0].y
			@z = args[0].z

		# conversion construction
		else
			args = args[0] if args[0].kind_of?( Array )

			# duplicate single argument
			if 1 == args.length
				@x = @y = @z = args[0].to_f
			# copy multiple arguments
			else
				@x = args[0].to_f
				@y = args[1].to_f
				@z = args[2].to_f
			end
		end

		self
	end

	private :set!


#-- queries --------------------------------------------------------------------

	attr_reader :x, :y, :z


#-- standard methods

	def to_a
		[@x, @y, @z]
	end


	def to_s
		sprintf( "(%g, %g, %g)", @x, @y, @z )
		#"(#{@x}, #{@y}, #{@z})"
	end


	def eql?( other )
		object_id.eql?( other.object_id ) ||
			( other.kind_of?(Vector3fc) &&
				(
					(@x == other.x) &&
					(@y == other.y) &&
					(@z == other.z)
				)
			)
	end


	def ==( other )
		self.eql?( other )
	end


	def isZero?
		(0.0 == @x) &&
		(0.0 == @y) &&
		(0.0 == @z)
	end


	def []( index )
		case index.abs.modulo( 3 )
			when 0 then @x
			when 1 then @y
			when 2 then @z
		end
	end


	def each?
		yield @x
		yield @y
		yield @z
	end


#-- arithmetic producing reals
#-- (unary then binary)

	def sum?
		@x + @y + @z
	end


	def average?
		(@x + @y + @z) / 3
	end


	def smallest?
		s = @x <= @y ? @x : @y
		s <= @z ? s : @z
	end


	def largest?
		l = @x >= @y ? @x : @y
		l >= @z ? l : @z
	end


	def length?
		Math.sqrt( (@x * @x) +
		           (@y * @y) +
		           (@z * @z) )
	end


	def distance?( v3f )
		xDif = @x - v3f.x
		yDif = @y - v3f.y
		zDif = @z - v3f.z

		Math.sqrt( (xDif * xDif) +
		           (yDif * yDif) +
		           (zDif * zDif) )
	end


	def dot?( v3f )
		(@x * v3f.x) +
		(@y * v3f.y) +
		(@z * v3f.z)
	end


#-- arithmetic producing vectors
#-- (unary then binary)

	def negative?
		Vector3fc.new( -@x,
		               -@y,
		               -@z )
	end


	def -@
		Vector3fc.new( -@x,
		               -@y,
		               -@z )
	end


	def abs?
		Vector3fc.new( @x >= 0.0 ? @x : -@x,
		               @y >= 0.0 ? @y : -@y,
		               @z >= 0.0 ? @z : -@z )
	end


	def unitized?
		length = Math.sqrt( (@x * @x) +
		                    (@y * @y) +
		                    (@z * @z) )
		oneOverLength = length != 0.0 ? 1.0 / length : 0.0

		Vector3fc.new( @x * oneOverLength,
		               @y * oneOverLength,
		               @z * oneOverLength )
	end


	def cross?( v3f )
		Vector3fc.new( (@y * v3f.z) - (@z * v3f.y),
		               (@z * v3f.x) - (@x * v3f.z),
		               (@x * v3f.y) - (@y * v3f.x) )
	end


	def +( v3f )
		Vector3fc.new( @x + v3f.x,
		               @y + v3f.y,
		               @z + v3f.z )
	end


	def -( v3f )
		Vector3fc.new( @x - v3f.x,
		               @y - v3f.y,
		               @z - v3f.z )
	end


	def *( arg )
		if arg.kind_of?( Numeric )
			Vector3fc.new( @x * arg.to_f,
			               @y * arg.to_f,
			               @z * arg.to_f )
		else
			Vector3fc.new( @x * arg.x,
			               @y * arg.y,
			               @z * arg.z )
		end
	end


	def /( arg )
		if arg.kind_of?( Numeric )
			oneOverArg = 1.0 / arg.to_f
			Vector3fc.new( @x * oneOverArg,
			               @y * oneOverArg,
			               @z * oneOverArg )
		else
			Vector3fc.new( @x / arg.x,
			               @y / arg.y,
			               @z / arg.z )
		end
	end


#-- logical producing vectors

	def <=>( v3f )
		Vector3fc.new( @x <=> v3f.x,
		               @y <=> v3f.y,
		               @z <=> v3f.z )
	end


	def eq?( v3f )
		Vector3fc.new( @x == v3f.x ? 1 : 0,
		               @y == v3f.y ? 1 : 0,
		               @z == v3f.z ? 1 : 0 )
	end


	def >( v3f )
		Vector3fc.new( @x > v3f.x ? 1 : 0,
		               @y > v3f.y ? 1 : 0,
		               @z > v3f.z ? 1 : 0 )
	end


	def >=( v3f )
		Vector3fc.new( @x >= v3f.x ? 1 : 0,
		               @y >= v3f.y ? 1 : 0,
		               @z >= v3f.z ? 1 : 0 )
	end


	def <( v3f )
		Vector3fc.new( @x < v3f.x ? 1 : 0,
		               @y < v3f.y ? 1 : 0,
		               @z < v3f.z ? 1 : 0 )
	end


	def <=( v3f )
		Vector3fc.new( @x <= v3f.x ? 1 : 0,
		               @y <= v3f.y ? 1 : 0,
		               @z <= v3f.z ? 1 : 0 )
	end


#-- clamps

	def clampToMinOf?( v3f )
		Vector3fc.new( @x >= v3f.x ? @x : v3f.x,
		               @y >= v3f.y ? @y : v3f.y,
		               @z >= v3f.z ? @z : v3f.z )
	end


	def clampToMaxOf?( v3f )
		Vector3fc.new( @x <= v3f.x ? @x : v3f.x,
		               @y <= v3f.y ? @y : v3f.y,
		               @z <= v3f.z ? @z : v3f.z )
	end


	def clampBetween?( min, max )
		Vector3fc.new( @x < min.x ? min.x : (@x > max.x ? max.x : @x),
		               @y < min.y ? min.y : (@y > max.y ? max.y : @y),
		               @z < min.z ? min.z : (@z > max.z ? max.z : @z) )
	end


	# 0 to almost 1, ie: [0,1).
	#
	def clamp01?
		Vector3fc.new( @x < 0.0 ? 0.0 : (@x >= 1.0 ? Hxa7241::FLOAT_ALMOST_ONE : @x),
		               @y < 0.0 ? 0.0 : (@y >= 1.0 ? Hxa7241::FLOAT_ALMOST_ONE : @y),
		               @z < 0.0 ? 0.0 : (@z >= 1.0 ? Hxa7241::FLOAT_ALMOST_ONE : @z) )
	end


#-- constants ------------------------------------------------------------------

	ZERO       = Vector3fc.new( 0 )
	HALF       = Vector3fc.new( 0.5 )
	ONE        = Vector3fc.new( 1 )
	EPSILON    = Vector3fc.new( Hxa7241::FLOAT_EPSILON )
	ALMOST_ONE = Vector3fc.new( Hxa7241::FLOAT_ALMOST_ONE )
	MIN        = Vector3fc.new( Hxa7241::FLOAT_MIN )
	MAX        = Vector3fc.new( Hxa7241::FLOAT_MAX )
	X          = Vector3fc.new( 1, 0, 0 )
	Y          = Vector3fc.new( 0, 1, 0 )
	Z          = Vector3fc.new( 0, 0, 1 )

end




class Vector3fc
#-- test -----------------------------------------------------------------------

	def Vector3fc.test
		testConstruction && testQueries
	end


	def Vector3fc.testConstruction
		examples =
		[
			Vector3fc.new,
			Vector3fc.new( -3, 571.0004, 800000000000000000000000000000000000000000000000000 ),
			Vector3fc.new( -11 ),
			Vector3fc.new( -111.1 ),
			Vector3fc.new( 1111111111111111111111111111111111111111111111111 ),
			Vector3fc.new( [22] ),
			Vector3fc.new( [3, 33.3, 3333333333333333333333333333333] ),
			Vector3fc.new( Vector3fc.new( 4, 44, 444 ) ),

			Vector3fc.new( 5, 55 ),
			Vector3fc.new( 6, 66.0, 666, 6666.0 ),
			Vector3fc.new( [7, 77.0] ),
			Vector3fc.new( [8, 88.0, 888, 8888.0] ),

			Vector3fc.new( 'aghiapsfgja' ),
			Vector3fc.new( 9, '99.0', 'aghiapsfgja' ),
			Vector3fc.new( '100.0', 10, 'aghiapsfgja' ),
			Vector3fc.new( ['dlfjlhsh'] ),
			Vector3fc.new( [11, '111.0', 'dlfjlhsh' ] ),
			Vector3fc.new( ['122.0', 12, 'dlfjlhsh' ] )
		]

		isOk = !examples.empty?
		examples.each do |eg|
			# are fields Float ?
			isOk &= eg.x.instance_of?( Float ) &&
			        eg.y.instance_of?( Float ) &&
			        eg.z.instance_of?( Float )
		end

		isOk
	end


	def Vector3fc.testQueries
		isOk = true

		# queries:

		# ==, eql, isZero?
		isOk &= Vector3fc.new( 1, -2, 30.7 ) == Vector3fc.new( 1, -2, 30.7 )
		isOk &= Vector3fc.new( 1, -2, 30.7 ) != Vector3fc::ZERO
		isOk &= Vector3fc::EPSILON == Vector3fc::EPSILON
		isOk &= !(Vector3fc::HALF == 0.5)
		isOk &= Vector3fc::ONE != "1.0"

		isOk &= Vector3fc.new( 1, -2, 30.7 ).eql?( Vector3fc.new( 1, -2, 30.7 ) )
		isOk &= !(Vector3fc.new( 1, -2, 30.7 ).eql?( Vector3fc::ZERO ))
		isOk &= Vector3fc::EPSILON.eql?( Vector3fc::EPSILON )
		isOk &= !(Vector3fc::HALF.eql?( 0.5 ))
		isOk &= !(Vector3fc::ONE.eql?( "1.0" ))

		isOk &= !(Vector3fc.new( 0, 3, 0 ).isZero?)
		isOk &= Vector3fc.new( 0, 0, 0 ).isZero?

		# to_a, [], each?
		isOk &= Vector3fc.new( 1, -2, 30.7 ).to_a == [1.0, -2.0, 30.7]
		v = Vector3fc.new( 1, -2, 30.7 )
		isOk &= (v.x == v[0] && v.y == v[1] && v.z == v[2])
		a = Array.new
		v.each? do |e|
			a.push( e )
		end
		isOk &= v.to_a == a

		# sum?, average?, smallest?, largest?
		isOk &= Vector3fc.new( 1, -2, 30.7 ).sum? == 29.7
		isOk &= Vector3fc.new( 1, -2, 30.7 ).average? == 9.9
		isOk &= Vector3fc.new( 1, -2, 30.7 ).smallest? == -2
		isOk &= Vector3fc.new( 1, -2, 30.7 ).largest? == 30.7

		# length?, distance?, dot?
		isOk &= (Vector3fc.new( 1, -2, 30.7 ).length? - 30.7813255075216).abs < 1e-12
		isOk &= (Vector3fc.new( 1, -2, 30.7 ).distance?( Vector3fc.new( -11, 24.3, -3 ) ) - 44.400225224654).abs < 1e-12
		isOk &= (Vector3fc.new( 1, -2, 30.7 ).dot?( Vector3fc.new( -3, 24.3, -11 ) ) - (-389.3)).abs < 1e-12

		# negative?, abs?, unitized?, cross?
		isOk &= Vector3fc.new( 1, -2, 30.7 ).negative? == Vector3fc.new( -1, 2, -30.7 )
		isOk &= Vector3fc.new( -1, 2, -30.7 ).abs? == Vector3fc.new( 1, 2, 30.7 )
		v = Vector3fc.new( -1, 2, -30.7 ).unitized?
		isOk &= ((v.x - -0.0324872299523).abs < 1e-12) && ((v.y - 0.06497445990464).abs < 1e-12) && ((v.z - -0.9973579595362).abs < 1e-12)
		isOk &= Vector3fc::X.cross?( Vector3fc::Y ) == Vector3fc::Z
		isOk &= Vector3fc::Y.cross?( Vector3fc::Z ) == Vector3fc::X
		isOk &= Vector3fc::Z.cross?( Vector3fc::X ) == Vector3fc::Y

		# +, -, *, /
		isOk &= (Vector3fc::X + Vector3fc::Y + Vector3fc::Z) == Vector3fc::ONE
		isOk &= (Vector3fc::ONE - Vector3fc::X - Vector3fc::Y - Vector3fc::Z) == Vector3fc::ZERO
		isOk &= (Vector3fc::HALF * 2) == Vector3fc::ONE
		isOk &= (Vector3fc::ONE / 2) == Vector3fc::HALF
		isOk &= (Vector3fc.new( -1, 2, -30.7 ) * (Vector3fc::ONE * 2)) == Vector3fc.new( -2, 4, -61.4 )
		isOk &= (Vector3fc.new( -1, 2, -30.7 ) / Vector3fc::HALF) == Vector3fc.new( -2, 4, -61.4 )

		# clampToMinOf?, clampToMaxOf?, clampBetween?, clamp01?
		isOk &= (Vector3fc::ZERO.clampToMinOf?(Vector3fc.new(1,2,3))) == Vector3fc.new(1,2,3)
		isOk &= (Vector3fc.new( -1, 2, -30.7 ).clampToMinOf?(Vector3fc.new(-1,-2,-3))) == Vector3fc.new( -1, 2, -3 )
		isOk &= (Vector3fc::ONE.clampToMaxOf?(Vector3fc.new(-1,-2,-3))) == Vector3fc.new(-1,-2,-3)
		isOk &= (Vector3fc.new( -1, 2, -30.7 ).clampToMaxOf?(Vector3fc.new(-1,-2,-3))) == Vector3fc.new( -1, -2, -30.7 )
		isOk &= (Vector3fc.new( -1, 2, 30.7 ).clampBetween?( Vector3fc::HALF, Vector3fc.new(10,11,26) )) == Vector3fc.new( 0.5, 2, 26 )
		isOk &= Vector3fc.new(-1, 0.5, 3).clamp01? == Vector3fc.new(0, 0.5, Hxa7241::FLOAT_ALMOST_ONE)

		isOk
	end

end


end # module Hxa7241_Graphics
