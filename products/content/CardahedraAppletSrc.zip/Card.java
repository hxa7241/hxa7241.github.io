///  artifex@computer.org  |  2001-08  ///




class Card
{
/// construction -----------------------------------------------------------------------------------
	public Card( final float[] pt1, final float[] pt2, final float[] pt3,
		         final short[] textureFront, final short[] textureBack,
	             final int width, final int height )
	{
		setPosition( pt1, pt2, pt3 );
		setTextures( textureFront, textureBack, width, height );
	}


/// set things -------------------------------------------------------------------------------------
	public void setPosition( final float[] pt1, final float[] pt2, final float[] pt3 )
	{
//		if( (pt1 == null) || (pt2 == null) || (pt3 == null) ||
//		    (pt1.length != 3) || (pt2.length != 3) || (pt3.length != 3) )
//		{
//			return;
//		}


		axisPoint1_m.set( pt1 );
		axisPoint2_m.set( pt2 );


		Vector3f p3 = new Vector3f( pt3 );

		Vector3f v1  = axisPoint2_m.minus( axisPoint1_m );
		Vector3f v2  = p3.minus( axisPoint1_m );
		Vector3f v1u = v1.unitize();
		Vector3f v2u = v2.unitize();

		float v1dotv2 = v2u.dot( v1u );

		Vector3f v3 = new Vector3f( v1u );
		v3.scaleEq( v1dotv2 );
		v3.negateEq();
		v3.plusEq( v2u );
		v3.unitizeEq();
		v3.scaleEq( v1.length() * 0.5f );


		orientationVector_m.set( v3 );

		normalFixed_m.set( v1 ).crossEq( orientationVector_m ).unitizeEq();

		setFixedVertices();
	}


	public void setTextures( final short[] textureFront, final short[] textureBack,
	                         final int width, final int height )
	{
//		if( (textureFront == null) || (textureBack == null) ||
//		    (width <= 0) || (height <= 0) )
//		{
//			return;
//		}
		if( (width == 0) || (height == 0) )
		{
			 throw new RuntimeException( "zero texture dimension" );
		}

		textureFront_m  = textureFront;
		textureBack_m   = textureBack;
		textureWidth_m  = width;
		textureHeight_m = height;

		setFixedVertices();
	}


	private void setFixedVertices()
	{
		final float widthOverHeight    = (float)textureWidth_m / (float)textureHeight_m;
		final float textureAspectRatio = widthOverHeight < 1.0f ?
		                                 widthOverHeight : 1.0f / widthOverHeight;

		Vector3f orientationVector = orientationVector_m.scale( textureAspectRatio );

		verticesFixed_m[0].set( axisPoint1_m ).plusEq(  orientationVector );
		verticesFixed_m[1].set( axisPoint1_m ).minusEq( orientationVector );
		verticesFixed_m[2].set( axisPoint2_m ).minusEq( orientationVector );
		verticesFixed_m[3].set( axisPoint2_m ).plusEq(  orientationVector );

		vertices_m[0].set( verticesFixed_m[0] );
		vertices_m[1].set( verticesFixed_m[1] );
		vertices_m[2].set( verticesFixed_m[2] );
		vertices_m[3].set( verticesFixed_m[3] );
	}


/// update / draw ----------------------------------------------------------------------------------
	public void draw( final float[] lightVector,
	                  float ambientLight, final float lightInside,
	                  final int width, final int height,
	                  final float[] zBuffer, final int[] image )
	{
//		if( (zBuffer == null) || (image == null) ||
//		    (width <= 0) || (height <= 0) )
//		{
//			return;
//		}


		/// localise fields
		final Vector3f[] vertices   = vertices_m;
		final float perspectiveness = perspectiveness_m;
		final float screenScaling   = (float)( (width < height ? width : height) >> 1 );


		/// project vertices
		final float widthHalf  = (float)width  * 0.5f;
		final float heightHalf = (float)height * 0.5f;
		for( int i = 4;  i-- > 0; )
		{
			final float projection = screenScaling / (1.0f + ((vertices[ i ].z + 1.0f) * perspectiveness));
			screenX_m[ i ] = (vertices[ i ].x * projection) + widthHalf;
			screenY_m[ i ] = (vertices[ i ].y * projection) + heightHalf;
			screenW_m[ i ] = 1.0f / (1.0f + vertices[ i ].z + 1.0f);
			//screenW_m[ i ] = (32768.0f / (1.0f + Float.MIN_VALUE + ((vertices[ i ].z + 1.0f) * 127.5f)));
		}


		final boolean frontFacing = ( (screenX_m[ 3 ] - screenX_m[ 1 ]) * (screenY_m[ 2 ] - screenY_m[ 1 ]) <
		                 	             (screenY_m[ 3 ] - screenY_m[ 1 ]) * (screenX_m[ 2 ] - screenX_m[ 1 ])   );

		/// calc shading
		int shadeInt = 0;
		{
			final float normalX = normal_m.x;
			final float normalY = normal_m.y;
			final float normalZ = normal_m.z;

			float dot = (normalX * lightVector[0]) + (normalY * lightVector[1]) + (normalZ * lightVector[2]);
			dot = frontFacing ? -dot : dot;
			dot = dot >= 0.0f ? dot : 0.0f;

			if( ambientLight > 1.0f )
			{
				ambientLight = 1.0f;
			}
			else if( ambientLight < 0.0f )
			{
				ambientLight = 0.0f;
			}

			final float shade = ((dot * (1.0f - ambientLight)) + ambientLight) * (frontFacing ? 1.0f : lightInside);
			shadeInt = (int)(shade * 255.0f);
		}
		final int colorShaded = 0xFF000000 | (shadeInt << 16) | (shadeInt << 8) | shadeInt;


		/// floor ys before all use
		screenY_m[ 0 ] = (float)Math.floor( (double)screenY_m[ 0 ] );
		screenY_m[ 1 ] = (float)Math.floor( (double)screenY_m[ 1 ] );
		screenY_m[ 2 ] = (float)Math.floor( (double)screenY_m[ 2 ] );
		screenY_m[ 3 ] = (float)Math.floor( (double)screenY_m[ 3 ] );


		/// put vert 0 at the top left
		/// (0.0f == -0.0f is true)
		int highestVert = 0;
		float yCompare = screenY_m[ 1 ] - screenY_m[ highestVert ];
		if( (yCompare < 0.0f) || ((yCompare == 0.0f) && (screenX_m[ 1 ] < screenX_m[ highestVert ])) )
		{
			highestVert = 1;
		}
		yCompare = screenY_m[ 2 ] - screenY_m[ highestVert ];
		if( (yCompare < 0.0f) || ((yCompare == 0.0f) && (screenX_m[ 2 ] < screenX_m[ highestVert ])) )
		{
			highestVert = 2;
		}
		yCompare = screenY_m[ 3 ] - screenY_m[ highestVert ];
		if( (yCompare < 0.0f) || ((yCompare == 0.0f) && (screenX_m[ 3 ] < screenX_m[ highestVert ])) )
		{
			highestVert = 3;
		}
		int p0 = highestVert;
		int p1 = (1 + highestVert) & 0x03;
		int p2 = (2 + highestVert) & 0x03;
		int p3 = (3 + highestVert) & 0x03;


		/// put vert 1 anti clockwise from vert 0
		if( frontFacing )
		{
			final int temp = p1;
			p1 = p3;
			p3 = temp;
		}
		final int vertBits = (p3 << 6) | (p2 << 4) | (p1 << 2) | p0;


		/// note relative vert heights
		final int p1Higher      = ~( (int)((screenY_m[p3] - screenY_m[p1]) * 1024.0f) >> 31);
		final int p2Higher      = (int)((screenY_m[p2] - screenY_m[ p1Higher != 0 ? p3 : p1 ]) * 1024.0f) >> 31;
		final int higherPtFlags = ((p2Higher & 0x02) | (p1Higher & 0x01)) << 2;


		/// lookup tables - 4 bits per value
		final int endLeftBits   = (0 << 30) | (3 << 28) | (2 << 26) | (1 << 24) |
		                          (0 << 22) | (1 << 20) | (2 << 18) | (3 << 16) |
		                          (0 << 14) | (2 << 12) | (3 << 10) | (1 <<  8) |
		                          (0 <<  6) | (2 <<  4) | (1 <<  2) | (3 <<  0);
		final int gradLeftBits  = (0 << 30) | (2 << 28) | (1 << 26) | (0 << 24) |
		                          (0 << 22) | (0 << 20) | (0 << 18) | (0 << 16) |
		                          (0 << 14) | (1 << 12) | (1 << 10) | (0 <<  8) |
		                          (0 <<  6) | (1 <<  4) | (0 <<  2) | (0 <<  0);
		final int gradRightBits = (0 << 30) | (3 << 28) | (3 << 26) | (3 << 24) |
		                          (0 << 22) | (1 << 20) | (2 << 18) | (3 << 16) |
		                          (0 << 14) | (2 << 12) | (3 << 10) | (3 <<  8) |
		                          (0 <<  6) | (2 <<  4) | (2 <<  2) | (3 <<  0);


		/// calc gradients along edges
		{
			final float dy10 = screenY_m[ p1 ] - screenY_m[ p0 ];
			final float dy21 = screenY_m[ p2 ] - screenY_m[ p1 ];
			final float dy32 = screenY_m[ p3 ] - screenY_m[ p2 ];
			final float dy03 = screenY_m[ p0 ] - screenY_m[ p3 ];

			final float dy10recip = 1.0f / dy10;
			final float dy21recip = 1.0f / dy21;
			final float dy32recip = 1.0f / dy32;
			final float dy03recip = 1.0f / dy03;

			final float dx10 = screenX_m[ p1 ] - screenX_m[ p0 ];
			final float dx21 = screenX_m[ p2 ] - screenX_m[ p1 ];
			final float dx32 = screenX_m[ p3 ] - screenX_m[ p2 ];
			final float dx03 = screenX_m[ p0 ] - screenX_m[ p3 ];

			edgeGradients_m[0]  = dx10 * dy10recip;
			edgeGradients_m[1]  = dx21 * dy21recip;
			edgeGradients_m[2]  = dx32 * dy32recip;
			edgeGradients_m[3]  = dx03 * dy03recip;

			final float dw10 = screenW_m[ p1 ] - screenW_m[ p0 ];
			final float dw21 = screenW_m[ p2 ] - screenW_m[ p1 ];
			final float dw32 = screenW_m[ p3 ] - screenW_m[ p2 ];
			final float dw03 = screenW_m[ p0 ] - screenW_m[ p3 ];

			edgeGradientsW_m[0] = dw10 * dy10recip;
			edgeGradientsW_m[1] = dw21 * dy21recip;
			edgeGradientsW_m[2] = dw32 * dy32recip;
			edgeGradientsW_m[3] = dw03 * dy03recip;
		}


		/// rasterize
		final boolean horizontalTop = edgeGradients_m[3] != Float.NEGATIVE_INFINITY;
		final int width2210 = width << 10;
		int   iLeft  = (int)(screenX_m[p0] * 1024.0f) + (((int)screenY_m[p0] * width) << 10);
		int   iRight = horizontalTop ? iLeft : (int)(screenX_m[p3] * 1024.0f) + (((int)screenY_m[p3] * width) << 10);
		float wLeft  = screenW_m[p0];
		float wRight = horizontalTop ? wLeft : screenW_m[p3];

		/// quadrangle of trapezoids
		for( int i = 0;  i < 3;  ++i )
		{
			final int bitsShift       = ((higherPtFlags | i) << 1);
			final int iLeftIncLookup  = (gradLeftBits  >> bitsShift) & 0x03;
			final int iRightIncLookup = (gradRightBits >> bitsShift) & 0x03;
			final int iLeftEndLookup  = (endLeftBits   >> bitsShift) & 0x03;

			final int   iLeftInc  = (int)(edgeGradients_m[ iLeftIncLookup  ] * 1024.0f) + width2210;
			final int   iRightInc = (int)(edgeGradients_m[ iRightIncLookup ] * 1024.0f) + width2210;
			final int   iLeftEnd  = (((int)screenY_m[ (vertBits >> (iLeftEndLookup << 1)) & 0x03 ] * width) << 10);
			final float wLeftInc  = edgeGradientsW_m[ iLeftIncLookup ];
			final float wRightInc = edgeGradientsW_m[ iRightIncLookup ];

			/// triangle/trapezoid of spans
			while( iLeft < iLeftEnd )
			{
				iLeft  += iLeftInc;
				iRight += iRightInc;
				wLeft  += wLeftInc;
				wRight += wRightInc;

				int         iIndex    = iLeft  >> 10;
				final int   iIndexEnd = iRight >> 10;
				float       w         = wLeft;
				final float wInc      = (wRight - wLeft) / (float)(iIndexEnd - iIndex);

				/// span of pixels
				while( iIndex < iIndexEnd )
				{
					/// check z buffer
					if( w > zBuffer[ iIndex ] )
					{
						/// write color and z
						image[ iIndex ]   = colorShaded;
						zBuffer[ iIndex ] = w;
					}

					++iIndex;
					w += wInc;
				}
			}
		}
	}


	public void rotate( final float[] sinXYZ, final float[] cosXYZ )
	{
//		if( (sinXYZ == null) || (cosXYZ == null) ||
//		    (sinXYZ.length != 3) || (cosXYZ.length != 3) )
//		{
//			return;
//		}

		/// rotate vertices
		for( int i = 4;  i-- != 0; )
		{
			rotateVertex( sinXYZ, cosXYZ, verticesFixed_m[ i ], vertices_m[ i ] );
		}

		/// rotate normal
		rotateVertex( sinXYZ, cosXYZ, normalFixed_m, normal_m );
	}


	private void rotateVertex( final float[] sinXYZ, final float[] cosXYZ,
	                           final Vector3f vertexIn, final Vector3f vertexOut )
	{
		final float sinRotationX = sinXYZ[0];
		final float cosRotationX = cosXYZ[0];
		final float sinRotationY = sinXYZ[1];
		final float cosRotationY = cosXYZ[1];
		final float sinRotationZ = sinXYZ[2];
		final float cosRotationZ = cosXYZ[2];

		/// rotate
		float vertX = vertexIn.x;
		float vertY = vertexIn.y;
		float vertZ = vertexIn.z;

		float tmp1 = vertY;
		float tmp2 = vertZ;
		vertY = (tmp1 * cosRotationX) - (tmp2 * sinRotationX);
		vertZ = (tmp2 * cosRotationX) + (tmp1 * sinRotationX);

		tmp1 = vertZ;
		tmp2 = vertX;
		vertZ = (tmp1 * cosRotationY) - (tmp2 * sinRotationY);
		vertX = (tmp2 * cosRotationY) + (tmp1 * sinRotationY);

		tmp1 = vertX;
		tmp2 = vertY;
		vertX = (tmp1 * cosRotationZ) - (tmp2 * sinRotationZ);
		vertY = (tmp2 * cosRotationZ) + (tmp1 * sinRotationZ);

		/// save
		vertexOut.x = vertX;
		vertexOut.y = vertY;
		vertexOut.z = vertZ;
	}


	public void move()
	{
	}


	/*public void line(int x0, int y0, int x1, int y1, int color, int width, int[] pixels )
	{
		int pix = color;
		int dy = y1 - y0;
		int dx = x1 - x0;
		int stepy;
		if(dy < 0)
		{
			dy = -dy;
			stepy = -width;
		}
		else
		{
			stepy = width;
		}
		int stepx;
		if(dx < 0)
		{
			dx = -dx;
			stepx = -1;
		}
		else
		{
			stepx = 1;
		}
		dy <<= 1;
		dx <<= 1;
		y0 *= width;
		y1 *= width;
		pixels[x0 + y0] = pix;
		if(dx > dy)
		{
			int fraction = dy - (dx >> 1);
			while(x0 != x1)
			{
				if(fraction >= 0)
				{
					y0 += stepy;
					fraction -= dx;
				}
				x0 += stepx;
				fraction += dy;
				pixels[x0 + y0] = pix;
			}
		} else
		{
			int fraction = dx - (dy >> 1);
			while(y0 != y1)
			{
				if(fraction >= 0)
				{
					x0 += stepx;
					fraction -= dy;
				}
				y0 += stepy;
				fraction += dx;
				pixels[x0 + y0] = pix;
			}
		}
	}*/


/// fields -----------------------------------------------------------------------------------------
	/// texture
	private short[] textureFront_m;   /// 5,5,5
	private short[] textureBack_m;

	private int textureWidth_m  = 2;
	private int textureHeight_m = 1;


	/// position constants
	private Vector3f axisPoint1_m        = new Vector3f();
	private Vector3f axisPoint2_m        = new Vector3f();
	private Vector3f orientationVector_m = new Vector3f();

	private Vector3f[] verticesFixed_m   = new Vector3f[ 4 ];
	private Vector3f   normalFixed_m     = new Vector3f();

	/// position variables
	private Vector3f[] vertices_m        = new Vector3f[ 4 ];
	private Vector3f   normal_m          = new Vector3f();

	{
		for( int i = 4;  i-- > 0; )
		{
			verticesFixed_m[i] = new Vector3f();
			vertices_m[i]      = new Vector3f();
		}
	}


	/// drawing storage cache
	final float[] screenX_m = new float[ 4 ];
	final float[] screenY_m = new float[ 4 ];
	final float[] screenW_m = new float[ 4 ];

	final float[] edgeGradients_m  = new float[ 4 ];
	final float[] edgeGradientsW_m = new float[ 4 ];


	/// projection
	private static final float perspectiveness_m = 0.25f;
}
