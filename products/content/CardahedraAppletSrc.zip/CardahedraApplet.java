///  artifex@computer.org  |  2001-08  ///




public class CardahedraApplet
	extends AppletAnimated
{
/// construction -----------------------------------------------------------------------------------
	public CardahedraApplet()
	{
		super();

		lastChangeTime_m = System.currentTimeMillis();
	}


/// AppletAnimated overrides -----------------------------------------------------------------------
	public void initDerived( final int width, final int height, final int[] pixels )
	{
		/// max dimensions of 2048 * 2048
		if( (width * height) > (2048 * 2048) )
		{
			throw new IllegalArgumentException( "width and/or height to large : (width * height) must be < (2048 * 2048)" );
		}

		cardahedra_m[0] = new PlatonicCardahedron( PlatonicCardahedron.TETRA,  new short[2], new short[2], 2, 1 );
		cardahedra_m[1] = new PlatonicCardahedron( PlatonicCardahedron.HEXA,   new short[2], new short[2], 2, 1 );
		cardahedra_m[2] = new PlatonicCardahedron( PlatonicCardahedron.OCTA,   new short[2], new short[2], 2, 1 );
		cardahedra_m[3] = new PlatonicCardahedron( PlatonicCardahedron.DODECA, new short[2], new short[2], 2, 1 );
		cardahedra_m[4] = new PlatonicCardahedron( PlatonicCardahedron.ICOSA,  new short[2], new short[2], 2, 1 );

		zBuffer_m = new float[ pixels.length ];

		addKeyListener( userInputHandler_m );
		addMouseListener( userInputHandler_m );
		addMouseMotionListener( userInputHandler_m );
	}


	public void startDerived()
	{
	}


	public void stopDerived()
	{
	}


	public void destroyDerived()
	{
	}


	protected void drawFrame( final int width, final int height, final int[] pixels )
	{
		/// update
//		if( userInputHandler_m.isMousePressed() )
//		{
//			/// manual move
//			final int   mouseMovementX   = userInputHandler_m.getMousePosX() - lastMousePosX_m;
//			final int   mouseMovementY   = userInputHandler_m.getMousePosY() - lastMousePosY_m;
//			final float degreesToRadians = 3.141592653f / 180.0f;
//
//			cardahedra_m[ currentModel_m ].move( (float)mouseMovementY * degreesToRadians,
//			                                     (float)mouseMovementX * degreesToRadians,
//			                                     0.0f );
//		}
//		else
		if( !userInputHandler_m.isPaused() )
		{
			/// automatic move
			for( int i = cardahedra_m.length;  i-- > 0; )
			{
				cardahedra_m[ i ].update();
			}
		}


		/// draw
		if( zBuffer_m.length != pixels.length )
		{
			zBuffer_m = new float[ pixels.length ];
		}
		clearImageAndZbuffer( pixels, zBuffer_m );
		cardahedra_m[ currentModel_m ].draw( lightVector_m, ambientLight_m, lightInside_m,
		                                     width, height, zBuffer_m, pixels );


		/// change cardahedron model every several seconds or on key
		final long currentTime = System.currentTimeMillis();
		if( ((currentTime - lastChangeTime_m) > modelPeriod_m) ||
		    userInputHandler_m.isNextModelKey() )
		{
			currentModel_m   = (currentModel_m + 1) % cardahedra_m.length;
			lastChangeTime_m = currentTime;
			userInputHandler_m.resetNextModelKey();

			cardahedra_m[ currentModel_m ].startTransition();
		}


		/// adjust update speed
		final float fps = getFrameRate();
		if( fps != 0.0f )
		{
			for( int i = cardahedra_m.length;  i-- > 0; )
			{
				cardahedra_m[ i ].notifyOfFramerate( fps );
			}
		}


		lastMousePosX_m = userInputHandler_m.getMousePosX();
		lastMousePosY_m = userInputHandler_m.getMousePosY();
	}


	public String getAppletInfo()
	{
		return "simple cardahedra applet  |  artifex@computer.org  |  2001-08";
	}


	public String[][] getParameterInfo()
	{
		return new String[][] {{"","",""}};
	}
	//{	/// of the form:
	//	return  new String[][] { {"name",  "type",  "comment"},
	//	                         {"name",  "type",  "comment"}  };
	//}


/// implementation ---------------------------------------------------------------------------------
	private static void clearImageAndZbuffer( final int[] image, final float[] zBuffer )
	{
		for( int i = image.length;  i-- > 0; )
		{
			image[ i ]   = 0xFFFFFFFF;
			zBuffer[ i ] = 0.0f;
		}
	}


/// fields -----------------------------------------------------------------------------------------
	private Cardahedron[] cardahedra_m = new Cardahedron[ 5 ];
	private int           currentModel_m;

	private float[] zBuffer_m;

	private static final float[] lightVector_m  = { -0.272f, -0.680f, -0.680f };
	private static final float   ambientLight_m = 0.5f;
	private static final float   lightInside_m  = 0.625f;

	private static       long lastChangeTime_m;
	private static final long modelPeriod_m = 8000L;


	/// input
	private UserInput userInputHandler_m = new UserInput();
	private int lastMousePosX_m;
	private int lastMousePosY_m;

	private static class UserInput
		implements java.awt.event.KeyListener,
		           java.awt.event.MouseListener,
		           java.awt.event.MouseMotionListener
	{
	/// queries
		public boolean isPaused()
		{
			return isPaused_m;
		}

		public boolean isNextModelKey()
		{
			return isNextModelKey_m;
		}

		public boolean isMousePressed()
		{
			return isMousePressed_m;
		}

		public int getMousePosX()
		{
			return mousePosX_m;
		}

		public int getMousePosY()
		{
			return mousePosY_m;
		}


	/// commands
		public void resetNextModelKey()
		{
			isNextModelKey_m = false;
		}


	/// event handlers
		public void keyPressed( java.awt.event.KeyEvent e )
		{
			final char c = e.getKeyChar();

			isPaused_m ^= (c == ' ');
		}

		public void keyTyped( java.awt.event.KeyEvent e )
		{
			final char c = e.getKeyChar();

			isNextModelKey_m = (c == '\n');
		}

		public void mousePressed( java.awt.event.MouseEvent e )
		{
			isMousePressed_m = true;
		}

		public void mouseReleased( java.awt.event.MouseEvent e )
		{
			isMousePressed_m = false;
		}

		public void mouseDragged( java.awt.event.MouseEvent e )
		{
			mousePosX_m = e.getX();
			mousePosY_m = e.getY();
		}

		public void mouseMoved( java.awt.event.MouseEvent e )
		{
			mousePosX_m = e.getX();
			mousePosY_m = e.getY();
		}

		public void keyReleased( java.awt.event.KeyEvent e ) {}
		public void mouseClicked( java.awt.event.MouseEvent e ) {}
		public void mouseEntered( java.awt.event.MouseEvent e ) {}
		public void mouseExited( java.awt.event.MouseEvent e ) {}


		private boolean isPaused_m;
		private boolean isNextModelKey_m;
		private boolean isMousePressed_m;
		private int     mousePosX_m;
		private int     mousePosY_m;
	}

}
