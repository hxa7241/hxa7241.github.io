///  artifex@computer.org  |  2001-08  ///




abstract class Cardahedron
{
/// construction -----------------------------------------------------------------------------------
	protected Cardahedron( final int noOfCards )
	{
		cards_m = new Card[ noOfCards ];
	}


/// protected interface ----------------------------------------------------------------------------
	protected Card[] getCards()
	{
		return cards_m;
	}


/// set things -------------------------------------------------------------------------------------
	public void setTextures( final short[] textureFront, final short[] textureBack,
	                         final int width, final int height )
	{
		for( int i = cards_m.length;  i-- > 0; )
		{
			cards_m[ i ].setTextures( textureFront, textureBack, width, height );
		}
	}


	public void notifyOfFramerate( final float framesPerSecond )
	{
		/// adjust rotation increment to retain constant speed
		frameRateFactor_m = 1.0f / (0.5f * framesPerSecond);
	}


	public void startTransition()
	{
		startTime_m = System.currentTimeMillis();
	}


	public void draw( final float[] lightVector,
	                  final float ambientLight, final float lightInside,
	                  final int width, final int height,
	                  final float[] zBuffer, final int[] image )
	{
		final long currentTime = System.currentTimeMillis();

		int startCard = 0;
		if( (currentTime - startTime_m) < transitionPeriod_m )
		{
			startCard = (cards_m.length * (int)(currentTime - startTime_m)) / transitionPeriod_m;
		}
		else
		{
			startCard = cards_m.length;
		}


		for( int i = startCard;  i-- > 0; )
		{
			cards_m[ i ].draw( lightVector, ambientLight, lightInside,
			                   width, height, zBuffer, image );
		}
	}


/// update / draw ----------------------------------------------------------------------------------
	public void update()
	{
		/// increment rotation position
		rotationX_m += rotationIncX_m * frameRateFactor_m;
		rotationY_m += rotationIncY_m * frameRateFactor_m;
		rotationZ_m += rotationIncZ_m * frameRateFactor_m;


		/// keep within first cycle to eliminate any drift
		final float twoPi = 2.0f * 3.141592653f;

		rotationX_m = rotationX_m > twoPi ? rotationX_m - twoPi : rotationX_m;
		rotationX_m = rotationX_m <  0.0f ? rotationX_m + twoPi : rotationX_m;
		rotationY_m = rotationY_m > twoPi ? rotationY_m - twoPi : rotationY_m;
		rotationY_m = rotationY_m <  0.0f ? rotationY_m + twoPi : rotationY_m;
		rotationZ_m = rotationZ_m > twoPi ? rotationZ_m - twoPi : rotationZ_m;
		rotationX_m = rotationZ_m <  0.0f ? rotationZ_m + twoPi : rotationZ_m;


		/// calc rotation 'matrix'
		/// (the cube isnt rotated incrementally because i want to elimate any drift)
		sinXYZ_m[0] = (float)Math.sin( (double)rotationX_m );
		cosXYZ_m[0] = (float)Math.cos( (double)rotationX_m );
		sinXYZ_m[1] = (float)Math.sin( (double)rotationY_m );
		cosXYZ_m[1] = (float)Math.cos( (double)rotationY_m );
		sinXYZ_m[2] = (float)Math.sin( (double)rotationZ_m );
		cosXYZ_m[2] = (float)Math.cos( (double)rotationZ_m );


		/// update cards
		for( int i = cards_m.length;  i-- > 0; )
		{
			cards_m[ i ].rotate( sinXYZ_m, cosXYZ_m );
		}
	}


	public void move( final float rotationIncX, final float rotationIncY, final float rotationIncZ )
	{
	}


/// fields -----------------------------------------------------------------------------------------
	private Card[] cards_m = new Card[0];


	/// rotation things for update
	private float frameRateFactor_m = 1.0f / (0.5f * 30.0f);

	private float rotationX_m;
	private float rotationY_m;
	private float rotationZ_m;

	private float rotationIncX_m = (32.0f / 180.0f * 3.141592653f);
	private float rotationIncY_m = (14.0f / 180.0f * 3.141592653f);
	private float rotationIncZ_m = (20.0f / 180.0f * 3.141592653f);


	/// drawing transition
	private long startTime_m;
	private static final int transitionPeriod_m = 500;


	/// storage cache
	private float[] sinXYZ_m = new float[ 3 ];
	private float[] cosXYZ_m = new float[ 3 ];

}
