///  artifex@computer.org  |  2001-08  ///




class PlatonicCardahedron
	extends Cardahedron
{
/// constants
	public static final int TETRA  = 0;
	public static final int HEXA   = 1;
	public static final int OCTA   = 2;
	public static final int DODECA = 3;
	public static final int ICOSA  = 4;


/// construction -----------------------------------------------------------------------------------
	public PlatonicCardahedron( int whichOne,
	                            final short[] textureFront, final short[] textureBack,
	                            final int width, final int height )
	{
		super( faces_m[ ((whichOne & 0x7FFFFFFF) % 5) ].length * faces_m[ ((whichOne & 0x7FFFFFFF) % 5) ][0].length );


		whichOne = ((whichOne & 0x7FFFFFFF) % 5);
		final int noOfFaces     = faces_m[ whichOne ].length;
		final int noOfFaceVerts = faces_m[ whichOne ][ 0 ].length;


		Card[]     cards       = getCards();
		Vector3f[] faceVerts   = { new Vector3f(), new Vector3f(), new Vector3f(), new Vector3f(), new Vector3f() };
		Vector3f   faceCenter  = new Vector3f();
		Vector3f   orientation = new Vector3f();
		float[]    temp1 = new float[3];
		float[]    temp2 = new float[3];
		float[]    temp3 = new float[3];

		/// step thru faces
		for( int f = noOfFaces;  f-- > 0; )
		{
			faceCenter.set( 0.0f, 0.0f, 0.0f );

			/// step thru face verts
			for( int v = noOfFaceVerts;  v-- > 0; )
			{
				/// add vert
				final short vertBits  = verts_m[ whichOne ][ faces_m[ whichOne ][ f ][ v ] - 1 ];
				final int   vertBitsX = (int)vertBits & 0x07;
				final int   vertBitsY = (vertBits >> 4) & 0x07;
				final int   vertBitsZ = (vertBits >> 8) & 0x07;
				faceVerts[ v ].set( values_m[ vertBitsX & 0x03 ] * (vertBitsX > 3 ? -1.0f : 1.0f),
				                    values_m[ vertBitsY & 0x03 ] * (vertBitsY > 3 ? -1.0f : 1.0f),
				                    values_m[ vertBitsZ & 0x03 ] * (vertBitsZ > 3 ? -1.0f : 1.0f) );
				faceVerts[ v ].unitizeEq().scaleEq( 0.95f );
				faceCenter.plusEq( faceVerts[ v ] );
			}

			/// face center = div added verts by number of verts
			faceCenter.scaleEq( 1.0f / (float)noOfFaceVerts );

			/// step thru face verts
			for( int v = noOfFaceVerts;  v-- > 0; )
			{
				/// make card
				orientation.set( faceVerts[ v ] );
				orientation.minusEq( faceVerts[ (v + 1) % noOfFaceVerts ] ).negateEq().plusEq( faceVerts[ v ] );
				cards[ (f * noOfFaceVerts) + v ] = new Card( faceVerts[ v ].get( temp1 ), faceCenter.get( temp2 ),
				                                             orientation.get( temp3 ),
				                                             textureFront, textureBack, width, height );
			}
		}



		/*super( 2 );

		Card[] cards = getCards();

//		cards[0] = new Card( new float[] { 0.0f, -1.0f, -1.0f }, new float[] { 0.0f, 1.0f, -1.0f }, new float[] { 1.0f, 1.0f, -1.0f },
//		                     textureFront, textureBack, width, height );
//		cards[1] = new Card( new float[] { 0.0f, -1.0f, 1.0f },  new float[] { 0.0f, 1.0f, 1.0f },  new float[] { 1.0f, 1.0f, 1.0f },
//		                     textureFront, textureBack, width, height );

		cards[0] = new Card( new float[] {  0.0f,  -0.666f, -0.666f },
		                     new float[] {  0.0f,   0.666f, -0.666f },
		                     new float[] { -0.666f, 0.666f, -0.666f },
		                     textureFront, textureBack, width, height );
//		cards[0] = new Card( new float[] {  0.0f,  -0.666f / 2.0f, -0.666f },
//		                     new float[] {  0.0f,   0.666f / 2.0f, -0.666f },
//		                     new float[] { -0.666f, 0.666f / 2.0f, -0.666f },
//		                     textureFront, textureBack, 1, 1 );

		cards[1] = new Card( new float[] { 0.0f,  -0.666f, 0.666f },
		                     new float[] { 0.0f,   0.666f, 0.666f },
		                     new float[] { 0.666f, 0.666f, 0.666f },
		                     textureFront, textureBack, width, height );*/
	}


/// ------------------------------------------------------------------------------------------------


/// fields -----------------------------------------------------------------------------------------

	private static final short[]  vertsTetra_m  = { 0x0155, 0x0515, 0x0551, 0x0111 };
	private static final byte[][] facesTetra_m  = { { 4, 3, 2 }, { 3, 4, 1 }, { 2, 1, 4 }, { 1, 2, 3 } };

	private static final short[]  vertsHexa_m   = { 0x0111, 0x0511, 0x0151, 0x0551, 0x0115, 0x0515, 0x0155, 0x0555 };
	private static final byte[][] facesHexa_m   = { { 2, 1, 3, 4 }, { 5, 6, 8, 7 }, { 1, 2, 6, 5 }, { 4, 3, 7, 8 }, { 3, 1, 5, 7 }, { 2, 4, 8, 6 } };

	private static final short[]  vertsOcta_m   = { 0x0001, 0x0005, 0x0010, 0x0050, 0x0100, 0x0500 };
	private static final byte[][] facesOcta_m   = { { 1, 3, 5 }, { 3, 1, 6 }, { 4, 1, 5 }, { 1, 4, 6 }, { 3, 2, 5 }, { 2, 3, 6 }, { 2, 4, 5 }, { 4, 2, 6 } };

	private static final short[]  vertsDodeca_m = { 0x0111, 0x0511, 0x0151, 0x0551, 0x0115,
	                                                0x0515, 0x0155, 0x0555,
	                                                0x0032, 0x0036, 0x0072, 0x0076,
	                                                0x0203, 0x0603, 0x0207, 0x0607,
	                                                0x0320, 0x0360, 0x0720, 0x0760 };
	private static final byte[][] facesDodeca_m = { { 2, 9, 1, 13, 14 },  { 5, 10, 6, 16, 15 }, { 3, 11, 4, 14, 13 }, { 8, 12, 7, 15, 16 },
	                                                { 3, 13, 1, 17, 18 }, { 2, 14, 4, 20, 19 }, { 5, 15, 7, 18, 17 }, { 8, 16, 6, 19, 20 },
	                                                { 5, 17, 1, 9, 10 },  { 3, 18, 7, 12, 11 }, { 2, 19, 6, 10, 9 },  { 8, 20, 4, 11, 12 } };

	private static final short[]  vertsIcosa_m  = { 0x0013, 0x0017, 0x0053, 0x0057,
	                                                0x0301, 0x0701, 0x0305, 0x0705,
	                                                0x0130, 0x0170, 0x0530, 0x0570 };
	private static final byte[][] facesIcosa_m  = { { 1, 9, 5 }, { 1, 6, 11 }, { 3, 5, 10 }, { 3, 12, 6 }, { 2, 7, 9 },
	                                                { 2, 11, 8 }, { 4, 10, 7 }, { 4, 8, 12 }, { 1, 11, 9 }, { 2, 9, 11 },
	                                                { 3, 10, 12 }, { 4, 12, 10 }, { 5, 3, 1 }, { 6, 1, 3 }, { 7, 2, 4 },
	                                                { 8, 4, 2 }, { 9, 7, 5 }, { 10, 5, 7 }, { 11, 6, 8 }, { 12, 8, 6 } };


	private static final float[]    values_m    = { 0.0f, 1.0f, 0.61803398874989484820458683436564f, 1.6180339887498948482045868343656f };
	private static final byte[][][] faces_m     = { facesTetra_m, facesHexa_m, facesOcta_m, facesDodeca_m, facesIcosa_m };
	private static final short[][]  verts_m     = { vertsTetra_m, vertsHexa_m, vertsOcta_m, vertsDodeca_m, vertsIcosa_m };
}
