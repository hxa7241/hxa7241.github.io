///  artifex@computer.org  |  2001-08  ///




public class Vector3f
{
/// construction -----------------------------------------------------------------------------------
	public Vector3f()
	{
	}

	public Vector3f( final Vector3f v )
	{
		set( v );
	}

	public Vector3f( final float x, final float y, final float z )
	{
		set( x, y, z );
	}

	public Vector3f( final float[] xyz )
	{
		set( xyz );
	}


/// queries ----------------------------------------------------------------------------------------
	public final float[] get( final float[] xyz )
	{
		xyz[0] = x;
		xyz[1] = y;
		xyz[2] = z;

		return xyz;
	}

	public final float[] get()
	{
		return get( new float[3] );
	}

	public final float length()
	{
		return (float)Math.sqrt( (double)dot( this ) );
	}

	public final float distance( final Vector3f v )
	{
		final float dx = v.x - x;
		final float dy = v.y - y;
		final float dz = v.z - z;

		return (float)Math.sqrt( (double)( (dx * dx) + (dy * dy) + (dz * dz) ) );
	}

	public final float dot( final Vector3f v )
	{
		return (x * v.x) + (y * v.y) + (z * v.z);
	}

	public final Vector3f cross( final Vector3f v )
	{
		return  new Vector3f( this ).crossEq( v );
	}

	public final Vector3f negate()
	{
		return  new Vector3f( this ).negateEq();
	}

	public final Vector3f scale( final float s )
	{
		return  new Vector3f( this ).scaleEq( s );
	}

	public final Vector3f plus( final Vector3f v )
	{
		return  new Vector3f( this ).plusEq( v );
	}

	public final Vector3f minus( final Vector3f v )
	{
		return  new Vector3f( this ).minusEq( v );
	}

	public final Vector3f multiply( final Vector3f v )
	{
		return  new Vector3f( this ).multiplyEq( v );
	}

	public final Vector3f divide( final Vector3f v )
	{
		return  new Vector3f( this ).divideEq( v );
	}

	public final Vector3f unitize()
	{
		return  new Vector3f( this ).unitizeEq();
	}

	public final boolean equals( final Object o )
	{
		boolean isEqual = false;

		if( o == this )
		{
			isEqual = true;
		}
		else if( o instanceof Vector3f )
		{
			final Vector3f v = (Vector3f)o;
			isEqual = (x == v.x) && (y == v.y) && (z == v.z);
		}

		return isEqual;
	}

	public final int hashCode()
	{
		int hash = 17;
		hash = (hash * 37) + Float.floatToIntBits( x );
		hash = (hash * 37) + Float.floatToIntBits( y );
		hash = (hash * 37) + Float.floatToIntBits( z );

		return hash;
	}

	public final String toString()
	{
		return getClass().getName() + "{" + x + ", " + y + ", " + z + "}";
	}


/// commands ---------------------------------------------------------------------------------------
	public final Vector3f set( final Vector3f v )
	{
		x = v.x;
		y = v.y;
		z = v.z;

		return  this;
	}

	public final Vector3f set( final float x, final float y, final float z )
	{
		this.x = x;
		this.y = y;
		this.z = z;

		return  this;
	}

	public final Vector3f set( final float[] xyz )
	{
		x = xyz[0];
		y = xyz[1];
		z = xyz[2];

		return  this;
	}

	public final Vector3f crossEq( final Vector3f v )
	{
		final float xNew = (y * v.z) - (z * v.y);
		final float yNew = (z * v.x) - (x * v.z);
		final float zNew = (x * v.y) - (y * v.x);

		x = xNew;  y = yNew;  z = zNew;

		return  this;
	}

	public final Vector3f negateEq()
	{
		x = -x;
		y = -y;
		z = -z;

		return this;
	}

	public final Vector3f scaleEq( final float s )
	{
		x *= s;
		y *= s;
		z *= s;

		return this;
	}

	public final Vector3f plusEq( final Vector3f v )
	{
		x += v.x;
		y += v.y;
		z += v.z;

		return this;
	}

	public final Vector3f minusEq( final Vector3f v )
	{
		x -= v.x;
		y -= v.y;
		z -= v.z;

		return this;
	}

	public final Vector3f multiplyEq( final Vector3f v )
	{
		x *= v.x;
		y *= v.y;
		z *= v.z;

		return this;
	}

	public final Vector3f divideEq( final Vector3f v )
	{
		x /= v.x;
		y /= v.y;
		z /= v.z;

		return this;
	}

	public final Vector3f unitizeEq()
	{
		final float length = length();

		if( length != 0.0f )
		{
			scaleEq( 1.0f / length );
		}
		else
		{
			x = y = z = 0.0f;
		}

		return this;
	}


/// fields -----------------------------------------------------------------------------------------
	public float x;
	public float y;
	public float z;

}
