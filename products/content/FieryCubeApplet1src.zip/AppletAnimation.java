import java.applet.*;
import java.awt.*;
import java.awt.image.*;




abstract class AppletAnimation
	extends Applet
	implements Runnable
{
/// customization interface ------------------------------------------------------------------------
	public void initDerived()
	{
	}

	public void startDerived()
	{
	}

	public void stopDerived()
	{
	}

	public void destroyDerived()
	{
	}

	abstract protected void drawFrame();

	abstract protected long getSleepPeriodMillisecs();
	abstract protected int  getFrameSkipRate();

	abstract public String getAppletInfo();
	abstract public String[][] getParameterInfo();
	/*{	/// of the form:
		return  new String[][] { {"name",  "type",  "comment"},
		                         {"name",  "type",  "comment"}  };
	}*/


/// construction -----------------------------------------------------------------------------------
	public AppletAnimation()
	{
		super();

		if( IS_THREAD_USED )
		{
			drawThread_m = new Thread( this );
		}
	}


/// AppletAnimation services interface -------------------------------------------------------------
	protected final int[] getPixels()
	{
		return  outputPixels_m;
	}

	protected final int getWidth_()
	{
		return width_m;
	}

	protected final int getHeight_()
	{
		return height_m;
	}

	protected final int getFrameCount()
	{
		return frameCount_m;
	}


/// Applet overrides -------------------------------------------------------------------------------
	public final void init()
	{
		/// set width and height
		Dimension widhei = getSize();   /// jdk1.1
		width_m  = widhei.width;
		height_m = widhei.height;
		//width_m  = getWidth();   /// jdk1.2
		//height_m = getHeight();

		/// create pixel surface
		outputPixels_m = new int[ width_m * height_m ];

		/// create image
		ColorModel        cm  = ColorModel.getRGBdefault();
		MemoryImageSource mis = new MemoryImageSource( width_m, height_m, cm, outputPixels_m, 0, width_m );
		outputImage_m = createImage( mis );


		/// init derived object
		initDerived();
	}

	public final void start()
	{
		startDerived();

		startThread();
	}

	public final void stop()
	{
		try
		{
			stopDerived();
		}
		finally
		{
			stopThread();
		}
	}

	public final void destroy()
	{
		destroyDerived();
	}

	public final void update( Graphics g )
	{
		int frameSkipRate = getFrameSkipRate();
		if( frameSkipRate == 0 )
		{
			frameSkipRate = 1;
		}

		if( ( frameCount_m % frameSkipRate ) == 0 )
		{
			try
			{
				drawFrame();
			}
			catch( RuntimeException e )
			{
				requestThreadStop();
				throw e;
			}
		}

		paint( g );


		if( frameCount_m == 0 )
		{
			startTime_m = System.currentTimeMillis();
		}
		else if( frameCount_m == 100 )
		{
			final long currentTime = System.currentTimeMillis();
			final int frameRate = (int)( ((long)frameCount_m * 1000L) / (currentTime - startTime_m) );
			System.out.print( "fps (100 frames): " + frameRate );
		}

		++frameCount_m;
	}

	public final void paint( Graphics g )
	{
		outputImage_m.flush();
		g.drawImage( outputImage_m, 0, 0, this );
	}


/// thread control ---------------------------------------------------------------------------------
	private void startThread()
	{
		if( IS_THREAD_USED )
		{
			drawThreadPermission_m = true;
			drawThread_m.start();
		}
	}

	private void stopThread()
	{
		if( IS_THREAD_USED )
		{
			try
			{
				requestThreadStop();
				drawThread_m.join();
			}
			catch( InterruptedException e )
			{
			}
		}
	}

	private void requestThreadStop()
	{
		drawThreadPermission_m = false;
	}

	public final void run()
	{
		final long sleepPeriodMillisecs = getSleepPeriodMillisecs();

		while( drawThreadPermission_m )
		{
			/// request redrawing
			repaint();

			try
			{
				drawThread_m.sleep( sleepPeriodMillisecs );
			}
			catch( InterruptedException e )
			{
			}
		}
	}


/// fields -----------------------------------------------------------------------------------------
	/// update thread
	private static final	boolean	IS_THREAD_USED = false;
	private volatile		boolean	drawThreadPermission_m;
	private 					Thread	drawThread_m;

	/// image buffer
	private			int		width_m;
	private			int		height_m;
	private			int		outputPixels_m[];
	private			Image		outputImage_m;

	/// other
	private	volatile	int		frameCount_m;
	private	volatile	long	startTime_m;
}
