/// Copywrong (c) 2001,  artifex.  All wrongs reserved. ///




/**
 * Speedy, good quality small 2D blurs.
 *
 * Works on 2D int 'images' stored in 1D arrays.
 * Wraps around in a 'helical' way - each row/column wraps to the end of the
 * <i>next</i> one.
 * The top left and bottom right 1 by 2 area of pixels dont always get filled
 * in correctly.
 *
 * @author artifex
 * @date   2001
 */
public final class BlurFairlyGood
{
/// construction -----------------------------------------------------------------------------------
	public BlurFairlyGood( int iterations, int[] spare ) throws Exception
	{
		this( iterations, 0, spare );
	}

	public BlurFairlyGood( int iterations, int threshold, int[] spare ) throws Exception
	{
		setIterations( iterations_m );
		threshold_m  = threshold;
		setSpareBuffer( spare );
	}


/// commands ---------------------------------------------------------------------------------------
	public void setIterations( int iterations )
	{
		if( iterations < 0 )
		{
			iterations = 0;
		}
		iterations_m = iterations;
	}

	public void setThreshold( int threshold )
	{
		threshold_m = threshold;
	}

	public void setSpareBuffer( int[] spare ) throws Exception
	{
		if( (spare == null) || (spare.length == 0) )
		{
			throw new Exception( "invalid buffer" );
		}
		spare_m = spare;
	}


/// queries ----------------------------------------------------------------------------------------
	public int getIterations()
	{
		return iterations_m;
	}

	public int getThreshold()
	{
		return threshold_m;
	}

	public void blurGather3( final int width, final int height, final int[] pixels )
	{
		if( (width < 0) || (height < 0) || (spare_m.length != pixels.length) ||
		    (pixels.length != width * height) )
		{
			return;
		}

		blurGather3( iterations_m, width, height, spare_m, pixels );
	}

	public void blurGather5( final int width, final int height, final int[] pixels )
	{
		if( (width < 0) || (height < 0) || (spare_m.length != pixels.length) ||
		    (pixels.length != width * height) )
		{
			return;
		}

		blurGather5( iterations_m, width, height, spare_m, pixels );
	}

	/*public void blurSpread3( final int width, final int height, final int[] pixels )
	{
		if( (width < 0) || (height < 0) || (spare_m.length != pixels.length) ||
		    (pixels.length != width * height) )
		{
			return;
		}

		blurSpread3( iterations_m, threshold_m, width, height, pixelsSpare_m, pixels );
	}

	public void blurSpread5( final int width, final int height, final int[] pixels )
	{
		if( (width < 0) || (height < 0) || (spare_m.length != pixels.length) ||
		    (pixels.length != width * height) )
		{
			return;
		}

		blurSpread5( iterations_m, threshold_m, width, height, pixelsSpare_m, pixels );
	}*/


/// the real stuff ---------------------------------------------------------------------------------
	/**
	 * Speedily blurs a rectangular int array (in place) with a small hat filter.
    *
	 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
	 * one.
	 * the top left and bottom right (first and last) pixels dont always get filled
	 * in correctly.
	 * <code>
	 *    kernel shape:               121
	 *                   121          242
	 *                                121
	 *                (separate)   (resultant)
	 * </code>
	 *
	 * @param iterations  how many times to iterate the blurring
	 * @param width       width of the 2D array
	 * @param height      height of the 2D array
	 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
	 * @param pixels      input, and output, 2D array
	 */
	public static void blurGather3( final int iterations, final int width, final int height,
	                                final int[] pixelsSpare, final int[] pixels )
	{
		final int length = pixels.length;
		final int end    = length - 1;

		for( int a = iterations; a-- > 0; )
		{
			/// horizontally (into the spare array)
			int k2 = pixels[ 0 ];
			int k1 = pixels[ end ];
			int s1 = k1 + k2 + 1;
			int s2 = 0;
			for( int i = end;  i-- != 0; )
			{
				k2 = k1;
				k1 = pixels[ i ];
				s2 = s1;
				s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
				pixelsSpare[ i + 1 ] = (s1 + s2) >> 2;
			}
			pixelsSpare[ 0 ] = ((pixels[ end ] + k1) + s1 + 1) >> 2;

			/// vertically (back into the in/out array)
			k2 = pixels[ 0 ];
			k1 = pixels[ end ];
			s1 = k1 + k2 + 1;
			s2 = 0;
			for( int i = end, j = i;  i != 0; )
			{
				i = i >= width ? i : i + end;
				i -= width;

				k2 = k1;
				k1 = pixelsSpare[ i ];
				s2 = s1;
				s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
				pixels[ j ] = (s1 + s2) >> 2;

				j = i;
			}
			pixels[ 0 ] = ((pixels[ end ] + k1) + s1 + 1) >> 2;
		}
	}

	/**
	 * Speedily blurs a rectangular int array (in place) with a small boxy-hatty filter.
    *
	 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
	 * one.
	 * the top left and bottom right 1 by 2 area of pixels dont always get filled
	 * in correctly.
	 * <code>
	 *    kernel shape:                12221
	 *                                 24442
	 *                   12221         24442       - half way between box and hat
	 *                                 24442
	 *                                 12221
	 *                 (separate)   (resultant)
	 * </code>
	 *
	 * @param iterations  how many times to iterate the blurring
	 * @param width       width of the 2D array
	 * @param height      height of the 2D array
	 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
	 * @param pixels      input, and output, 2D array
	 */
	public static void blurGather5( final int iterations, final int width, final int height,
	                                final int[] pixelsSpare, final int[] pixels )
	{
		final int length = pixels.length;
		final int end    = length - 1;

		for( int a = iterations; a-- > 0; )
		{
			/// horizontally (into the spare array)
			int k2 = pixels[ end ];
			int k1 = pixels[ end - 1 ];
			int s1 = k1 + k2 + 1;
			int s2 = pixels[ end ] + pixels[ 0 ] + 1;
			int s3 = pixels[ 0 ] + pixels[ 1 ] + 1;
			int s4 = 0;
			//int empty = 0xFFFFFFFF;
			for( int i = end - 1;  i-- != 0; )
			{
				k2 = k1;
				k1 = pixels[ i ];
				s4 = s3;
				s3 = s2;
				s2 = s1;
				s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
				pixelsSpare[ i + 2 ] = (s1 + s2 + s3 + s4) >> 3;

				/*int nk = pixels[ i ];   /// switching off version
				int ns = nk + k1;
				if( (empty != 0) || (ns != 0) )
				{
					k2 = k1;
					k1 = nk;
					s4 = s3;
					s3 = s2;
					s2 = s1;
					s1 = ns + 1;   /// add 1 to make negatives round correctly
					empty = s1 | s2 | s3 | s4;
					pixelsSpare[ i + 2 ] = (s1 + s2 + s3 + s4) >> 3;
				}*/
			}
			k2 = k1;
			k1 = pixels[ end ];
			s4 = s3;
			s3 = s2;
			s2 = s1;
			s1 = k1 + k2 + 1;
			pixelsSpare[ 1 ] = (s1 + s2 + s3 + s4) >> 3;
			pixelsSpare[ 0 ] = ((pixels[ end-1 ] + k1 + 1) + s1 + s2 + s3) >> 3;

			/// vertically (back into the in/out array)
			k2 = pixels[ end ];
			k1 = pixels[ end - width ];
			s1 = k1 + k2 + 1;
			s2 = pixels[ end ] + pixels[ 0 ] + 1;
			s3 = pixels[ 0 ] + pixels[ width ] + 1;
			s4 = 0;
			//empty = 0xFFFFFFFF;
			for( int i2 = end, i1 = i2 - width, i = i1;  i != 0; )
			{
				i = i >= width ? i : i + end;
				i -= width;

				k2 = k1;
				k1 = pixelsSpare[ i ];
				s4 = s3;
				s3 = s2;
				s2 = s1;
				s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
				pixels[ i2 ] = (s1 + s2 + s3 + s4) >> 3;

				i2 = i1;
				i1 = i;

				/*i = i >= width ? i : i + end;   /// switching off version
				i -= width;

				int nk = pixelsSpare[ i ];
				int ns = nk + k1;
				if( (empty != 0) || (ns != 0) )
				{
					k2 = k1;
					k1 = nk;
					s4 = s3;
					s3 = s2;
					s2 = s1;
					s1 = ns + 1;   /// add 1 to make negatives round correctly
					empty = s1 | s2 | s3 | s4;
					pixels[ i2 ] = (s1 + s2 + s3 + s4) >> 3;
				}

				i2 = i1;
				i1 = i;*/
			}
			k2 = k1;
			k1 = pixels[ end ];
			s4 = s3;
			s3 = s2;
			s2 = s1;
			s1 = k1 + k2 + 1;
			pixelsSpare[ 1 ] = (s1 + s2 + s3 + s4) >> 3;
			pixelsSpare[ 0 ] = ((pixels[ end-width ] + k1 + 1) + s1 + s2 + s3) >> 3;
		}
	}

	/*public static void blurSpread( final int iterations, int threshold,
	                               final int width, final int height,
	                               final int[] pixelsSpare, final int[] pixels )
	{
		///    0
		///   000
		///  00000
		/// 0000000  16
	}*/


/// test -------------------------------------------------------------------------------------------
	public static void main( String[] params )
	{
		if( (params == null) || (params.length != 3) )
		{
			/// no params - print usage help
			System.out.println( "" );
			System.out.println( "public class BlurFairlyGood" );
			System.out.println( "---------------------------" );
			System.out.println( "" );
			System.out.println( "example:" );
			System.out.println( "\tjava BlurFairlyGood 3 8 4" );
			System.out.println( "- to perform the test using the value 4 at point (3,8)" );
		}
		else
		{
			int x = 0;
			int y = 0;
			int v = 0;
			try
			{
				x = Integer.parseInt( params[0] );
				y = Integer.parseInt( params[1] );
				v = Integer.parseInt( params[2] );
			}
			catch( Exception e ) {}
			test1( x, y, v );
		}
	}

	private static void test1( int x, int y, int v )
	{
		final int[] widHei = { 0, 0 };
		final int[] image  = makeTestImage( x, y, v, widHei );
		final int width  = widHei[0];
		final int height = widHei[1];

		final int[] spare  = new int[ width * height ];


		System.out.println( "\n<input>" );
		printImage( image, width, height );

		blurGather3( 1, width, height, spare, image );

		System.out.println( "\n<output>" );
		printImage( image, width, height );
	}

	private static int[] makeTestImage( int x, int y, int v, int[] widthHeight )
	{
		int[] testImage = { 00, 00, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    00, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00,
		                    00, 0, 0, 0, 0, 0, 0, 0, 0, 00, 00, };

		widthHeight[0] = 11;
		widthHeight[1] = 11;

		if( (x < 0) ) x = 0;
		else if( (x >= widthHeight[0]) ) x = widthHeight[0]-1;
		if( (y < 0) ) y = 0;
		else if( (y >= widthHeight[1]) ) y = widthHeight[1]-1;

		testImage[ x + (y * widthHeight[0]) ] = v;

		return testImage;
	}

	private static void printImage( int[] image, int width, int height )
	{
		System.out.println( "" );
		System.out.println( "width height:  " + width + " " + height );
		System.out.println( "" );

		for( int y = 0; y < height; ++y )
		{
			for( int x = 0; x < width; ++x )
			{
				System.out.print( "" + image[ x + (y * width) ] + " " );
			}
			System.out.print( "\n" );
		}
	}


/// fields -----------------------------------------------------------------------------------------
	private	int iterations_m;
	private	int threshold_m;

	private	int[] spare_m;
}

