/// Copywrong (c) 2001,  artifex.  All wrongs reserved. ///

import java.util.Random;
import java.awt.Image;
import java.awt.image.PixelGrabber;




public class FieryPixels
	extends AppletAnimation
{
/// construction -----------------------------------------------------------------------------------


/// AppletAnimation overrides ----------------------------------------------------------------------
	public void initDerived()
	{
		loadParameters();

		width_m  = getWidth_();
		height_m = getHeight_();


		/// make blank main buffers
		pixels_m      = new int[ width_m * height_m ];
		pixelsOther_m = new int[ width_m * height_m ];


		/// make other stuff
		heatMap_m = loadHeatMap( startImageName_m, width_m, height_m, null );
		coolMap_m = makeCoolMap( width_m, height_m, pixelsOther_m, null );
		initWarpMap( width_m, height_m, pixelsOther_m );


		c3d_m = new cube3d( this, width_m, height_m );
	}

	/*public void startDerived()
	{
	}

	public void stopDerived()
	{
	}

	public void destroyDerived()
	{
	}*/

	protected void drawFrame()
	{
//		heatAndCool( heatMap_m, coolMap_m, pixels_m, pixelsOther_m );
//		BlurFairlyGood.blurGather5( 1, width_m, height_m, pixels_m, pixelsOther_m );
//		warp( width_m, height_m, pixelsOther_m, pixels_m );
//
//		convertByteGrayToARGB( pixels_m, getPixels() );

		warp( width_m, height_m, pixels_m, pixelsOther_m );
		heatAndCool( heatMap_m, coolMap_m, pixelsOther_m, pixels_m );
		BlurFairlyGood.blurGather5( 1, width_m, height_m, pixelsOther_m, pixels_m );

		convertByteGrayToARGB( pixels_m, getPixels() );

		//System.out.print( "" + getFrameCount() + " " );
	}

	protected long getSleepPeriodMillisecs()
	{
		return  SLEEP_PERIOD_MILLISECS;
	}

	protected int getFrameSkipRate()
	{
		return 0;
	}

	public String getAppletInfo()
	{
		return "FieryCube applet. Copywrong (c) 2001, artifex. All wrongs reserved.";
	}

	public String[][] getParameterInfo()
	{
		return  new String[][] { { IMAGE_PARAM,          "string",   "heatmap image file name" },
		                         { WARP_STRENGTH_PARAM,  "integer",  "strength of the flame disturbance (0-8)" },
		                         { WARP_BROADNESS_PARAM, "integer",  "broadness of the flame disturbance (1-16)" },
		                         { UPDRAFT_SPEED_PARAM,  "integer",  "speed of upward motion of the flame (-128-+128)" },
		                         { COOL_FACTOR_PARAM,    "integer",  "cooling rate (0-64)" },
		                         { HEAT_NOISE_PARAM,     "integer",  "unevenness of heating (0-16)" },
		                         { WARP_INTERP_PARAM,    "integer",  "number of frames between new warps (0-6)" } };
	}


/// initialisation ---------------------------------------------------------------------------------
	private void loadParameters()
	{
		startImageName_m = getParameter( IMAGE_PARAM );

		warpStrength_m  = getParameterInt( WARP_STRENGTH_PARAM,    0,   8, warpStrength_m );
		warpBroadness_m = getParameterInt( WARP_BROADNESS_PARAM,   1,  16, warpBroadness_m );
		updraftSpeed_m  = getParameterInt( UPDRAFT_SPEED_PARAM, -128, 128, updraftSpeed_m );
		coolFactor_m    = getParameterInt( COOL_FACTOR_PARAM,      0,  64, coolFactor_m );
		heatNoise_m     = getParameterInt( HEAT_NOISE_PARAM,       0,  16, heatNoise_m );
		warpInterpolationFraction_m = getParameterInt( WARP_INTERP_PARAM, 0, 6, warpInterpolationFraction_m );
	}

	private int getParameterInt( String name, int min, int max, int dflt )
	{
		int val = dflt;
		final String valString = getParameter( name );
		if( valString != null )
		{
			try
			{
				val = Integer.parseInt( valString );
				if( val < min )
				{
					val = min;
				}
				else if( val > max )
				{
					val = max;
				}
			}
			catch( Exception ignore ) {}
		}

		return val;
	}

	private int[] loadHeatMap( final String startImageName,
	                           final int width, final int height, int[] pixels )
	{
		if( pixels == null )
		{
			pixels = new int[ width * height ];
		}

		if( startImageName != null )
		{
			Image startImage = getImage( getDocumentBase(), startImageName );

			PixelGrabber pg = new PixelGrabber( startImage, 0, 0, width, height, pixels, 0, width );
			try
			{
				pg.grabPixels();
			}
			catch( InterruptedException e )
			{
				throw new Error( e.getMessage() );
			}

			/// convert to byte grayscale
			convertARGBtoByteGray( pixels, pixels );
		}

		return pixels;
	}

	private int[] makeCoolMap( final int width, final int height,
	                           final int[] pixelsOther, int[] pixels )
	{
		if( pixels == null )
		{
			pixels = new int[ width * height ];
		}

		for( int i = pixels.length;  i-- > 0; )
		{
			pixels[ i ] = coolFactor_m;
		}


		/*/// dot with noise
		final Random randSeries = new Random();
		for( int i = pixels.length /2;  i-- > 0; )
		{
			int indx = (randSeries.nextInt() & 0x7FFFFFFF) % pixels.length;
			pixels[ indx ] = randSeries.nextInt() & 0x0000001F;
		}

		/// blur
		BlurFairlyGood.blurGather3( 4, width, height, pixelsOther, pixels );

		/// dot with noise
		for( int i = pixels.length /2;  i-- > 0; )
		{
			int indx = (randSeries.nextInt() & 0x7FFFFFFF) % pixels.length;
			pixels[ indx ] = randSeries.nextInt() & 0x0000001F;
		}

		/// blur
		BlurFairlyGood.blurGather3( 4, width, height, pixelsOther, pixels );*/


		return pixels;
	}

	private void initWarpMap( final int width, final int height, final int[] pixelsOther )
	{
		warpMapX_m = new int[ width * height ];
		warpMapY_m = new int[ width * height ];

		interpolatedWarpX_m = new int[ width * height ];
		interpolatedWarpY_m = new int[ width * height ];
		warpIncrementX_m    = new int[ width * height ];
		warpIncrementY_m    = new int[ width * height ];


		/*/// test - straight upwards
		for( int i = warpMapX_m.length;  i-- > 0; )
		{
			warpMapX_m[ i ] = 0;
			warpMapY_m[ i ] = 1;
		}*/


		final Random randSeries = new Random();
		final int strengthShift = 32 - warpStrength_m;

		/// dot with noise
		for( int i = warpMapY_m.length /4;  i-- > 0; )
		{
			int indx = (randSeries.nextInt() & 0x7FFFFFFF) % warpMapY_m.length;
			warpMapX_m[ indx ] = randSeries.nextInt() >> strengthShift;

			indx = (randSeries.nextInt() & 0x7FFFFFFF) % warpMapY_m.length;
			warpMapY_m[ indx ] = randSeries.nextInt() >> strengthShift;
		}

		/// blur
		BlurFairlyGood.blurGather5( warpBroadness_m, width, height, pixelsOther, warpMapX_m );
		BlurFairlyGood.blurGather5( warpBroadness_m, width, height, pixelsOther, warpMapY_m );


		/*/// test - some stats on the warp
		int sum = 0;  int pos = 0;  int neg = 0;
		for( int i = pixels.length;  i-- > 0; )
		{
			if( yShift_m[ i ] > 0 ) ++pos;
			if( yShift_m[ i ] < 0 ) ++neg;
			sum += yShift_m[ i ];
		}
		System.out.println( "~ count= " + pixels.length + "  sum= " + sum + "  signbias= " + (((float)pos/pixels.length - (float)neg/pixels.length)*100) + "%  ave= " + ((float)sum/pixels.length) + " ~" );
		System.out.println( "" );*/
	}


/// rendering  -------------------------------------------------------------------------------------
	private void heatAndCool( final int[] heatMap, final int[] coolMap,
	                          final int[] pixelsIn, final int[] pixelsOut )
	{
		if( startImageName_m == null )
		{
			c3d_m.updateAndDraw( heatMap_m );
			convertARGBtoByteGray( heatMap_m, heatMap_m );
		}

		final int heatNoise = heatNoise_m;
		for( int i = pixelsIn.length; i-- != 0; )
		{
			randSeed_m = (randSeed_m * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
			final int rand  = (int)(randSeed_m >>> 16);

			final int noise = rand & (0xFFFFFFFF << heatNoise);
			final int heat  = heatMap[ i ] & noise;
			final int cool  = coolMap[ i ];

			final int in = pixelsIn[ i ];
			int out = in - cool;
			out &= ~(out >> 31);   /// clamp to 0 min
			out |= heat;

			pixelsOut[ i ] = out;
		}
	}

	private void warp( final int width, final int height,
	                   final int[] pixelsIn, final int[] pixelsOut )
	{
		makeWarpMap();

		final int length = pixelsOut.length;
		for( int i = pixelsOut.length; i-- > 0; )
		{
			/// add incrs to currents
			final int currentX = interpolatedWarpX_m[ i ];
			final int currentY = interpolatedWarpY_m[ i ];
			interpolatedWarpX_m[ i ] += warpIncrementX_m[ i ];
			interpolatedWarpY_m[ i ] += warpIncrementY_m[ i ];

			/// >> vals from currents
			int warpX = currentX >> warpInterpolationFraction_m;
			int warpY = currentY >> warpInterpolationFraction_m;

			/// bias upwards
			warpY += updraftSpeed_m;

			/// derive index from shifted vals
			int warpedIndex = i + warpX + (warpY * width);
			/*if( warpedIndex < 0 )
			{
				warpedIndex = 0;
			}
			else if( warpedIndex >= length )
			{
				warpedIndex = length-1;
			}*/
			warpedIndex &= ~(warpedIndex >> 31);   /// clamp to 0 min
			final int maxCmp = (warpedIndex - length) >> 31;
			warpedIndex = (warpedIndex & maxCmp) | ((length-1) & ~maxCmp);   /// clamp to max

			/// warp pixel
			pixelsOut[ i ] = pixelsIn[ warpedIndex ];
		}
	}

	private void makeWarpMap()
	{
		/// only every few frames
		if( ( getFrameCount() & ((1 << warpInterpolationFraction_m) -1) ) == 0 )
		{
			final int length = warpIncrementX_m.length;

			/// pick new position for warp maps
			final int offset = (nextRandomInt() & 0x7FFFFFFF) % length;

			/// set warp increments to new position vals minus current vals
			int pos = length - offset - 1;
			for( int i = length;  i-- > 0;  pos = pos != 0 ? pos-1 : length-1 )
			{
				warpIncrementX_m[ i ] = warpMapX_m[ pos ] - (interpolatedWarpX_m[ i ] >> warpInterpolationFraction_m);
				warpIncrementY_m[ i ] = warpMapY_m[ pos ] - (interpolatedWarpY_m[ i ] >> warpInterpolationFraction_m);
			}
		}
	}

	private static void convertByteGrayToARGB( final int[] indexPixels, final int[] argbPixels )
	{
		for( int i = argbPixels.length; i-- != 0; )
		{
			argbPixels[ i ] = PALETTE_ARGB[ indexPixels[ i ] ];
		}
	}

	private static void convertARGBtoByteGray( final int[] argbPixels, final int[] grayPixels )
	{
		for( int i = grayPixels.length; i-- != 0; )
		{
			final int argb = argbPixels[ i ];

			final int r = (argb >>> 16) & 0xFF;
			final int g = (argb >>>  8) & 0xFF;
			final int b = (argb       ) & 0xFF;

			final int gray = (r + g + b) / 3;

			grayPixels[ i ] = gray;
		}
	}

	private int nextRandomInt()
	{
		randSeed_m = (randSeed_m * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
		return (int)(randSeed_m >>> 16);
	}


/// test -------------------------------------------------------------------------------------------
	/*public static void main( String[] params )
	{
		if( (params == null) || (params.length != 1) )
		{
			/// no params - print usage help
			System.out.println( "" );
			System.out.println( "public class FieryPixels" );
			System.out.println( "------------------------" );
			System.out.println( "" );
			System.out.println( "example:" );
			System.out.println( "\tjava FireyPixels 5" );
			System.out.println( "- to perform the test with 5 iterations" );
		}
		else
		{
			int i = 1;
			try
			{
				i = Integer.parseInt( params[0] );
			}
			catch( Exception e ) {}
			test1( i );
		}
	}

	private static void test1( int i )
	{
		final int[] widHei = { 0, 0 };
		final int[] image  = makeTestImage( 255, widHei );
		final int width  = widHei[0];
		final int height = widHei[1];

		final int[] spare  = new int[ width * height ];


		System.out.println( "\n<input>" );
		printImages( image, spare, width, height );

		//makeCoolMap( width, height, spare, image );
		//heatAndCool( int[] heatMap, int[] coolMap, int[] pixelsIn, int[] pixelsOut );
		//convertByteGrayToARGB( image, spare );
		convertARGBtoByteGray( image, spare );

		System.out.println( "\n<output>" );
		printImages( image, spare, width, height );
	}

	private static int[] makeTestImage( int v, int[] widthHeight )
	{
		int[] testImage = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, v, v, v, 0, 0, 0, 0,
		                    0, 0, 0, 0, v, v, v, 0, 0, 0, 0,
		                    0, 0, 0, 0, v, v, v, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };

		widthHeight[0] = 11;
		widthHeight[1] = 11;

		return testImage;
	}

	private static void printImages( int[] image1, int[] image2, int width, int height )
	{
		System.out.println( "" );
		System.out.println( "width height:  " + width + " " + height );
		System.out.println( "" );

		for( int y = 0; y < height; ++y )
		{
			for( int x = 0; x < width; ++x )
			{
				System.out.print( "" + image1[ x + (y * width) ] + " " );
			}
			System.out.print( "\t\t" );
			for( int x = 0; x < width; ++x )
			{
				System.out.print( "" + image2[ x + (y * width) ] + " " );
			}
			System.out.print( "\n" );
		}
	}*/


/// fields -----------------------------------------------------------------------------------------
	/// html tag parameter values
	private		String	startImageName_m;
	private		int		warpStrength_m   = 6;
	private		int		warpBroadness_m  = 4;
	private		int		updraftSpeed_m   = 4;
	private		int		coolFactor_m     = 14;
	private		int		heatNoise_m      = 4;
	private		int		warpInterpolationFraction_m = 2;   /// 2 to the power of this

	/// buffer dimensions
	private		int 	width_m;
	private		int 	height_m;

	/// the pixel buffers
	private		int[]	pixels_m;
	private		int[]	pixelsOther_m;

	/// image modifier precalcs
	private		int[]	heatMap_m;
	private		int[]	coolMap_m;

	private		cube3d	c3d_m;

	/// warp things
	private		int[]	warpMapX_m;
	private		int[]	warpMapY_m;
	private		int[]	interpolatedWarpX_m;
	private		int[]	interpolatedWarpY_m;
	private		int[]	warpIncrementX_m;
	private		int[]	warpIncrementY_m;

	private		long	randSeed_m = (System.currentTimeMillis() ^ 0x5DEECE66DL) & ((1L << 48) - 1);


	/// constants
	private static final	String IMAGE_PARAM          = "StartImage";
	private static final	String WARP_STRENGTH_PARAM  = "WarpStrength";
	private static final	String WARP_BROADNESS_PARAM = "WarpBroadness";
	private static final	String UPDRAFT_SPEED_PARAM  = "UpdraftSpeed";
	private static final	String COOL_FACTOR_PARAM    = "CoolFactor";
	private static final	String HEAT_NOISE_PARAM     = "HeatNoise";
	private static final	String WARP_INTERP_PARAM    = "WarpInterpolation";
	private static final	long   SLEEP_PERIOD_MILLISECS = 20L;


	/// palette
	private static final	byte  FIRE_RED[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 17, 17, 18, 18, 19, 20, 20, 21, 22, 22, 23, 23, 24, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 32, 32, 33, 34, 34, 35, 36, 36, 37, 38, 38, 39, 40, 40, 41, 41, 42, 43, 43, 44, 44, 45, 46, 46, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 52, 52, 52, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 57, 58, 58, 58, 58, 59, 59, 59, 59, 59, 60, 60, 60, 60, 60, 60, 60, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62 };
	private static final	byte  FIRE_GREEN[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 21, 21, 21, 22, 22, 23, 23, 23, 24, 24, 25, 25, 26, 26, 26, 27, 27, 28, 28, 29, 29, 29, 30, 30, 31, 31, 32, 32, 32, 33, 33, 34, 34, 35, 35, 35, 36, 36, 37, 37, 37, 38, 38, 39, 39, 40, 40, 40, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 50, 51, 51, 51, 52, 52, 52, 52, 53, 53, 53, 53, 54, 54, 54, 54, 55, 55, 55, 55, 55, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 58, 58, 58, 58, 58, 58, 59, 59, 59, 59, 59, 59, 59, 59, 60, 60, 60, 60, 60, 60 };
	private static final	byte  FIRE_BLUE[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11 };

	private static final	int[] PALETTE_ARGB;

	static
	{
		PALETTE_ARGB = new int[ 256 ];

		for( int i = PALETTE_ARGB.length; i-- > 0; )
		{
			final int r = ((int)FIRE_RED[ i ]   << 2) & 0xFF;
			final int g = ((int)FIRE_GREEN[ i ] << 2) & 0xFF;
			final int b = ((int)FIRE_BLUE[ i ]  << 2) & 0xFF;

			PALETTE_ARGB[ i ] = (0xFF000000) | (r << 16) | (g << 8) | b;
		}
	}
}
