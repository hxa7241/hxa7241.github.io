/// adapted from:

// | cube3d (c)1997 by Peter Walser
// |
// | Feel free to use this applet or parts of the source code
// | for non-commercial purpose, you just have to set a link to
// | my HomePage. Thank you.
// |
// | Peter Walser
// | proxima@active.ch
// | http://www2.active.ch/~proxima
// | -----------------------------------------------------------

import java.awt.*;
import java.awt.image.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;



public class cube3d
{
	private Image img;
	private Graphics gx;


	private Date   currentTime = new Date();
	private static final String HHmmss = "HH:mm:ss";
	private DateFormat df = new SimpleDateFormat( HHmmss );


	private double rotatex=32;
	private double rotatey=14;
	private double rotatez=20;

	private Color bgcolor=new Color(0,0,0);
	private Color fgcolor=new Color(255,255,255);

	private double centerx;
	private double centery;

	private int width;
	private int height;

	private double x[]=new double[10];
	private double y[]=new double[10];
	private double z[]=new double[10];
	private int xx[]=new int[10];
	private int yy[]=new int[10];

	private double pi=3.14159265;

	//private Image idx_offscreen=null;
	//private Graphics g2;

	public cube3d( Component cmponent, int width, int height )
	{
		img = cmponent.createImage( width, height );
		gx = (Graphics)img.getGraphics();
		gx.setFont( new Font( "Dialog", Font.BOLD, height/5 ) );

		//Stroke stroke = new BasicStroke( 5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
		//gx.setStroke( stroke );

		df.setTimeZone( TimeZone.getDefault() );


		this.width = width;
		this.height = height;

		centerx=(double)width/2;
		centery=(double)height/2;

		rotatex=(rotatex/180*pi)/20;
		rotatey=(rotatey/180*pi)/20;
		rotatez=(rotatez/180*pi)/20;

	//Declaration of 3dCube
    	x[1]=-1;
		y[1]=-1;
		z[1]=-1;
		x[2]= 1;
		y[2]=-1;
		z[2]=-1;
		x[3]= 1;
		y[3]=-1;
		z[3]= 1;
		x[4]=-1;
		y[4]=-1;
		z[4]= 1;
		x[5]=-1;
		y[5]= 1;
		z[5]=-1;
		x[6]= 1;
		y[6]= 1;
		z[6]=-1;
		x[7]= 1;
		y[7]= 1;
		z[7]= 1;
		x[8]=-1;
		y[8]= 1;
		z[8]= 1;

		//idx_offscreen=createImage(this.size().width,this.size().height);
		//g2=idx_offscreen.getGraphics();
	}

	public void updateAndDraw( int[] pixels )
	{
		double qx,qy,qz;

		for (int i=1;i<=8;i++)
		{

		// Rotation arround x-axis

			qy=y[i];
			qz=z[i];
			y[i]= qy*Math.cos(rotatex) - qz*Math.sin(rotatex);
			z[i]= qz*Math.cos(rotatex) + qy*Math.sin(rotatex);

		// Rotation arround y-axis

			qz=z[i];
			qx=x[i];
			z[i]= qz*Math.cos(rotatey) - qx*Math.sin(rotatey);
			x[i]= qx*Math.cos(rotatey) + qz*Math.sin(rotatey);

		// Rotation arround z-axis

			qx=x[i];
			qy=y[i];
			x[i]= qx*Math.cos(rotatez) - qy*Math.sin(rotatez);
			y[i]= qy*Math.cos(rotatez) + qx*Math.sin(rotatez);
		}

	// Calculate Points (3d -> 2d)
		for (int i=1;i<9;i++)
		{
			xx[i]=(int)(x[i]*(5/(5+z[i]))*centerx/2.5+centerx);
			yy[i]=(int)(y[i]*(5/(5+z[i]))*centery/2.5+centery*0.8);
		}

	// clear
		gx.setColor(bgcolor);
		gx.fillRect(0,0,(int)(centerx*2),(int)(centery*2));

	// Draw Cube edges
		gx.setColor(fgcolor);
		for( int ty = -2; ty < 3; ++ty)
		{
			for( int tx = -2; tx < 3; ++tx )
			{
				for (int i=1;i<5;i++)
				{
					gx.drawLine( xx[i]+tx,   yy[i]+ty,   xx[i+4]+tx,     yy[i+4]+ty     );
					gx.drawLine( xx[i]+tx,   yy[i]+ty,   xx[(i%4)+1]+tx, yy[(i%4)+1]+ty );
					gx.drawLine( xx[i+4]+tx, yy[i+4]+ty, xx[(i%4)+5]+tx, yy[(i%4)+5]+ty );
				}
			}
		}


		/// draw time, etc...
		currentTime.setTime( System.currentTimeMillis() );
		String timeString = df.format( currentTime );
		gx.drawString( timeString, width/10, (int)(height*(0.95)) );



		//paint(g2);
		//g.drawImage(idx_offscreen,0,0,this);

		PixelGrabber pg = new PixelGrabber( img, 0, 0, width, height, pixels, 0, width );
		try
		{
			pg.grabPixels();
		}
		catch( InterruptedException e )
		{
			throw new Error( e.getMessage() );
		}
	}
}




/*
		gx.setColor(Color.black);
		gx.fillRect(0,0,this.size().width,this.size().height);
		gx.setColor(new Color(0,255,0));
		gx.drawString("TIME",10,20);
		gx.drawLine(10,26,160,26);
		gx.drawString("Please wait while initializing...",10,92);


		String username = System.getProperty( "user.name" );

		//long time = System.currentTimeMillis();
		Date time = new Date();
		String HHmmss = "HH:mm:ss";
		DateFormat df = new SimpleDateFormat( HHmmss );

		String timeString = df.format( time );



		//Image img = make image
		Image img = createImage( width, height );
		Graphics gx = img.getGraphics();
		Stroke stroke = new BasicStroke( 5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
		gx.setStroke( stroke );

		gx.draw(  )

		PixelGrabber pg = new PixelGrabber( img, 0, 0, width, height, pixels, 0, width );
		try
		{
			pg.grabPixels();
		}
		catch( InterruptedException e )
		{
			throw new Error( e.getMessage() );
		}
*/