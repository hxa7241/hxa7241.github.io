// Minimal Screensaver
// ---------------------
// (c) 1998 Lucian Wischik. You may do whatever you want with this code, without restriction.
//
// This code is a basic minimal screensaver. It does not use SCRNSAVE.LIB or any other library:
// absolutely all the code is in this source file.
// The saver works perfectly fine under '95 and NT. It respects the Plus! configuration settings
// (password delay, mouse movement threshold). It can handle passwords correctly.
// It makes all the correct calls in the correct places, including calls that are undocumented
// by Microsoft.
// This code accompanies the guide 'How To Write a 32bit Screen Saver'. All documentation for this
// code is in that guide. It can be found at www.wischik.com/scr/
//
// Notes:
// 0. All of this is a real hassle. If you used my ScrPlus library then it would all be much much
// easier. And you'd get lots of extra features, like a standard 'Plus!' style configuration dialog
// with preview in it, and proper handling of hot corners under NT as well as '95, and a high
// performance multimedia timer, and lots of examples including some that use full-screen DirectDraw.
// www.wischik.com/scr/
// If you have C++Builder then you should use my ScrPlus/C++Builder library which has an expert
// and components for easily generating screensavers.
// If you remain blind to the joys of using ScrPlus and are willing to waste time programming it
// all yourself, then read on...
// 1. Having a 'DEBUG' flag, with diagnostic output, is ABSOLUTELY ESSENTIAL. I can guarantee
// that if you develop a screensaver without diagnostic output for every single message that
// you handle, your screensaver will crash and you won't know why.
// 2. If you also wanted to write a configuration dialog that was able to set the standard Plus!
// options, you'd need to use two additional calls: SystemAgentDetect, and ScreenSaverChanged.
// They are documented in my 'how to write a 32bit screensaver' technical guide.
// 3. NT and '95 handle passwords differently. Under NT, the saver must terminate and then the
// verify-password dialog comes up. If the user fails, then the screensaver is launched again from
// scratch. Under '95, the password dialog comes up while the saver is running.
// 4. You should probably use WM_TIMER messages for your animation, rather than idle-processing.
// By using WM_TIMER messages your animation will keep going even when (under '95) the password
// dialog is up.
// 5. Changing the saver to allow interraction is easy. All you have to do is figure out which
// messages (keyboard, mouse, ...) will be used by you and stop them from closing the window.
// 6. Changing the saver to implement your own password routine is easy under '95: all you have
// to do is change the VerifyPassword routine. Under NT it's not really possible.

/// modified by artifex 2001/07


#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <regstr.h>
#include <stdlib.h>
#pragma hdrstop
#include "resource.h"

#define DEBUG FALSE

#define REGSTR_PATH_PLUSSCR (REGSTR_PATH_SETUP "\\Screen Savers")
//#define REGSTR_PATH_CONFIG  ("Software\\Lu\\Minimal Saver")
#define REGSTR_PATH_CONFIG  ("Software\\artifex\\FieryCube")
enum TScrMode {smNone,smConfig,smPassword,smPreview,smSaver};
TScrMode ScrMode=smNone;
HINSTANCE hInstance=NULL;
HWND hScrWindow=NULL;
class TSaverSettings; TSaverSettings *ss=NULL;
//char *MessageName(UINT);


#include "WinSaverGeneratorFire.h"

LONG __stdcall unhandledExceptionFilterFunction( LPEXCEPTION_POINTERS )// pExcPtrs )
{
	return EXCEPTION_EXECUTE_HANDLER;
}


#if DEBUG
void Debug(char *c) {OutputDebugString(c); OutputDebugString("\n");}
#else
void Debug(char *) {}
#endif


// CheckHots: this routine checks for Hot Corner services.
// It first tries with SAGE.DLL, which comes with Windows Plus!
// Failint this it tries with ScrHots, a third-party hot-corner
// service program written by the author that is freely
// distributable and works with NT and '95.
// It's not actually used in the saver, but code is included here
// just to be useful.
BOOL CheckHots()
{ typedef BOOL (WINAPI *SYSTEMAGENTDETECT)();
  HINSTANCE sagedll=LoadLibrary("Sage.dll");
  if (sagedll!=NULL)
  { SYSTEMAGENTDETECT detectproc=(SYSTEMAGENTDETECT)
        GetProcAddress(sagedll,"System_Agent_Detect");
    BOOL res=FALSE;
    if (detectproc!=NULL) res=detectproc();
    FreeLibrary(sagedll);
    if (res) return TRUE;
  }
  HINSTANCE hotsdll=LoadLibrary("ScrHots.dll");
  if (hotsdll!=NULL)
  { SYSTEMAGENTDETECT detectproc=(SYSTEMAGENTDETECT)
        GetProcAddress(hotsdll,"System_Agent_Detect");
    BOOL res=FALSE;
    if (detectproc!=NULL) res=detectproc();
    FreeLibrary(hotsdll);
    if (res) return TRUE;
  }
  return FALSE;
}

// NotifyHots: if you make any changes to the hot corner
// information in the registry, you must call NotifyHots
// to infxorm the hot corner services of your change.
// It's not actually used in the saver, but code is included here
// just to be useful.
void __fastcall NotifyHots()
{ typedef VOID (WINAPI *SCREENSAVERCHANGED)();
  HINSTANCE sagedll=LoadLibrary("Sage.DLL");
  if (sagedll!=NULL)
  { SCREENSAVERCHANGED changedproc=(SCREENSAVERCHANGED)
        GetProcAddress(sagedll,"Screen_Saver_Changed");
    if (changedproc!=NULL) changedproc();
    FreeLibrary(sagedll);
  }
  HINSTANCE hotsdll=LoadLibrary("ScrHots.dll");
  if (hotsdll!=NULL)
  { SCREENSAVERCHANGED changedproc=(SCREENSAVERCHANGED)
        GetProcAddress(hotsdll,"Screen_Saver_Changed");
    if (changedproc!=NULL) changedproc();
    FreeLibrary(hotsdll);
  }
}


BOOL VerifyPassword(HWND hwnd)
{ // Under NT, we return TRUE immediately. This lets the saver quit, and the system manages passwords.
  // Under '95, we call VerifyScreenSavePwd. This checks the appropriate registry key and, if necessary, pops up a verify dialog
  OSVERSIONINFO osv; osv.dwOSVersionInfoSize=sizeof(osv); GetVersionEx(&osv);
  if (osv.dwPlatformId==VER_PLATFORM_WIN32_NT) return TRUE;
  HINSTANCE hpwdcpl=::LoadLibrary("PASSWORD.CPL");
  if (hpwdcpl==NULL) {Debug("Unable to load PASSWORD.CPL. Aborting");return TRUE;}
  typedef BOOL (WINAPI *VERIFYSCREENSAVEPWD)(HWND hwnd);
  VERIFYSCREENSAVEPWD VerifyScreenSavePwd;
  VerifyScreenSavePwd=(VERIFYSCREENSAVEPWD)GetProcAddress(hpwdcpl,"VerifyScreenSavePwd");
  if (VerifyScreenSavePwd==NULL) {Debug("Unable to get VerifyPwProc address. Aborting");FreeLibrary(hpwdcpl);return TRUE;}
  Debug("About to call VerifyPwProc"); BOOL bres=VerifyScreenSavePwd(hwnd); FreeLibrary(hpwdcpl);
  return bres;
}
void ChangePassword(HWND hwnd)
{ // This only ever gets called under '95, when started with the /a option.
  HINSTANCE hmpr=::LoadLibrary("MPR.DLL");
  if (hmpr==NULL) {Debug("MPR.DLL not found: cannot change password.");return;}
  typedef VOID (WINAPI *PWDCHANGEPASSWORD) (LPCSTR lpcRegkeyname,HWND hwnd,UINT uiReserved1,UINT uiReserved2);
  PWDCHANGEPASSWORD PwdChangePassword=(PWDCHANGEPASSWORD)::GetProcAddress(hmpr,"PwdChangePasswordA");
  if (PwdChangePassword==NULL) {FreeLibrary(hmpr); Debug("PwdChangeProc not found: cannot change password");return;}
  PwdChangePassword("SCRSAVE",hwnd,0,0); FreeLibrary(hmpr);
}



class TSaverSettings
{ public:
  HWND hwnd;
  DWORD PasswordDelay;   // in seconds
  DWORD MouseThreshold;  // in pixels
  BOOL  MuteSound;
  POINT InitCursorPos;
  DWORD InitTime;        // in ms
  UINT  idTimer;         // a timer id, because this particular saver uses a timer
  BOOL  IsDialogActive;
  BOOL  ReallyClose;     // for NT, so we know if a WM_CLOSE came from us or it.
  BOOL  FlashScreen;     // this is a user-configuration option, particular to this example saver
  TSaverSettings();
  void ReadGeneralRegistry();
  void ReadConfigRegistry();
  void WriteConfigRegistry();
  void CloseSaverWindow();
  void StartDialog();
  void EndDialog();
};
TSaverSettings::TSaverSettings() {hwnd=NULL; ReallyClose=FALSE; idTimer=0;}
void TSaverSettings::ReadGeneralRegistry()
{ PasswordDelay=15; MouseThreshold=50; IsDialogActive=FALSE; // default values in case they're not in registry
  LONG res; HKEY skey; DWORD valtype, valsize, val;
  res=RegOpenKeyEx(HKEY_CURRENT_USER,REGSTR_PATH_PLUSSCR,0,KEY_ALL_ACCESS,&skey);
  if (res!=ERROR_SUCCESS) return;
  valsize=sizeof(val); res=RegQueryValueEx(skey,"Password Delay",0,&valtype,(LPBYTE)&val,&valsize); if (res==ERROR_SUCCESS) PasswordDelay=val;
  valsize=sizeof(val); res=RegQueryValueEx(skey,"Mouse Threshold",0,&valtype,(LPBYTE)&val,&valsize);if (res==ERROR_SUCCESS) MouseThreshold=val;
  valsize=sizeof(val); res=RegQueryValueEx(skey,"Mute Sound",0,&valtype,(LPBYTE)&val,&valsize);     if (res==ERROR_SUCCESS) MuteSound=val;
  RegCloseKey(skey);
}
void TSaverSettings::ReadConfigRegistry()
{ FlashScreen=FALSE;
  LONG res; HKEY skey; DWORD valtype, valsize, val;
  res=RegOpenKeyEx(HKEY_CURRENT_USER,REGSTR_PATH_CONFIG,0,KEY_ALL_ACCESS,&skey);
  if (res!=ERROR_SUCCESS) return;
  valsize=sizeof(val); res=RegQueryValueEx(skey,"Flash Screen",0,&valtype,(LPBYTE)&val,&valsize);   if (res==ERROR_SUCCESS) FlashScreen=val;
  RegCloseKey(skey);
}
void TSaverSettings::WriteConfigRegistry()
{ /*LONG res; HKEY skey; DWORD val, disp;
  res=RegCreateKeyEx(HKEY_CURRENT_USER,REGSTR_PATH_CONFIG,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&skey,&disp);
  if (res!=ERROR_SUCCESS) return;
  val=FlashScreen; RegSetValueEx(skey,"Flash Screen",0,REG_DWORD,(CONST BYTE*)&val,sizeof(val));
  RegCloseKey(skey);*/
}
void TSaverSettings::CloseSaverWindow() {ReallyClose=TRUE; PostMessage(hwnd,WM_CLOSE,0,0);}
void TSaverSettings::StartDialog() {IsDialogActive=TRUE;SendMessage(hwnd,WM_SETCURSOR,0,0);}
void TSaverSettings::EndDialog()   {IsDialogActive=FALSE;SendMessage(hwnd,WM_SETCURSOR,0,0);GetCursorPos(&InitCursorPos);}


LRESULT CALLBACK SaverWindowProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{ // If you have a problem that's really not going away, put a debug in here:
  // Debug(MessageName(msg));
  // This will make a log of every single message that gets sent to the window.

	static WinSaverGeneratorFire* pGenerator = 0;
	static char keyPress = 0;

  switch (msg)
  { case WM_CREATE:
    { Debug("WM_CREATE..."); ss->hwnd=hwnd;
      GetCursorPos(&(ss->InitCursorPos)); ss->InitTime=GetTickCount();
      ss->idTimer=SetTimer(hwnd,0,20,NULL);   /// windows appears to round this up to the nearest ten
      ::SetUnhandledExceptionFilter( unhandledExceptionFilterFunction );
    } break;
    case WM_TIMER:
    {
      /*if (ss->FlashScreen)
      {
      	static count = 0;
      	HDC hdc=GetDC(hwnd); RECT rc; GetClientRect(hwnd, &rc);
        FillRect(hdc,&rc,GetSysColorBrush( count++ % 25 ));
        ReleaseDC(hwnd,hdc);
      }*/
		HDC  hdc = ::GetDC( hwnd );
		RECT rc;
		::GetClientRect( hwnd, &rc );
		const sdword width  = sdword(rc.right-rc.left);
		const sdword height = sdword(rc.bottom-rc.top);

		try
		{
			if( pGenerator == 0 )
			{
				pGenerator = new WinSaverGeneratorFire( hdc, width, height );
			}

			const bool shouldContinue = pGenerator->drawFrame( hdc, width, height, keyPress );

			keyPress = 0;
			::ReleaseDC( hwnd, hdc );
			if( !shouldContinue )
			{
				Debug("WM_KEYDOWN: not handled by image generator - sending close");
				ss->CloseSaverWindow();
			}
		}
		catch( ... )
		{
			::ReleaseDC( hwnd, hdc );
			Debug("Exception caught - closing saver");
			ss->CloseSaverWindow();
		}
    } break;
    case WM_ACTIVATE: case WM_ACTIVATEAPP: case WM_NCACTIVATE:
    { if (ScrMode==smSaver && !ss->IsDialogActive && LOWORD(wParam)==WA_INACTIVE && !DEBUG)
      {Debug("WM_ACTIVATE: about to inactive window, so sending close"); ss->CloseSaverWindow();}
    } break;
	case WM_SETCURSOR:
    { if (ScrMode==smSaver && !ss->IsDialogActive && !DEBUG) SetCursor(NULL);
      else SetCursor(LoadCursor(NULL,IDC_ARROW));
    } break;
    case WM_LBUTTONDOWN: case WM_MBUTTONDOWN: case WM_RBUTTONDOWN: case WM_KEYDOWN:
    {
    	if (ScrMode==smSaver && !ss->IsDialogActive)
    	{
    		if( msg == WM_KEYDOWN )
    		{
    			keyPress = char(wParam);
    		}
    		else
    		{
	    		Debug("WM_BUTTONDOWN: sending close");
	    		ss->CloseSaverWindow();
	    	}
    	}
    } break;
	case WM_MOUSEMOVE:
	{ if (ScrMode==smSaver && !ss->IsDialogActive && !DEBUG)
	  { POINT pt; GetCursorPos(&pt);
        int dx=pt.x-ss->InitCursorPos.x; if (dx<0) dx=-dx; int dy=pt.y-ss->InitCursorPos.y; if (dy<0) dy=-dy;
        if (dx>(int)ss->MouseThreshold || dy>(int)ss->MouseThreshold)
        { Debug("WM_MOUSEMOVE: gone beyond threshold, sending close"); ss->CloseSaverWindow();
        }
      }
    } break;
	case (WM_SYSCOMMAND):
    { if (ScrMode==smSaver)
      { if (wParam==SC_SCREENSAVE) {Debug("WM_SYSCOMMAND: gobbling up a SC_SCREENSAVE to stop a new saver from running.");return FALSE;}
		if (wParam==SC_CLOSE && !DEBUG) {Debug("WM_SYSCOMMAND: gobbling up a SC_CLOSE");return FALSE;}
      }
    } break;
	case (WM_CLOSE):
	{ if (ScrMode==smSaver && ss->ReallyClose && !ss->IsDialogActive)
      { Debug("WM_CLOSE: maybe we need a password");
        BOOL CanClose=TRUE;
        if (GetTickCount()-ss->InitTime > 1000*ss->PasswordDelay)
        { ss->StartDialog(); CanClose=VerifyPassword(hwnd); ss->EndDialog();
        }
        if (CanClose) {Debug("WM_CLOSE: doing a DestroyWindow"); DestroyWindow(hwnd);}
        else {Debug("WM_CLOSE: but failed password, so doing nothing");}
      }
      if (ScrMode==smSaver) return FALSE; // so that DefWindowProc doesn't get called, because it would just DestroyWindow
    } break;
	case (WM_DESTROY):
    { if (ss->idTimer!=0) KillTimer(hwnd,ss->idTimer); ss->idTimer=0;
		delete pGenerator;  pGenerator = 0;
      Debug("POSTQUITMESSAGE from WM_DESTROY!!");
      PostQuitMessage(0);
    } break;
  }
  return DefWindowProc(hwnd,msg,wParam,lParam);
}





void DoSaver(HWND hparwnd)
{ WNDCLASS wc;
  wc.style=CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc=SaverWindowProc;
  wc.cbClsExtra=0;
  wc.cbWndExtra=0;
  wc.hInstance=hInstance;
  wc.hIcon=NULL;
  wc.hCursor=NULL;
  wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
  wc.lpszMenuName=NULL;
  wc.lpszClassName="ScrClass";
  RegisterClass(&wc);
  if (ScrMode==smPreview)
  { RECT rc; GetWindowRect(hparwnd,&rc);
    int cx=rc.right-rc.left, cy=rc.bottom-rc.top;
    hScrWindow=CreateWindowEx(0,"ScrClass","SaverPreview",WS_CHILD|WS_VISIBLE,0,0,cx,cy,hparwnd,NULL,hInstance,NULL);
  }
  else
  { int cx=GetSystemMetrics(SM_CXSCREEN), cy=GetSystemMetrics(SM_CYSCREEN);
    DWORD exstyle, style;
    if (DEBUG) { cx=cx/3; cy=cy/3; exstyle=0; style=WS_OVERLAPPEDWINDOW|WS_VISIBLE;}
    else {exstyle=WS_EX_TOPMOST; style=WS_POPUP|WS_VISIBLE;}
    hScrWindow=CreateWindowEx(exstyle,"ScrClass","SaverWindow",style,0,0,cx,cy,NULL,NULL,hInstance,NULL);
  }
  if (hScrWindow==NULL) return;
  UINT oldval;
  if (ScrMode==smSaver) SystemParametersInfo(SPI_SCREENSAVERRUNNING,1,&oldval,0);
  MSG msg;

  while (GetMessage(&msg,NULL,0,0))
  { TranslateMessage(&msg);
    DispatchMessage(&msg);
  }

  if (ScrMode==smSaver) SystemParametersInfo(SPI_SCREENSAVERRUNNING,0,&oldval,0);
  return;
}


BOOL CALLBACK ConfigDialogProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{ switch (msg)
  { case WM_INITDIALOG:
    { CheckDlgButton(hwnd,IDC_FLASH,ss->FlashScreen);
      return TRUE;
    }
    case WM_COMMAND:
    { int id=LOWORD(wParam);
      if (id==IDOK)
      { ss->FlashScreen=(IsDlgButtonChecked(hwnd,IDC_FLASH)==BST_CHECKED);
        ss->WriteConfigRegistry();
      }
      if (id==IDOK || id==IDCANCEL) EndDialog(hwnd,id);
    } break;
  }
  return FALSE;
}


// This routine is for using ScrPrev. It's so that you can start the saver
// with the command line /p scrprev and it runs itself in a preview window.
// You must first copy ScrPrev somewhere in your search path
HWND CheckForScrprev()
{ HWND hwnd=FindWindow("Scrprev",NULL); // looks for the Scrprev class
  if (hwnd==NULL) // try to load it
  { STARTUPINFO si; PROCESS_INFORMATION pi; ZeroMemory(&si,sizeof(si)); ZeroMemory(&pi,sizeof(pi));
    si.cb=sizeof(si);
    si.lpReserved=NULL; si.lpTitle=NULL; si.dwFlags=0; si.cbReserved2=0; si.lpReserved2=0; si.lpDesktop=0;
    BOOL cres=CreateProcess(NULL,"Scrprev",0,0,FALSE,CREATE_NEW_PROCESS_GROUP | CREATE_DEFAULT_ERROR_MODE,
                            0,0,&si,&pi);
    if (!cres) {Debug("Error creating scrprev process"); return NULL;}
    DWORD wres=WaitForInputIdle(pi.hProcess,2000);
    if (wres==WAIT_TIMEOUT) {Debug("Scrprev never becomes idle"); return NULL;}
    if (wres==0xFFFFFFFF) {Debug("ScrPrev, misc error after ScrPrev execution");return NULL;}
    hwnd=FindWindow("Scrprev",NULL);
  }
  if (hwnd==NULL) {Debug("Unable to find Scrprev window"); return NULL;}
  ::SetForegroundWindow(hwnd);
  hwnd=GetWindow(hwnd,GW_CHILD);
  if (hwnd==NULL) {Debug("Couldn't find Scrprev child"); return NULL;}
  return hwnd;
}


int WINAPI WinMain(HINSTANCE h,HINSTANCE,LPSTR,int)
{ hInstance=h;
  char *c=GetCommandLine();
  if (*c=='\"') {c++; while (*c!=0 && *c!='\"') c++;} else {while (*c!=0 && *c!=' ') c++;}
  if (*c!=0) c++;
  while (*c==' ') c++;
  HWND hwnd=NULL;
  if (*c==0) {ScrMode=smConfig; hwnd=NULL;}
  else
  { if (*c=='-' || *c=='/') c++;
    if (*c=='p' || *c=='P' || *c=='l' || *c=='L')
    { c++; while (*c==' ' || *c==':') c++;
      if ((strcmp(c,"scrprev")==0) || (strcmp(c,"ScrPrev")==0) || (strcmp(c,"SCRPREV")==0)) hwnd=CheckForScrprev();
      else hwnd=(HWND)atoi(c);
      ScrMode=smPreview;
    }
    else if (*c=='s' || *c=='S') {ScrMode=smSaver; }
    else if (*c=='c' || *c=='C') {c++; while (*c==' ' || *c==':') c++; if (*c==0) hwnd=GetForegroundWindow(); else hwnd=(HWND)atoi(c); ScrMode=smConfig;}
    else if (*c=='a' || *c=='A') {c++; while (*c==' ' || *c==':') c++; hwnd=(HWND)atoi(c); ScrMode=smPassword;}
  }
  // We create a global TSaverSettings here, for convenience. It will get used by the config dialog and
  // by the saver as it runs
  ss=new TSaverSettings(); ss->ReadGeneralRegistry(); ss->ReadConfigRegistry();
  if (ScrMode==smPassword) ChangePassword(hwnd);
  if (ScrMode==smConfig) DialogBox(hInstance,MAKEINTRESOURCE(DLG_CONFIG),hwnd,ConfigDialogProc);
  if (ScrMode==smSaver || ScrMode==smPreview) DoSaver(hwnd);
  delete ss;
  return 0;
}


// MessageName: this function returns the text name of the message.
/*char *MessageName(UINT msg)
{ switch (msg)
  { case WM_NULL: return "WM_NULL";
    case WM_CREATE: return "WM_CREATE";
    case WM_DESTROY: return "WM_DESTROY";
    case WM_MOVE: return "WM_MOVE";
    case WM_SIZE: return "WM_SIZE";
    case WM_ACTIVATE: return "WM_ACTIVATE";
    case WM_SETFOCUS: return "WM_SETFOCUS";
    case WM_KILLFOCUS: return "WM_KILLFOCUS";
    case WM_ENABLE: return "WM_ENABLE";
    case WM_SETREDRAW: return "WM_SETREDRAW";
    case WM_SETTEXT: return "WM_SETTEXT";
    case WM_GETTEXT: return "WM_GETTEXT";
    case WM_GETTEXTLENGTH: return "WM_GETTEXTLENGTH";
    case WM_PAINT: return "WM_PAINT";
    case WM_CLOSE: return "WM_CLOSE";
    case WM_QUERYENDSESSION: return "WM_QUERYENDSESSION";
    case WM_QUIT: return "WM_QUIT";
    case WM_QUERYOPEN: return "WM_QUERYOPEN";
    case WM_ERASEBKGND: return "WM_ERASEBKGND";
    case WM_SYSCOLORCHANGE: return "WM_SYSCOLORCHANGE";
    case WM_ENDSESSION: return "WM_ENDSESSION";
    case WM_SHOWWINDOW: return "WM_SHOWWINDOW";
    case WM_SETTINGCHANGE: return "WM_SETTINGCHANGE";
    case WM_DEVMODECHANGE: return "WM_DEVMODECHANGE";
    case WM_ACTIVATEAPP: return "WM_ACTIVATEAPP";
    case WM_FONTCHANGE: return "WM_FONTCHANGE";
    case WM_TIMECHANGE: return "WM_TIMECHANGE";
    case WM_CANCELMODE: return "WM_CANCELMODE";
    case WM_SETCURSOR: return "WM_SETCURSOR";
    case WM_MOUSEACTIVATE: return "WM_MOUSEACTIVATE";
    case WM_CHILDACTIVATE: return "WM_CHILDACTIVATE";
    case WM_QUEUESYNC: return "WM_QUEUESYNC";
    case WM_GETMINMAXINFO: return "WM_GETMINMAXINFO";
    case WM_PAINTICON: return "WM_PAINTICON";
    case WM_ICONERASEBKGND: return "WM_ICONERASEBKGND";
    case WM_NEXTDLGCTL: return "WM_NEXTDLGCTL";
    case WM_SPOOLERSTATUS: return "WM_SPOOLERSTATUS";
    case WM_DRAWITEM: return "WM_DRAWITEM";
    case WM_MEASUREITEM: return "WM_MEASUREITEM";
    case WM_DELETEITEM: return "WM_DELETEITEM";
    case WM_VKEYTOITEM: return "WM_VKEYTOITEM";
    case WM_CHARTOITEM: return "WM_CHARTOITEM";
    case WM_SETFONT: return "WM_SETFONT";
    case WM_GETFONT: return "WM_GETFONT";
    case WM_SETHOTKEY: return "WM_SETHOTKEY";
    case WM_GETHOTKEY: return "WM_GETHOTKEY";
    case WM_QUERYDRAGICON: return "WM_QUERYDRAGICON";
    case WM_COMPAREITEM: return "WM_COMPAREITEM";
    case WM_COMPACTING: return "WM_COMPACTING";
    case WM_COMMNOTIFY: return "WM_COMMNOTIFY";
    case WM_WINDOWPOSCHANGING: return "WM_WINDOWPOSCHANGING";
    case WM_WINDOWPOSCHANGED: return "WM_WINDOWPOSCHANGED";
    case WM_POWER: return "WM_POWER";
    case WM_COPYDATA: return "WM_COPYDATA";
    case WM_CANCELJOURNAL: return "WM_CANCELJOURNAL";
    case WM_NOTIFY: return "WM_NOTIFY";
    case WM_INPUTLANGCHANGEREQUEST: return "WM_INPUTLANGCHANGEREQUEST";
    case WM_INPUTLANGCHANGE: return "WM_INPUTLANGCHANGE";
    case WM_TCARD: return "WM_TCARD";
    case WM_HELP: return "WM_HELP";
    case WM_USERCHANGED: return "WM_USERCHANGED";
    case WM_NOTIFYFORMAT: return "WM_NOTIFYFORMAT";
    case WM_CONTEXTMENU: return "WM_CONTEXTMENU";
    case WM_STYLECHANGING: return "WM_STYLECHANGING";
    case WM_STYLECHANGED: return "WM_STYLECHANGED";
    case WM_DISPLAYCHANGE: return "WM_DISPLAYCHANGE";
    case WM_GETICON: return "WM_GETICON";
    case WM_SETICON: return "WM_SETICON";
    case WM_NCCREATE: return "WM_NCCREATE";
    case WM_NCDESTROY: return "WM_NCDESTROY";
    case WM_NCCALCSIZE: return "WM_NCCALCSIZE";
    case WM_NCHITTEST: return "WM_NCHITTEST";
    case WM_NCPAINT: return "WM_NCPAINT";
    case WM_NCACTIVATE: return "WM_NCACTIVATE";
    case WM_GETDLGCODE: return "WM_GETDLGCODE";
    case WM_NCMOUSEMOVE: return "WM_NCMOUSEMOVE";
    case WM_NCLBUTTONDOWN: return "WM_NCLBUTTONDOWN";
    case WM_NCLBUTTONUP: return "WM_NCLBUTTONUP";
    case WM_NCLBUTTONDBLCLK: return "WM_NCLBUTTONDBLCLK";
    case WM_NCRBUTTONDOWN: return "WM_NCRBUTTONDOWN";
    case WM_NCRBUTTONUP: return "WM_NCRBUTTONUP";
    case WM_NCRBUTTONDBLCLK: return "WM_NCRBUTTONDBLCLK";
    case WM_NCMBUTTONDOWN: return "WM_NCMBUTTONDOWN";
    case WM_NCMBUTTONUP: return "WM_NCMBUTTONUP";
    case WM_NCMBUTTONDBLCLK: return "WM_NCMBUTTONDBLCLK";
    case WM_KEYDOWN: return "WM_KEYDOWN";
    case WM_KEYUP: return "WM_KEYUP";
    case WM_CHAR: return "WM_CHAR";
    case WM_DEADCHAR: return "WM_DEADCHAR";
    case WM_SYSKEYDOWN: return "WM_SYSKEYDOWN";
    case WM_SYSKEYUP: return "WM_SYSKEYUP";
    case WM_SYSCHAR: return "WM_SYSCHAR";
    case WM_SYSDEADCHAR: return "WM_SYSDEADCHAR";
    case WM_IME_STARTCOMPOSITION: return "WM_IME_STARTCOMPOSITION";
    case WM_IME_ENDCOMPOSITION: return "WM_IME_ENDCOMPOSITION";
    case WM_IME_COMPOSITION: return "WM_IME_COMPOSITION";
    case WM_INITDIALOG: return "WM_INITDIALOG";
    case WM_COMMAND: return "WM_COMMAND";
    case WM_SYSCOMMAND: return "WM_SYSCOMMAND";
    case WM_TIMER: return "WM_TIMER";
    case WM_HSCROLL: return "WM_HSCROLL";
    case WM_VSCROLL: return "WM_VSCROLL";
    case WM_INITMENU: return "WM_INITMENU";
    case WM_INITMENUPOPUP: return "WM_INITMENUPOPUP";
    case WM_MENUSELECT: return "WM_MENUSELECT";
    case WM_MENUCHAR: return "WM_MENUCHAR";
    case WM_ENTERIDLE: return "WM_ENTERIDLE";
    case WM_CTLCOLORMSGBOX: return "WM_CTLCOLORMSGBOX";
    case WM_CTLCOLOREDIT: return "WM_CTLCOLOREDIT";
    case WM_CTLCOLORLISTBOX: return "WM_CTLCOLORLISTBOX";
    case WM_CTLCOLORBTN: return "WM_CTLCOLORBTN";
    case WM_CTLCOLORDLG: return "WM_CTLCOLORDLG";
    case WM_CTLCOLORSCROLLBAR: return "WM_CTLCOLORSCROLLBAR";
    case WM_CTLCOLORSTATIC: return "WM_CTLCOLORSTATIC";
    case WM_MOUSEMOVE: return "WM_MOUSEMOVE";
    case WM_LBUTTONDOWN: return "WM_LBUTTONDOWN";
    case WM_LBUTTONUP: return "WM_LBUTTONUP";
    case WM_LBUTTONDBLCLK: return "WM_LBUTTONDBLCLK";
    case WM_RBUTTONDOWN: return "WM_RBUTTONDOWN";
    case WM_RBUTTONUP: return "WM_RBUTTONUP";
    case WM_RBUTTONDBLCLK: return "WM_RBUTTONDBLCLK";
    case WM_MBUTTONDOWN: return "WM_MBUTTONDOWN";
    case WM_MBUTTONUP: return "WM_MBUTTONUP";
    case WM_MBUTTONDBLCLK: return "WM_MBUTTONDBLCLK";
    //case WM_MOUSEWHEEL: return "WM_MOUSEWHEEL";
    case WM_PARENTNOTIFY: return "WM_PARENTNOTIFY";
    case WM_ENTERMENULOOP: return "WM_ENTERMENULOOP";
    case WM_EXITMENULOOP: return "WM_EXITMENULOOP";
    case WM_NEXTMENU: return "WM_NEXTMENU";
    case WM_SIZING: return "WM_SIZING";
    case WM_CAPTURECHANGED: return "WM_CAPTURECHANGED";
    case WM_MOVING: return "WM_MOVING";
    case WM_POWERBROADCAST: return "WM_POWERBROADCAST";
    case WM_DEVICECHANGE: return "WM_DEVICECHANGE";
    case WM_IME_SETCONTEXT: return "WM_IME_SETCONTEXT";
    case WM_IME_NOTIFY: return "WM_IME_NOTIFY";
    case WM_IME_CONTROL: return "WM_IME_CONTROL";
    case WM_IME_COMPOSITIONFULL: return "WM_IME_COMPOSITIONFULL";
    case WM_IME_SELECT: return "WM_IME_SELECT";
    case WM_IME_CHAR: return "WM_IME_CHAR";
    case WM_IME_KEYDOWN: return "WM_IME_KEYDOWN";
    case WM_IME_KEYUP: return "WM_IME_KEYUP";
    case WM_MDICREATE: return "WM_MDICREATE";
    case WM_MDIDESTROY: return "WM_MDIDESTROY";
    case WM_MDIACTIVATE: return "WM_MDIACTIVATE";
    case WM_MDIRESTORE: return "WM_MDIRESTORE";
    case WM_MDINEXT: return "WM_MDINEXT";
    case WM_MDIMAXIMIZE: return "WM_MDIMAXIMIZE";
    case WM_MDITILE: return "WM_MDITILE";
    case WM_MDICASCADE: return "WM_MDICASCADE";
    case WM_MDIICONARRANGE: return "WM_MDIICONARRANGE";
    case WM_MDIGETACTIVE: return "WM_MDIGETACTIVE";
    case WM_MDISETMENU: return "WM_MDISETMENU";
    case WM_ENTERSIZEMOVE: return "WM_ENTERSIZEMOVE";
    case WM_EXITSIZEMOVE: return "WM_EXITSIZEMOVE";
    case WM_DROPFILES: return "WM_DROPFILES";
    case WM_MDIREFRESHMENU: return "WM_MDIREFRESHMENU";
    //case WM_MOUSEHOVER: return "WM_MOUSEHOVER";
    //case WM_MOUSELEAVE: return "WM_MOUSELEAVE";
    case WM_CUT: return "WM_CUT";
    case WM_COPY: return "WM_COPY";
    case WM_PASTE: return "WM_PASTE";
    case WM_CLEAR: return "WM_CLEAR";
    case WM_UNDO: return "WM_UNDO";
    case WM_RENDERFORMAT: return "WM_RENDERFORMAT";
    case WM_RENDERALLFORMATS: return "WM_RENDERALLFORMATS";
    case WM_DESTROYCLIPBOARD: return "WM_DESTROYCLIPBOARD";
    case WM_DRAWCLIPBOARD: return "WM_DRAWCLIPBOARD";
    case WM_PAINTCLIPBOARD: return "WM_PAINTCLIPBOARD";
    case WM_VSCROLLCLIPBOARD: return "WM_VSCROLLCLIPBOARD";
    case WM_SIZECLIPBOARD: return "WM_SIZECLIPBOARD";
    case WM_ASKCBFORMATNAME: return "WM_ASKCBFORMATNAME";
    case WM_CHANGECBCHAIN: return "WM_CHANGECBCHAIN";
    case WM_HSCROLLCLIPBOARD: return "WM_HSCROLLCLIPBOARD";
    case WM_QUERYNEWPALETTE: return "WM_QUERYNEWPALETTE";
    case WM_PALETTEISCHANGING: return "WM_PALETTEISCHANGING";
    case WM_PALETTECHANGED: return "WM_PALETTECHANGED";
    case WM_HOTKEY: return "WM_HOTKEY";
    case WM_PRINT: return "WM_PRINT";
    case WM_PRINTCLIENT: return "WM_PRINTCLIENT";
    case WM_HANDHELDFIRST: return "WM_HANDHELDFIRST";
    case WM_HANDHELDLAST: return "WM_HANDHELDLAST";
    case WM_AFXFIRST: return "WM_AFXFIRST";
    case WM_AFXLAST: return "WM_AFXLAST";
    case WM_PENWINFIRST: return "WM_PENWINFIRST";
    case WM_PENWINLAST: return "WM_PENWINLAST";
#ifdef __VCL
    case CM_ACTIVATE: return "CM_ACTIVATE";
    case CM_DEACTIVATE: return "CM_DEACTIVATE";
    case CM_GOTFOCUS: return "CM_GOTFOCUS";
    case CM_LOSTFOCUS: return "CM_LOSTFOCUS";
    case CM_CANCELMODE: return "CM_CANCELMODE";
    case CM_DIALOGKEY: return "CM_DIALOGKEY";
    case CM_DIALOGCHAR: return "CM_DIALOGCHAR";
    case CM_FOCUSCHANGED: return "CM_FOCUSCHANGED";
    case CM_PARENTFONTCHANGED: return "CM_PARENTFONTCHANGED";
    case CM_PARENTCOLORCHANGED: return "CM_PARENTCOLORCHANGED";
    case CM_HITTEST: return "CM_HITTEST";
    case CM_VISIBLECHANGED: return "CM_VISIBLECHANGED";
    case CM_ENABLEDCHANGED: return "CM_ENABLEDCHANGED";
    case CM_COLORCHANGED: return "CM_COLORCHANGED";
    case CM_FONTCHANGED: return "CM_FONTCHANGED";
    case CM_CURSORCHANGED: return "CM_CURSORCHANGED";
    case CM_CTL3DCHANGED: return "CM_CTL3DCHANGED";
    case CM_PARENTCTL3DCHANGED: return "CM_PARENTCTL3DCHANGED";
    case CM_TEXTCHANGED: return "CM_TEXTCHANGED";
    case CM_MOUSEENTER: return "CM_MOUSEENTER";
    case CM_MOUSELEAVE: return "CM_MOUSELEAVE";
    case CM_MENUCHANGED: return "CM_MENUCHANGED";
    case CM_APPKEYDOWN: return "CM_APPKEYDOWN";
    case CM_APPSYSCOMMAND: return "CM_APPSYSCOMMAND";
    case CM_BUTTONPRESSED: return "CM_BUTTONPRESSED";
    case CM_SHOWINGCHANGED: return "CM_SHOWINGCHANGED";
    case CM_ENTER: return "CM_ENTER";
    case CM_EXIT: return "CM_EXIT";
    case CM_DESIGNHITTEST: return "CM_DESIGNHITTEST";
    case CM_ICONCHANGED: return "CM_ICONCHANGED";
    case CM_WANTSPECIALKEY: return "CM_WANTSPECIALKEY";
    case CM_INVOKEHELP: return "CM_INVOKEHELP";
    case CM_WINDOWHOOK: return "CM_WINDOWHOOK";
    case CM_RELEASE: return "CM_RELEASE";
    case CM_SHOWHINTCHANGED: return "CM_SHOWHINTCHANGED";
    case CM_PARENTSHOWHINTCHANGED: return "CM_PARENTSHOWHINTCHANGED";
    case CM_SYSCOLORCHANGE: return "CM_SYSCOLORCHANGE";
    case CM_WININICHANGE: return "CM_WININICHANGE";
    case CM_FONTCHANGE: return "CM_FONTCHANGE";
    case CM_TIMECHANGE: return "CM_TIMECHANGE";
    case CM_TABSTOPCHANGED: return "CM_TABSTOPCHANGED";
    case CM_UIACTIVATE: return "CM_UIACTIVATE";
    case CM_UIDEACTIVATE: return "CM_UIDEACTIVATE";
    case CM_DOCWINDOWACTIVATE: return "CM_DOCWINDOWACTIVATE";
    case CM_CONTROLLISTCHANGE: return "CM_CONTROLLISTCHANGE";
    case CM_GETDATALINK: return "CM_GETDATALINK";
    case CM_CHILDKEY: return "CM_CHILDKEY";
    case CM_DRAG: return "CM_DRAG";
    case CM_HINTSHOW: return "CM_HINTSHOW";
    case CM_DIALOGHANDLE: return "CM_DIALOGHANDLE";
    case CM_ISTOOLCONTROL: return "CM_ISTOOLCONTROL";
    case CM_RECREATEWND: return "CM_RECREATEWND";
    case CM_INVALIDATE: return "CM_INVALIDATE";
    case CM_SYSFONTCHANGED: return "CM_SYSFONTCHANGED";
    case CM_CONTROLCHANGE: return "CM_CONTROLCHANGE";
    case CM_CHANGED: return "CM_CHANGED";
    case CN_CHARTOITEM: return "CN_CHARTOITEM";
    case CN_COMMAND: return "CN_COMMAND";
    case CN_COMPAREITEM: return "CN_COMPAREITEM";
    case CN_CTLCOLORBTN: return "CN_CTLCOLORBTN";
    case CN_CTLCOLORDLG: return "CN_CTLCOLORDLG";
    case CN_CTLCOLOREDIT: return "CN_CTLCOLOREDIT";
    case CN_CTLCOLORLISTBOX: return "CN_CTLCOLORLISTBOX";
    case CN_CTLCOLORMSGBOX: return "CN_CTLCOLORMSGBOX";
    case CN_CTLCOLORSCROLLBAR: return "CN_CTLCOLORSCROLLBAR";
    case CN_CTLCOLORSTATIC: return "CN_CTLCOLORSTATIC";
    case CN_DELETEITEM: return "CN_DELETEITEM";
    case CN_DRAWITEM: return "CN_DRAWITEM";
    case CN_HSCROLL: return "CN_HSCROLL";
    case CN_MEASUREITEM: return "CN_MEASUREITEM";
    case CN_PARENTNOTIFY: return "CN_PARENTNOTIFY";
    case CN_VKEYTOITEM: return "CN_VKEYTOITEM";
    case CN_VSCROLL: return "CN_VSCROLL";
    case CN_KEYDOWN: return "CN_KEYDOWN";
    case CN_KEYUP: return "CN_KEYUP";
    case CN_CHAR: return "CN_CHAR";
    case CN_SYSKEYDOWN: return "CN_SYSKEYDOWN";
    case CN_SYSCHAR: return "CN_SYSCHAR";
    case CN_NOTIFY: return "CN_NOTIFY";
#endif
    default: return "WM_????";
  }
}*/


