///  artifex@computer.org  |  2001-07-22  ///

/// some definitely sized integer primitive types


#ifndef primitives_h
#define primitives_h




/// types

typedef  unsigned char    byte;
typedef  signed   char    sbyte;

typedef  unsigned short   word;
typedef  signed   short   sword;

typedef  unsigned int     dword;
typedef  signed   int     sdword;

typedef  unsigned int     uint32;
typedef  signed   int     int32;


/// constants

#define  BYTE_MAX     ( byte(255) )
#define  BYTE_MIN     ( byte(0)   )
#define  BYTE_BITS    ( 8 )

#define  SBYTE_MAX    ( sbyte(127)  )
#define  SBYTE_MIN    ( sbyte(-128) )
#define  SBYTE_BITS   ( 8 )

#define  WORD_MAX     ( word(65535) )
#define  WORD_MIN     ( word(0)     )
#define  WORD_BITS    ( 16 )

#define  SWORD_MAX    ( sword(32767)  )
#define  SWORD_MIN    ( sword(-32768) )
#define  SWORD_BITS   ( 16 )

#define  DWORD_MAX    ( dword(4294967295) )
#define  DWORD_MIN    ( dword(0)          )
#define  DWORD_BITS   ( 32 )

#define  SDWORD_MAX   ( sdword(2147483647)  )
#define  SDWORD_MIN   ( sdword(-2147483648) )
#define  SDWORD_BITS  ( 32 )

#define  UINT32_MAX   ( uint32(4294967295) )
#define  UINT32_MIN   ( uint32(0)          )
#define  UINT32_BITS  ( 32 )

#define  INT32_MAX    ( int32(2147483647)  )
#define  INT32_MIN    ( int32(-2147483648) )
#define  INT32_BITS   ( 32 )




#endif//primitives_h
