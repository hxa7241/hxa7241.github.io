///  artifex@computer.org  |  2001-07-22  ///


#include "Blurs.h"

#include <math>
#include <memory>
#include "FpToInt.h"




/**
 * Speedily blurs a rectangular int array (in place) with a small hat filter.
 *
 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
 * one.
 * the top left and bottom right (first and last) pixels dont always get filled
 * in correctly.
 * <code>
 *    kernel shape:               121
 *                   121          242
 *                                121
 *                (separate)   (resultant)
 * </code>
 *
 * @param iterations  how many times to iterate the blurring
 * @param width       width of the 2D pixel array
 * @param height      height of the 2D pixel array
 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
 * @param pixels      input, and output, 2D array
 */
void Blurs::gatherSquare3
(
	const sdword iterations,
	const sdword width,
	const sdword height,
	sdword pixelsSpare[],
	sdword pixels[]
)
{
	const sdword length = width * height;
	const sdword end    = length - 1;

	for( sdword a = iterations; a-- > 0; )
	{
		/// horizontally (into the spare array)
		sdword k2 = pixels[   0 ];
		sdword k1 = pixels[ end ];
		sdword s1 = k1 + k2 + 1;
		sdword s2 = 0;
		for( sdword i = end;  i-- > 0; )
		{
			k2 = k1;
			k1 = pixels[ i ];
			s2 = s1;
			s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
			pixelsSpare[ i + 1 ] = (s1 + s2) >> 2;
		}
		pixelsSpare[ 0 ] = ((pixels[ end ] + k1) + s1 + 1) >> 2;


		/// vertically (back into the in/out array)
		k2 = pixelsSpare[   0 ];
		k1 = pixelsSpare[ end ];
		s1 = k1 + k2 + 1;
		s2;
		for( sdword i = end, j = i;  i > 0; )
		{
			i += ((i - width) >> 31) & end;//i = i >= width ? i : i + end;
			i -= width;

			k2 = k1;
			k1 = pixelsSpare[ i ];
			s2 = s1;
			s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
			pixels[ j ] = (s1 + s2) >> 2;

			j = i;
		}
		pixels[ 0 ] = ((pixelsSpare[ end ] + k1) + s1 + 1) >> 2;
	}
}


/**
 * Speedily blurs a rectangular int array (in place) with a small boxy-hatty filter.
 *
 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
 * one.
 * the top left and bottom right 1 by 2 area of pixels dont always get filled
 * in correctly.
 * <code>
 *    kernel shape:                12221
 *                                 24442
 *                   12221         24442       - some mixture of box and hat
 *                                 24442
 *                                 12221
 *                 (separate)   (resultant)
 * </code>
 *
 * @param iterations  how many times to iterate the blurring
 * @param width       width of the pixel 2D array
 * @param height      height of the pixel 2D array
 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
 * @param pixels      input, and output, 2D array
 */
void Blurs::gatherSquare5
(
	const sdword iterations,
	const sdword width,
	const sdword height,
	sdword pixelsSpare[],
	sdword pixels[]
)
{
	const sdword length = width * height;
	const sdword end    = length - 1;

	for( sdword a = iterations; a-- > 0; )
	{
		/// horizontally (into the spare array)
		sdword k2 = pixels[ end ];
		sdword k1 = pixels[ end - 1 ];
		sdword s1 = k1 + k2 + 1;
		sdword s2 = pixels[ end ] + pixels[ 0 ] + 1;
		sdword s3 = pixels[ 0 ] + pixels[ 1 ] + 1;
		sdword s4;
		sdword empty = 0xFFFFFFFF;
		for( sdword i = end - 1;  i-- > 0; )
		{
			/*k2 = k1;
			k1 = pixels[ i ];
			s4 = s3;
			s3 = s2;
			s2 = s1;
			s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
			pixelsSpare[ i + 2 ] = (s1 + s2 + s3 + s4) >> 3;*/

			/// switching off version
			sdword nk = pixels[ i ];
			sdword ns = nk + k1;
			if( (empty != 0) || (ns != 0) )
			{
				//k2 = k1;
				k1 = nk;
				s4 = s3;
				s3 = s2;
				s2 = s1;
				s1 = ns + 1;   /// add 1 to make negatives round correctly
				empty = s1 | s2 | s3 | s4;
				pixelsSpare[ i + 2 ] = (s1 + s2 + s3 + s4) >> 3;
			}
		}
		k2 = k1;
		k1 = pixels[ end ];
		s4 = s3;
		s3 = s2;
		s2 = s1;
		s1 = k1 + k2 + 1;
		pixelsSpare[ 1 ] = (s1 + s2 + s3 + s4) >> 3;
		pixelsSpare[ 0 ] = ((pixels[ end-1 ] + k1 + 1) + s1 + s2 + s3) >> 3;


		/// vertically (back into the in/out array)
		k2 = pixelsSpare[ end ];
		k1 = pixelsSpare[ end - width ];
		s1 = k1 + k2 + 1;
		s2 = pixelsSpare[ end ] + pixelsSpare[ 0 ] + 1;
		s3 = pixelsSpare[ 0 ] + pixelsSpare[ width ] + 1;
		s4;
		empty = 0xFFFFFFFF;
		for( sdword i2 = end, i1 = i2 - width, i = i1;  i > 0; )
		{
			/*i += ((i - width) >> 31) & end;//i = i >= width ? i : i + end;
			i -= width;

			k2 = k1;
			k1 = pixelsSpare[ i ];
			s4 = s3;
			s3 = s2;
			s2 = s1;
			s1 = k1 + k2 + 1;   /// add 1 to make negatives round correctly
			pixels[ i2 ] = (s1 + s2 + s3 + s4) >> 3;

			i2 = i1;
			i1 = i;*/

			/// switching off version
			i += ((i - width) >> 31) & end;//i = i >= width ? i : i + end;
			i -= width;

			sdword nk = pixelsSpare[ i ];
			sdword ns = nk + k1;
			if( (empty != 0) || (ns != 0) )
			{
				//k2 = k1;
				k1 = nk;
				s4 = s3;
				s3 = s2;
				s2 = s1;
				s1 = ns + 1;   /// add 1 to make negatives round correctly
				empty = s1 | s2 | s3 | s4;
				pixels[ i2 ] = (s1 + s2 + s3 + s4) >> 3;
			}

			i2 = i1;
			i1 = i;
		}
		k2 = k1;
		k1 = pixelsSpare[ end ];
		s4 = s3;
		s3 = s2;
		s2 = s1;
		s1 = k1 + k2 + 1;
		pixels[ 1 ] = (s1 + s2 + s3 + s4) >> 3;
		pixels[ 0 ] = ((pixelsSpare[ end-width ] + k1 + 1) + s1 + s2 + s3) >> 3;
	}
}


/**
 * Speedily blurs a rectangular byte array (in place) with a small hat filter.
 *
 * faster than the sdword[] version due to a simd implementation, but:
 * doesnt handle negative values, and loses some precision. and the top-bottom
 * wraparound is shifted along by 4.<br/><br/>
 *
 * width and height of array must both be multiples of 4.<br/><br/>
 *
 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
 * one.
 * the top left and bottom right 1 by 2 area of pixels dont always get filled
 * in correctly.
 * <code>
 *    kernel shape:               121
 *                   121          242
 *                                121
 *                (separate)   (resultant)
 * </code>
 *
 * (precision note: for values between 16 and 255 the average error is -6%)
 *
 * @param iterations  how many times to iterate the blurring
 * @param width       width of the 2D pixel array - must be a multiple of 4
 * @param height      height of the 2D pixel array - must be a multiple of 4
 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
 * @param pixels      input, and output, 2D array
 */
void Blurs::gatherSquare3
(
	const sdword iterations,
	const sdword width,
	const sdword height,
	sbyte pixelsSpare[],
	sbyte pixels[]
)
{
	/// 4 pixels will be calculated at once, so cast to dword arrays
	/// (for java, use ints and change the >>s to >>>s)
	dword* quadPixels = reinterpret_cast<dword*>( pixels );
	dword* quadSpares = reinterpret_cast<dword*>( pixelsSpare );
	const sdword length = (width * height) >> 2;
	const sdword end    = length - 1;
	const sdword qWidth = width >> 2;

	for( sdword a = iterations; a-- > 0; )
	{
		/// horizontally (into the spare array)
		dword previous = quadPixels[   0 ];
		dword current  = quadPixels[ end ];
		for( sdword i = end;  i-- > 0; )
		{
			const dword next = quadPixels[ i ];

			dword gather = ( (previous << 22) | (current >> 10) ) & 0x3F3F3F3Fu;
			gather      += ( (current  <<  6) | (next    >> 26) ) & 0x3F3F3F3Fu;
			gather      += ( current >> 1 ) & 0x7F7F7F7Fu;

			quadSpares[ i + 1 ] = gather;

			previous = current;
			current  = next;
		}
		const dword next = quadPixels[ end ];
		dword gather = ( (previous << 22) | (current >> 10) ) & 0x3F3F3F3Fu;
		gather      += ( (current  <<  6) | (next    >> 26) ) & 0x3F3F3F3Fu;
		gather      += ( current >> 1 ) & 0x7F7F7F7Fu;
		quadSpares[ 0 ] = gather;


		/// vertically (back into the in/out array)
		dword k2 = (quadSpares[   0 ] >> 2) & 0x3F3F3F3Fu;
		dword k1 = (quadSpares[ end ] >> 2) & 0x3F3F3F3Fu;
		dword s1 = k1 + k2;
		dword s2;
		dword* pQuadSpares = quadSpares + end;
		for( sdword i = end, j = i;  i > 0; )
		{
			//i += ((i - qWidth) >> 31) & end;//i = i >= qWidth ? i : i + end;
			const sdword back = ((i - qWidth) >> 31) & end;
			const sdword next = back - qWidth;
			pQuadSpares += next;
			i += next;

			k2 = k1;
			//k1 = (quadSpares[ i ] >> 2) & 0x3F3F3F3Fu;
			k1 = (*pQuadSpares >> 2) & 0x3F3F3F3Fu;
			s2 = s1;
			s1 = k1 + k2;
			quadPixels[ j ] = s1 + s2;

			j = i;
		}
		k2 = k1;
		k1 = (quadSpares[ end ] >> 2) & 0x3F3F3F3Fu;
		s2 = s1;
		s1 = k1 + k2;
		quadPixels[ 0 ] = s1 + s2;
	}
}


/**
 * Speedily blurs a rectangular byte array (in place) with a small boxy-hatty filter.
 *
 * faster than the sdword[] version due to a simd implementation, but:
 * doesnt handle negative values, and loses some precision. and the top-bottom
 * wraparound is shifted along by 4. and the top row doesnt work.<br/><br/>
 *
 * width and height of array must both be multiples of 4.<br/><br/>
 *
 * wraparound is 'helical' - each row/column wraps to the end of the <i>next</i>
 * one.
 * the top left and bottom right 1 by 2 area of pixels dont always get filled
 * in correctly.
 * <code>
 *    kernel shape:                12221
 *                                 24442
 *                   12221         24442       - some mixture of box and hat
 *                                 24442
 *                                 12221
 *                 (separate)   (resultant)
 * </code>
 *
 * (precision note: for values between 16 and 255 the average error probably at
 * at least -6%)
 *
 * @param iterations  how many times to iterate the blurring
 * @param width       width of the 2D pixel array - must be a multiple of 4
 * @param height      height of the 2D pixel array - must be a multiple of 4
 * @param pixelsSpare scratchpad working array (same dimensions as pixels)
 * @param pixels      input, and output, 2D array
 */
void Blurs::gatherSquare5
(
	const sdword iterations,
	const sdword width,
	const sdword height,
	sbyte pixelsSpare[],
	sbyte pixels[]
)
{
	/// 4 pixels will be calculated at once, so cast to dword arrays
	/// (for java, use ints and change the >>s to >>>s)
	dword* quadPixels = reinterpret_cast<dword*>( pixels );
	dword* quadSpares = reinterpret_cast<dword*>( pixelsSpare );
	const sdword length = (width * height) >> 2;
	const sdword end    = length - 1;
	const sdword qWidth = width >> 2;

	for( sdword a = iterations; a-- > 0; )
	{
		/// horizontally (into the spare array)
		dword previous = quadPixels[   0 ];
		dword current  = quadPixels[ end ];
		for( sdword i = end;  i-- > 0; )
		{
			const dword next = quadPixels[ i ];

			dword gather = ( current >> 2 ) & 0x3F3F3F3Fu;
			gather      += ( (previous << 22) | (current >> 10) ) & 0x3F3F3F3Fu;
			gather      += ( (previous << 13) | (current >> 19) ) & 0x1F1F1F1Fu;
			gather      += ( (current  <<  6) | (next    >> 26) ) & 0x3F3F3F3Fu;
			gather      += ( (current  << 13) | (next    >> 19) ) & 0x1F1F1F1Fu;

			quadSpares[ i + 1 ] = gather;

			previous = current;
			current  = next;
		}
		const dword next = quadPixels[ end ];
		dword gather = ( current >> 2 ) & 0x3F3F3F3Fu;
		gather      += ( (previous << 22) | (current >> 10) ) & 0x3F3F3F3Fu;
		gather      += ( (previous << 13) | (current >> 19) ) & 0x1F1F1F1Fu;
		gather      += ( (current  <<  6) | (next    >> 26) ) & 0x3F3F3F3Fu;
		gather      += ( (current  << 13) | (next    >> 19) ) & 0x1F1F1F1Fu;
		quadSpares[ 0 ] = gather;


		/// vertically (back into the in/out array)
		dword k2 = (quadSpares[ end          ] >> 3) & 0x1F1F1F1Fu;
		dword k1 = (quadSpares[ end - qWidth ] >> 3) & 0x1F1F1F1Fu;
		dword s1 = k1 + k2;
		dword s2 = ((quadSpares[ end ] >> 3) & 0x1F1F1F1Fu) + ((quadSpares[ 0      ] >> 3) & 0x1F1F1F1Fu);
		dword s3 = ((quadSpares[ 0   ] >> 3) & 0x1F1F1F1Fu) + ((quadSpares[ qWidth ] >> 3) & 0x1F1F1F1Fu);
		dword s4;
		dword* pQuadSpares = quadSpares + (end - qWidth);
		for( sdword i2 = end, i1 = i2 - qWidth, i = i1;  i > 0; )
		{
			//i += ((i - qWidth) >> 31) & end;//i = i >= qWidth ? i : i + end;
			//i -= qWidth;
			const sdword back = ((i - qWidth) >> 31) & end;
			const sdword next = back - qWidth;
			pQuadSpares += next;
			i += next;

			k2 = k1;
			//k1 = (quadSpares[ i ] >> 3) & 0x1F1F1F1Fu;
			k1 = (*pQuadSpares >> 3) & 0x1F1F1F1Fu;
			s4 = s3;
			s3 = s2;
			s2 = s1;
			s1 = k1 + k2;
			quadPixels[ i2 ] = s1 + s2 + s3 + s4;

			i2 = i1;
			i1 = i;
		}
		k2 = k1;
		k1 = (quadSpares[ end ] >> 3) & 0x1F1F1F1Fu;
		s4 = s3;
		s3 = s2;
		s2 = s1;
		s1 = k1 + k2;
		quadPixels[ 1 ] = s1 + s2 + s3 + s4;
		quadPixels[ 0 ] = (((quadSpares[ end-qWidth ] >> 3) & 0x1F1F1F1Fu) + k1) + s1 + s2 + s3;
	}
}


/**
 * Blurs a rectangular int array with a circular kernel.
 * pixels are in 16.16bit fixed point format.
 *
 * @param kernelShape  which kernel profile to use
 * @param kernelWidth  kernel diameter, even numbers are rounded up to odds
 * @param unitized     whether to unitize/normalize the kernel
 * @param threshold    in-pixels <= this value are skipped
 * @param width        width of the 2D pixel array
 * @param height       height of the 2D pixel array
 * @param pixelsIn     input pixel array
 * @param pixelsOut    output pixel array
 */
void Blurs::spreadCircle
(
	const EKernel kernelShape,
	      sdword  kernelWidth,
	const bool    unitized,
	const sdword  threshold,
	const sdword  width,
	const sdword  height,
	const sdword  pixelsIn[],
	      sdword  pixelsOut[]
)
{
	/// clamp kernel width
	kernelWidth = kernelWidth < (width-1) ? kernelWidth : (width-1);

	/// make kernel
	kernelWidth = getKernelWidthInPixels( kernelWidth );
	std::auto_ptr<sdword> pKernel( new sdword[ kernelWidth * kernelWidth ] );
	fillKernel( kernelShape, kernelWidth, unitized, pKernel.get() );


	/// prepare
	const sdword*const kernelTopLeft = pKernel.get();

	const sdword halfKernelWidth = kernelWidth >> 1;
	const sdword leftEdge  = halfKernelWidth;
	const sdword rightEdge = width - 1 - halfKernelWidth;
	const sdword topEdge   = halfKernelWidth;
	const sdword botEdge   = height - 1 - halfKernelWidth;

	/// do pixels
	sdword x = width  - 1;
	sdword y = height - 1;
	for( sdword i = width * height;  i-- != 0;  y = x == 0 ? y-1 : y, x = x == 0 ? width : x, --x )
	{
		const sdword pixelIn        = pixelsIn[ i ];
		const sdword pixelInShifted = pixelIn >> 10;

		/// only do non blank pixels
		if( (pixelIn > threshold) | (-pixelIn > -threshold) )
		{
			/// treat edges specially so the spreading wraps around
			if( (x < leftEdge) | (x > rightEdge) | (y < topEdge) | (y > botEdge) )
			{
				sdword py = y + halfKernelWidth;
				for( int ky = kernelWidth * kernelWidth;  ky != 0;  --py )
				{
					ky -= kernelWidth;
					sdword px = x + halfKernelWidth;
					for( int kx = kernelWidth;  kx-- != 0;  --px )
					{
						px = px <  0      ? px + width  : px;
						px = px >= width  ? px - width  : px;
						py = py <  0      ? py + height : py;
						py = py >= height ? py - height : py;

						pixelsOut[ (py * width) + px ] += ((kernelTopLeft[ ky + kx ] * pixelInShifted) + sdword(0x20)) >> 6;
					}
				}
			}
			/// spread non-edge pixels without worrying about wrapping
			else
			{
				/// do chord pieces
				/// for large circular kernels it would be worth doing these separately so that empty
				/// kernel elements can be skipped
				/// ...


				/// do concentric in-squares (with fall-through switch cases)
				sdword* pPixelsOut = pixelsOut + (i - (halfKernelWidth * width));
				int k = halfKernelWidth;
				switch( kernelWidth )
				{
				default :
					{
						const sdword  back = kernelWidth - width;
						const sdword* pKer = kernelTopLeft + (kernelWidth * kernelWidth) - 1;
						sdword*       pOut = pixelsOut + i + halfKernelWidth + (halfKernelWidth * width);
						for( int ky = kernelWidth;  ky-- > 0; )
						{
							for( int kx = kernelWidth;  kx-- > 0; )
							{
								*pOut += ((*pKer * pixelInShifted) + sdword(0x20)) >> 6;
								--pOut;
								--pKer;
							}
							pOut += back;
						}
						break;
					}
				/*case 11 :
				case 10 :
					{
						const sdword val1 = ((kernelTopLeft[ k     ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val2 = ((kernelTopLeft[ k + 1 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val3 = ((kernelTopLeft[ k + 2 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val4 = ((kernelTopLeft[ k + 3 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val5 = ((kernelTopLeft[ k + 4 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val6 = ((kernelTopLeft[ k + 5 ] * pixelInShifted) + sdword(0x20)) >> 6;
						k += kernelWidth;

						*(pPixelsOut)          += val1;
						*(++pPixelsOut)        += val2;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val4;
						*(++pPixelsOut)        += val5;
						*(++pPixelsOut)        += val6;
						*(pPixelsOut += width) += val5;
						*(pPixelsOut += width) += val4;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val1;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val4;
						*(pPixelsOut += width) += val5;
						*(pPixelsOut += width) += val6;
						*(--pPixelsOut)        += val5;
						*(--pPixelsOut)        += val4;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val1;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val4;
						*(--pPixelsOut)        += val5;
						*(--pPixelsOut)        += val6;
						*(pPixelsOut -= width) += val5;
						*(pPixelsOut -= width) += val4;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val1;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val4;
						*(pPixelsOut -= width) += val5;
						*(pPixelsOut -= width) += val6;
						*(++pPixelsOut)        += val5;
						*(++pPixelsOut)        += val4;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val2;
						++pPixelsOut;
						pPixelsOut += width;
					}
				case 9 :
				case 8 :
					{
						const sdword val1 = ((kernelTopLeft[ k     ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val2 = ((kernelTopLeft[ k + 1 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val3 = ((kernelTopLeft[ k + 2 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val4 = ((kernelTopLeft[ k + 3 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val5 = ((kernelTopLeft[ k + 4 ] * pixelInShifted) + sdword(0x20)) >> 6;
						k += kernelWidth;

						*(pPixelsOut)          += val1;
						*(++pPixelsOut)        += val2;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val4;
						*(++pPixelsOut)        += val5;
						*(pPixelsOut += width) += val4;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val1;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val4;
						*(pPixelsOut += width) += val5;
						*(--pPixelsOut)        += val4;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val1;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val4;
						*(--pPixelsOut)        += val5;
						*(pPixelsOut -= width) += val4;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val1;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val4;
						*(pPixelsOut -= width) += val5;
						*(++pPixelsOut)        += val4;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val2;
						++pPixelsOut;
						pPixelsOut += width;
					}*/
				case 7 :
				case 6 :
					{
						const sdword val1 = ((kernelTopLeft[ k     ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val2 = ((kernelTopLeft[ k + 1 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val3 = ((kernelTopLeft[ k + 2 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val4 = ((kernelTopLeft[ k + 3 ] * pixelInShifted) + sdword(0x20)) >> 6;
						k += kernelWidth;

						*(pPixelsOut)          += val1;
						*(++pPixelsOut)        += val2;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val4;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val1;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val3;
						*(pPixelsOut += width) += val4;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val1;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val3;
						*(--pPixelsOut)        += val4;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val1;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val3;
						*(pPixelsOut -= width) += val4;
						*(++pPixelsOut)        += val3;
						*(++pPixelsOut)        += val2;
						++pPixelsOut;
						pPixelsOut += width;
					}
				case 5 :
				case 4 :
					{
						const sdword val1 = ((kernelTopLeft[ k     ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val2 = ((kernelTopLeft[ k + 1 ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val3 = ((kernelTopLeft[ k + 2 ] * pixelInShifted) + sdword(0x20)) >> 6;
						k += kernelWidth;

						*(pPixelsOut)          += val1;
						*(++pPixelsOut)        += val2;
						*(++pPixelsOut)        += val3;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val1;
						*(pPixelsOut += width) += val2;
						*(pPixelsOut += width) += val3;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val1;
						*(--pPixelsOut)        += val2;
						*(--pPixelsOut)        += val3;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val1;
						*(pPixelsOut -= width) += val2;
						*(pPixelsOut -= width) += val3;
						*(++pPixelsOut)        += val2;
						++pPixelsOut;
						pPixelsOut += width;
					}
				case 3 :
				case 2 :
					{
						const sdword val1 = ((kernelTopLeft[ k     ] * pixelInShifted) + sdword(0x20)) >> 6;
						const sdword val2 = ((kernelTopLeft[ k + 1 ] * pixelInShifted) + sdword(0x20)) >> 6;
						k += kernelWidth;

						*(pPixelsOut)          += val1;
						*(++pPixelsOut)        += val2;
						*(pPixelsOut += width) += val1;
						*(pPixelsOut += width) += val2;
						*(--pPixelsOut)        += val1;
						*(--pPixelsOut)        += val2;
						*(pPixelsOut -= width) += val1;
						*(pPixelsOut -= width) += val2;
						++pPixelsOut;
						pPixelsOut += width;
					}
				case 1 :
					{
						const sdword val1 = ((kernelTopLeft[ k ] * pixelInShifted) + sdword(0x20)) >> 6;
						*(pPixelsOut) += val1;
					}
				case 0 : ;
				}
			}
		}
	}
}


sdword Blurs::getKernelWidthInPixels
(
	const sdword kernelWidth
) ///static
{
	return kernelWidth < 0 ? 1 : kernelWidth | 1;
}


void Blurs::fillKernel
(
	const EKernel kernelShape,
	const sdword  kernelWidth,
	const bool    unitized,
	sdword*const  pKernel
) /// static
{
	const sdword width     = getKernelWidthInPixels( kernelWidth );
	const float  halfWidth = float( width / 2 );
	float (*function)( float ) = kernelShape == eBox ? &box : (kernelShape == eHat ? &hat : &gaussian);

	/// step thru kernel elements
	sdword kernelSum = 0;
	for( int y = width;  y-- != 0; )
	{
		for( int x = width;  x-- != 0; )
		{
			/// step thru kernel subsamples
			float subSampleSum = 0;
			const int   subSampleWidth     = 8;
			const float halfSubSampleWidth = float( subSampleWidth ) * 0.5f;
			for( int sy = subSampleWidth;  sy-- != 0; )
			{
				const float yDist  = float( y  ) - halfWidth;
				const float syDist = (float( sy ) + 0.5f) - halfSubSampleWidth;
				const float bDist  = ( yDist + (syDist / subSampleWidth) ) / halfWidth;

				for( int sx = subSampleWidth;  sx-- != 0; )
				{
					const float xDist  = float( x  ) - halfWidth;
					const float sxDist = (float( sx ) + 0.5f) - halfSubSampleWidth;
					const float aDist  = ( xDist + (sxDist / subSampleWidth) ) / halfWidth;

					const float distFromCenter = float( std::sqrt( double((aDist * aDist) + (bDist * bDist)) ) );
					subSampleSum += function( distFromCenter );
				}
			}
			const sdword meanSubSample = fpToInt(subSampleSum * 65536.0f + 0.5f) / (subSampleWidth * subSampleWidth);

			//pKernel[ (y * width) + x ] = (x*10) + y + (width*1000);   /// TEST ///
			pKernel[ (y * width) + x ] = meanSubSample;
			kernelSum += meanSubSample;
		}
	}

	/// unitize kernel
	if( unitized )
	{
		const float oneOverSum = 1.0f / ( float( kernelSum ) / 65536.0f );
		sdword unitizedSum = 0;
		for( int e = width*width;  e-- != 0; )
		{
			const float  element       = float( pKernel[ e ] ) / 65536.0f;
			const sdword elementScaled = sdword( (element * oneOverSum) * 65536.0f + 0.5f );

			pKernel[ e ] = elementScaled;
			unitizedSum += elementScaled;
		}

		/// compensate for unitization error
		pKernel[ (width * width) >> 1 ] += (sdword(65536) - unitizedSum);
	}
}


float Blurs::box( const float x )   /// static
{
	return x <= 1.0f ? 1.0f : 0.0f;
}


float Blurs::hat( float x )   /// static
{
	x  =  x < 1.0f ? x : 1.0f;
	return 1.0f - x;
}


float Blurs::gaussian( const float x )   /// static
{
	/// do this sometime, use hat for now...

		x  =  x < 1.0f ? x : 1.0f;
		return 1.0f - x;
}
