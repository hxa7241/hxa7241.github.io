///  artifex@computer.org  |  2001-07-22  ///


#ifndef Blurs_h
#define Blurs_h

#include "Primitives.h"




/**
 * Fast, decent quality small 2D blurs.
 *
 * Works on 2D int 'images' stored in 1D arrays.
 *
 * Gather blurs wrap around in a 'helical' way - each row/column wraps to the
 * end of the <i>next</i> one,
 * and, the top left and bottom right 1 by 2 area of pixels dont always get filled
 * in correctly.
 *
 * Spread blurs wrap correctly.
 */
class Blurs
{
public:

	static void gatherSquare3( sdword iterations, sdword width, sdword height,
	                           sdword pixelsSpare[], sdword pixelsInOut[] );
	static void gatherSquare5( sdword iterations, sdword width, sdword height,
	                           sdword pixelsSpare[], sdword pixelsInOut[] );

	static void gatherSquare3( sdword iterations, sdword width, sdword height,
	                           sbyte pixelsSpare[], sbyte pixelsInOut[] );
	static void gatherSquare5( sdword iterations, sdword width, sdword height,
	                           sbyte pixelsSpare[], sbyte pixelsInOut[] );


	enum EKernel { eBox, eHat, eGaussian };

	static void spreadCircle( EKernel kernelShape, sdword kernelWidth, bool unitized,
	                          sdword threshold,
	                          sdword width, sdword height,
	                          const sdword pixelsIn[], sdword pixelsOut[] );


protected:


private:
	/// kernel definition
	static sdword getKernelWidthInPixels( sdword kernelWidth );
	static void   fillKernel( EKernel kernelShape, sdword kernelWidth, bool unitized, sdword* pKernel );

	static float  box( float x );
	static float  hat( float x );
	static float  gaussian( float x );



	/// disallow
	                 Blurs();
	                ~Blurs();
	                 Blurs( const Blurs& );
	          Blurs& operator=( const Blurs& );
};




#endif//Blurs_h
