///  artifex@computer.org  |  2001-07-22  ///


#include "FpToInt.h"
