///  artifex@computer.org  |  2001-07-22  ///


#ifndef FpToInt_h
#define FpToInt_h


#include "Primitives.h"




/// INLINES ///

/*inline
sdword fpToInt( float f )
{
	f += float( 1 << 23 );
	return *(reinterpret_cast<sdword*>( &f )) & sdword(0x7FFFFF);
}*/


inline
sdword fpToInt( const float f )
{
	double dtemp = ((((65536.0 * 65536.0 * 16) + (65536.0 * 0.5))* 65536.0)) + double(f);
	return *(reinterpret_cast<sdword*>( &dtemp )) - sdword(0x80000000);
}


inline
sdword fpToInt1616( const float f )
{
	double dtemp = ((((65536.0 * 16) + (0.5))* 65536.0)) + double(f);
	return *(reinterpret_cast<sdword*>( &dtemp )) - sdword(0x80000000);
}




#endif//FpToInt_h
