///  artifex@computer.org  |  2001-07-22  ///


#ifndef RandomFast_h
#define RandomFast_h


#include "Primitives.h"




/**
 * Simplest fastest random number generator.
 *
 * Not very random, but it is fast.
 * 'Numerical Recipes In C', ch7 p284-285
 * www.nr.com
 */
class RandomFast
{
public:
/// construction
	RandomFast( const sdword seed =0 )
		: random_m( seed )
	{
	}


/// direct access
	void setSeed( const sdword seed )
	{
		random_m = seed;
	}

	sdword getSeed()
	{
		return random_m;
	}


/// sequence values
	sdword nextSdword()
	{
		return random_m = sdword(1664525) * random_m + sdword(1013904223);
	}

	float nextFloat()
	{
		random_m = sdword(1664525) * random_m + sdword(1013904223);

		sdword itemp = sdword(0x3F800000) | (sdword(0x007FFFFF) & random_m);
		return *(reinterpret_cast<float*>(&itemp)) - 1.0f;
	}


private:
/// current value of sequence and seed of the rest of the sequence
	sdword random_m;

};




/*
test sequence of 32-bit values (hex):
00000000, 3C6EF35F, 47502932, D1CCF6E9,
AAF95334, 6252E503, 9F2EC686, 57FE6C2D,
A3D95FA8, 81FDBEE7, 94F0AF1A, CBF633B1
*/




#endif//RandomFast_h
