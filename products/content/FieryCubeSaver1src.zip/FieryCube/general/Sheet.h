///  artifex@computer.org  |  2001-07-22  ///


#ifndef Sheet_h
#define Sheet_h


#include "Primitives.h"

#include "Array.h"




template<class TYPE>
class Sheet
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                Sheet();
	                Sheet( sdword width, sdword height );                  /// throws
	                Sheet( sdword width, sdword height, bool zeroMem );    /// throws

	virtual        ~Sheet();
	                Sheet( const Sheet& );
	         Sheet& operator=( const Sheet& );
	/// ---------------------------------------------------------


	/// set size
	        void    setSize( sdword width, sdword height );                /// throws
	        void    setSize( sdword width, sdword height, bool zeroMem );  /// throws

	/// get size
	        sdword  getLength()                                            const;
	        sdword  getWidth()                                             const;
	        sdword  getHeight()                                            const;

	/// check size
	static  bool    isSizeWithinRange( sdword width, sdword height );
	static  sdword  getMaxSize();

	/// access
	        TYPE&   operator[]( int i )                                    const;
	        TYPE*   getMemory()                                            const;
	        TYPE*   getRow( sdword y )                                     const;

	/// util
	        void    zeroMemory()                                           const;

	/// clone
	virtual Sheet*  clone()                                                const;


protected: //--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--
	/// virtual assignment
	        void    assign( const Sheet<TYPE>& );


	/// data
	        Array<TYPE>  memory_m;
	        sdword       width_m;
	        sdword       height_m;


private: ///////////////////////////////////////////////////////////////////////////////////////////
};








/// TEMPLATE MEMBERS ///


/// standard object services //////////////////////////////////////////////////////////////////////
template<class TYPE>
Sheet<TYPE>::Sheet()
 : memory_m(),
   width_m( 0 ),
   height_m( 0 )
{
}


template<class TYPE>
Sheet<TYPE>::Sheet( const sdword width, const sdword height )
 : memory_m(),
   width_m( 0 ),
   height_m( 0 )
{
	Sheet<TYPE>::setSize( width, height );
}


template<class TYPE>
Sheet<TYPE>::Sheet( const sdword width, const sdword height, const bool zeroMem )
 : memory_m(),
   width_m( 0 ),
   height_m( 0 )
{
	Sheet<TYPE>::setSize( width, height, zeroMem );
}


template<class TYPE>
Sheet<TYPE>::~Sheet()
{
}


template<class TYPE>
Sheet<TYPE>::Sheet( const Sheet<TYPE>& sh )
 : memory_m(),
   width_m( 0 ),
   height_m( 0 )
{
	Sheet<TYPE>::assign( sh );
}


template<class TYPE>
Sheet<TYPE>& Sheet<TYPE>::operator=( const Sheet<TYPE>& sh )
{
	assign( sh );

	return *this;
}




/// size ///////////////////////////////////////////////////////////////////////////////////////////
template<class TYPE>
void Sheet<TYPE>::setSize( const sdword width, const sdword height )
{
	if( !isSizeWithinRange( width, height ) )
	{
		throw "Sheet<TYPE>::setSize()\nsize not within range";
	}

	memory_m.setLength( width * height );
   width_m  = width;
   height_m = height;
}


template<class TYPE>
void Sheet<TYPE>::setSize( const sdword width, const sdword height, const bool zeroMem )
{
	setSize( width, height );

	if( zeroMem )
	{
		memory_m.zeroMemory();
	}
}


template<class TYPE>
inline
sdword Sheet<TYPE>::getLength() const
{
	return memory_m.getLength();
}


template<class TYPE>
inline
sdword Sheet<TYPE>::getWidth() const
{
	return width_m;
}


template<class TYPE>
inline
sdword Sheet<TYPE>::getHeight() const
{
	return height_m;
}


template<class TYPE>
bool Sheet<TYPE>::isSizeWithinRange( const sdword width, const sdword height )   /// static
{
	bool isWithin = true;

	/// is negative ?
	if( (width < 0) || (height < 0) )
	{
		isWithin = false;
	}
	else if( height != 0 )   /// prevent divide by zero
	{
		/// is the total number of elements greater than max length ?
		if( width > (getMaxSize() / height) )
		{
			isWithin = false;
		}
	}

	return isWithin;
}


template<class TYPE>
inline
sdword Sheet<TYPE>::getMaxSize()   /// static
{
	return Array<TYPE>::getMaxLength();
}




/// access /////////////////////////////////////////////////////////////////////////////////////////
template<class TYPE>
inline
TYPE& Sheet<TYPE>::operator[]( int i ) const
{
	return memory_m.getMemory()[ i ];
}


template<class TYPE>
inline
TYPE* Sheet<TYPE>::getMemory() const
{
	return memory_m.getMemory();
}


template<class TYPE>
inline
TYPE* Sheet<TYPE>::getRow( sdword y ) const
{
	y = (y >= 0) ? y : -y;
	return memory_m.getMemory() + (y % height_m) * width;
}




/// util ///////////////////////////////////////////////////////////////////////////////////////////
template<class TYPE>
inline
void Sheet<TYPE>::zeroMemory() const
{
	memory_m.zeroMemory();
}




/// clone //////////////////////////////////////////////////////////////////////////////////////////
template<class TYPE>
Sheet<TYPE>* Sheet<TYPE>::clone() const
{
	Sheet<TYPE>* clone = new Sheet<TYPE>( *this );
	if( clone == 0 )
	{
		throw "Sheet<TYPE>::clone()\ncouldnt get memory";
	}

	return  clone;
}




/// protected //--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//

/// virtual assignment /////////////////////////////////////////////////////////////////////////////
template<class TYPE>
void Sheet<TYPE>::assign( const Sheet<TYPE>& sh )
{
	memory_m = sh.memory_m;
	width_m  = sh.width_m;
	height_m = sh.height_m;
}




#endif//Sheet_h
