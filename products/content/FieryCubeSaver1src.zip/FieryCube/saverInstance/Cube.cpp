///  artifex@computer.org  |  2001-07-22  ///


#include "Cube.h"

#include "FpToInt.h"
#include "RandomFast.h"
#include <math>




/// statics
const float Cube::rotationIncXDflt_m = (32.0f / 180.0f * 3.141592653f);
const float Cube::rotationIncYDflt_m = (14.0f / 180.0f * 3.141592653f);
const float Cube::rotationIncZDflt_m = (20.0f / 180.0f * 3.141592653f);

const float Cube::unitVerticesX_m[ 8 ] = { -1, +1, +1, -1, -1, +1, +1, -1 };
const float Cube::unitVerticesY_m[ 8 ] = { -1, -1, +1, +1, -1, -1, +1, +1 };
const float Cube::unitVerticesZ_m[ 8 ] = { -1, -1, -1, -1, +1, +1, +1, +1 };

const sdword Cube::noOfPolylines_m   = 4;
const sdword Cube::polylines_m[ 4 ]  = { 4, 4, 4, 4 };
const sdword Cube::pvIndexes_m[ 16 ] = { 0, 3, 2, 6,  4, 0, 1, 2,  1, 5, 4, 7,  3, 7, 6, 5 };

const float Cube::unitPerspectiveness_m = 0.25f;//0.4f;
const float Cube::screenScaling_m       = 1.5f * 0.55f;//0.6f;




/// standard object services //////////////////////////////////////////////////////////////////////
Cube::Cube
(
	const sdword width,
	const sdword height,
	const sdword thickness,
	const float  framesPerSecond,
	const sdword randSeed
)
{
	set( width, height, thickness );


	/// set rotation increments
	{
		const int ordering[6][3] = { { 0, 1, 2 }, { 0, 2, 1 }, { 1, 0, 2 }, { 1, 2, 0 }, { 2, 0, 1 }, { 2, 1, 0 } };
		const float xyz[] = { rotationIncXDflt_m, rotationIncYDflt_m, rotationIncZDflt_m };
		RandomFast rand( randSeed );

		const int order = ((rand.nextSdword() & 0x7FFFFFFF) >> 16) % 6;
		rotationIncX_m = xyz[ ordering[order][0] ];
		rotationIncY_m = xyz[ ordering[order][1] ];
		rotationIncZ_m = xyz[ ordering[order][2] ];

		rotationIncX_m = (rand.nextSdword() < 0) ? -rotationIncX_m : rotationIncX_m;
		rotationIncY_m = (rand.nextSdword() < 0) ? -rotationIncY_m : rotationIncY_m;
		rotationIncZ_m = (rand.nextSdword() < 0) ? -rotationIncZ_m : rotationIncZ_m;

		notifyOfFrameRate( framesPerSecond );
	}


	/// init rotation position
	rotationX_m = rotationIncX_m * frameRateFactor_m * 10.0f;
	rotationY_m = rotationIncY_m * frameRateFactor_m * 10.0f;
	rotationZ_m = rotationIncZ_m * frameRateFactor_m * 10.0f;
}


Cube::~Cube()
{
}




/// adjust /////////////////////////////////////////////////////////////////////////////////////////
void Cube::set
(
	const sdword width,
	const sdword height,
	const sdword thickness
)
{
	/// save image dimension info
	width_m     = width;
	height_m    = height;
	thickness_m = thickness;


	/// scale cube to fit cube diagonal inside image width and height
	//const float imageSmallerDim = width < height ? float(width) : float(height);
	const float cubeDiagonal = float(::sqrt( double((2.0f * 2.0f) + (2.0f * 2.0f) + (2.0f * 2.0f)) ));

	scaling_m         = height / cubeDiagonal;//imageSmallerDim / cubeDiagonal;
	enclosingRadius_m = (cubeDiagonal / 2.0f) * scaling_m;
	perspectiveness_m = (unitPerspectiveness_m * 0.7f) / scaling_m;

	for( int i = 8;  i-- != 0; )
	{
		verticesX_m[i] = unitVerticesX_m[i] * scaling_m;
		verticesY_m[i] = unitVerticesY_m[i] * scaling_m;
		verticesZ_m[i] = unitVerticesZ_m[i] * scaling_m;
	}
}


void Cube::notifyOfFrameRate
(
	const float framesPerSecond
)
{
	frameRateFactor_m = 1.0f / (1.2f * framesPerSecond);
}




/// update /////////////////////////////////////////////////////////////////////////////////////////
void Cube::updateAndDraw
(
	const sbyte color,
	sbyte image[]
)
{
	const sdword halfWidth  = width_m  >> 1;
	const sdword halfHeight = height_m >> 1;

	/// calc rotation 'matrix'
	/// (the cube isnt rotated incrementally because i want to elimate any drift - being used
	/// in a screensaver means it might be running for hours, or maybe even weeks if someone
	/// goes on holiday and leaves their pc on at work!)
	const float sinRotationX = std::sin( rotationX_m );   /// could use the sincos instruction here...
	const float cosRotationX = std::cos( rotationX_m );
	const float sinRotationY = std::sin( rotationY_m );
	const float cosRotationY = std::cos( rotationY_m );
	const float sinRotationZ = std::sin( rotationZ_m );
	const float cosRotationZ = std::cos( rotationZ_m );

	/// rotate vertices into screen coords
	for( int i = 8;  i-- != 0; )
	{
		/// rotate
		float vertX = verticesX_m[ i ];
		float vertY = verticesY_m[ i ];
		float vertZ = verticesZ_m[ i ];

		float tmp1 = vertY;
		float tmp2 = vertZ;
		vertY = (tmp1 * cosRotationX) - (tmp2 * sinRotationX);
		vertZ = (tmp2 * cosRotationX) + (tmp1 * sinRotationX);

		tmp1 = vertZ;
		tmp2 = vertX;
		vertZ = (tmp1 * cosRotationY) - (tmp2 * sinRotationY);
		vertX = (tmp2 * cosRotationY) + (tmp1 * sinRotationY);

		tmp1 = vertX;
		tmp2 = vertY;
		vertX = (tmp1 * cosRotationZ) - (tmp2 * sinRotationZ);
		vertY = (tmp2 * cosRotationZ) + (tmp1 * sinRotationZ);

		/// project
		const float projection = screenScaling_m / (1.0f + ((vertZ + enclosingRadius_m) * perspectiveness_m));
		screenXYs_m[i].first   = ::fpToInt( (vertX * projection * 65536.0f) + 0.5f ) + (halfWidth  << 16);
		screenXYs_m[i].second  = ::fpToInt( (vertY * projection * 65536.0f) + 0.5f ) + (halfHeight << 16);
	}

	/// increment rotation position, keeping within first cycle to eliminate any drift
	const float twoPi = 2.0f * 3.141592653f;
	rotationX_m += rotationIncX_m * frameRateFactor_m;
	rotationX_m = rotationX_m > twoPi ? rotationX_m - twoPi : rotationX_m;
	rotationX_m = rotationX_m <  0.0f ? rotationX_m + twoPi : rotationX_m;
	rotationY_m += rotationIncY_m * frameRateFactor_m;
	rotationY_m = rotationY_m > twoPi ? rotationY_m - twoPi : rotationY_m;
	rotationY_m = rotationY_m <  0.0f ? rotationY_m + twoPi : rotationY_m;
	rotationZ_m += rotationIncZ_m * frameRateFactor_m;
	rotationZ_m = rotationZ_m > twoPi ? rotationZ_m - twoPi : rotationZ_m;
	rotationX_m = rotationZ_m <  0.0f ? rotationZ_m + twoPi : rotationZ_m;


	/// prepare draw function data structure
	for( int i = 16;  i-- != 0; )
	{
		polylineVerts_m[i] = screenXYs_m[ pvIndexes_m[i] ];
	}

	/// draw
	polyPolyline( color, thickness_m, width_m, image, polylineVerts_m, polylines_m, noOfPolylines_m );


	// like the win32 function:
	//BOOL ::PolyPolyline(
	//	HDC hdc,                      // handle to device context
	//	CONST POINT *lppt,            // array of points
	//	CONST DWORD *lpdwPolyPoints,  // array of values
	//	DWORD cCount                  // number of entries in values array
	//);
}


void Cube::polyPolyline
(
	const sbyte  color,
	const sdword thickness,
	const sdword width,
	sbyte  pixels[],
	const std::pair<sdword,sdword> polylineVerts[],
	const sdword polylines[],    /// sub-lengths of polylineVerts[]
	const sdword noOfPolylines   /// length of polylines[]
) /// static
{
	int vert = 0;
	for( int i = 0;  i < noOfPolylines;  ++i )
	{
		const int end = vert + polylines[ i ];
		if( vert < end )
		{
			std::pair<sdword,sdword> lastPoint = polylineVerts[ vert ];
			for( ;  ++vert < end; )
			{
				const std::pair<sdword,sdword> point = polylineVerts[ vert ];

				drawLine( lastPoint.first, lastPoint.second, point.first, point.second, color, thickness, width, 0, pixels );

				lastPoint = point;
			}
		}
	}
}


void Cube::drawLine
(
	sdword x0,
	sdword y0,
	sdword x1,
	sdword y1,
	const  sbyte ,//color,
	sdword thickness,
	const  sdword widthPixels,
	const  sdword,// heightPixels,
	sbyte  pPixels[]
) /// static
{
	if( thickness < 1 )
	{
		return;
	}

	/// draw end-caps
	drawEndCaps( x0, y0, x1, y1, 0xFF, thickness, widthPixels, pPixels );


	--thickness;


	/// compensate thickness for angle
	{
		const sdword xdif       = (x1 - x0 + 0x8000) >> 16;
		const sdword ydif       = (y1 - y0 + 0x8000) >> 16;
		const float  hypot      = float( std::sqrt( double((xdif * xdif) + (ydif * ydif)) ) );
		const sdword xdifabs    = xdif >= 0 ? xdif : -xdif;
		const sdword ydifabs    = ydif >= 0 ? ydif : -ydif;
		const sdword longerSide = (xdifabs > ydifabs) ? xdifabs : ydifabs;

		thickness = (longerSide != 0) ? ::fpToInt( hypot * (float(thickness) / float(longerSide)) + 0.5f ) : thickness;
		thickness = thickness < 1 ? 1 : thickness;
	}


	/// prepare to iterate
	/// (should be possible to find a neater refactoring here, but wow, its so easy to get something wrong)
	sdword len;
	sdword yFrac;
	sdword yFracInc;
	sdword pIncX;
	sdword pIncY;
	sbyte* pPixel;
	{
		const sdword xDif    = x1 - x0;
		const sdword yDif    = y1 - y0;
		const sdword xDifAbs = xDif < 0 ? -xDif : xDif;
		const sdword yDifAbs = yDif < 0 ? -yDif : yDif;

		if( xDifAbs >= yDifAbs )
		{
			const sdword xStart = yDif < 0 ? x1 : x0;
			const sdword yStart = yDif < 0 ? y1 : y0;
			len      = (xDifAbs + 0x8000) >> 16;
			yFrac    = yStart & 0xFFFF;
			yFracInc = sdword((float(yDifAbs) / float(xDifAbs)) * 65536.0f);
			pIncX    = (xDif < 0) ^ (yDif < 0) ? -1 : 1;
			pIncY    = widthPixels;
			pPixel   = pPixels + (xStart >> 16) + ((yStart >> 16) * widthPixels);
		}
		else
		{
			const sdword xStart = xDif < 0 ? x1 : x0;
			const sdword yStart = xDif < 0 ? y1 : y0;
			len      = (yDifAbs + 0x8000) >> 16;
			yFrac    = xStart & 0xFFFF;
			yFracInc = sdword((float(xDifAbs) / float(yDifAbs)) * 65536.0f);
			pIncX    = (xDif < 0) ^ (yDif < 0) ? -widthPixels : widthPixels;
			pIncY    = 1;
			pPixel   = pPixels + (xStart >> 16) + ((yStart >> 16) * widthPixels);
		}
	}


	const sdword outerEdge1 = (thickness >> 1) * pIncY;
	const sdword outerEdge2 = (thickness - (thickness >> 1)) * pIncY;

	/// iterate
	while( len-- > 0 )
	{
		/// draw
		{
//			const sbyte pixel = static_cast<sbyte>(yFrac >> 8);
//			*pPixel           = ~pixel;
//			*(pPixel + pIncY) =  pixel;

			const sbyte shade = static_cast<sbyte>(yFrac >> 8);

			*(pPixel + outerEdge1 + pIncY) |= shade;
			*(pPixel - outerEdge2)         |= sbyte(~shade);   /// cast to stop compiler warning

			sdword edge = outerEdge1;
			switch( thickness )
			{
				default :
				for( int i = thickness - 23;  true; )   /// only odd thickness > 23
				{
					*(pPixel - edge) = 0xFF;
					*(pPixel + edge) = 0xFF;   edge -= pIncY;
					if( --i <= 0 )   break;
				}
				case 23 :   *(pPixel - edge) = 0xFF;
				case 22 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 21 :   *(pPixel - edge) = 0xFF;
				case 20 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 19 :   *(pPixel - edge) = 0xFF;
				case 18 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 17 :   *(pPixel - edge) = 0xFF;
				case 16 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 15 :   *(pPixel - edge) = 0xFF;
				case 14 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 13 :   *(pPixel - edge) = 0xFF;
				case 12 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case 11 :   *(pPixel - edge) = 0xFF;
				case 10 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case  9 :   *(pPixel - edge) = 0xFF;
				case  8 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case  7 :   *(pPixel - edge) = 0xFF;
				case  6 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case  5 :   *(pPixel - edge) = 0xFF;
				case  4 :   *(pPixel + edge) = 0xFF;   edge -= pIncY;
				case  3 :   *(pPixel - edge) = 0xFF;
				case  2 :   *(pPixel + edge) = 0xFF;
				case  1 :   *(pPixel)        = 0xFF;
				case  0 :   ;
			}
		}

		/// move
		{
			yFrac += yFracInc;
			const sdword intCrossing = sdword(dword(yFrac & 0x00010000) << 15) >> 31;
			yFrac &= 0xFFFF;

			pPixel += pIncX + (intCrossing & pIncY);
		}
	}
}


void Cube::drawEndCaps
(
	const sdword x0,
	const sdword y0,
	const sdword x1,
	const sdword y1,
	const sbyte  color,
	const sdword thickness,
	const sdword widthPixels,
	      sbyte  pPixels[]
) /// static
{
	drawEndCap( x0, y0, color, thickness, widthPixels, pPixels );
	drawEndCap( x1, y1, color, thickness, widthPixels, pPixels );
}


/*
 * somewhat imperfect line end-caps, but good enough for these purposes
 */
void Cube::drawEndCap
(
	const sdword xCenter,
	const sdword yCenter,
	const sbyte  ,//color,
	const sdword thickness,
	const sdword widthPixels,
	      sbyte  pPixels[]
) /// static
{
	const sdword radius = thickness < 0 ? 0 : thickness >> 1;
	if( radius == 0 )
	{
		return;
	}


	sdword x   = 0;
	sdword y   = radius;
	sdword d   = 1 - radius;
	sdword de  = 3;
	sdword dse = -2 * radius + 5;

	sbyte*const pCenter = pPixels + ((xCenter + 0x8000) >> 16) + (((yCenter + 0x8000) >> 16) * widthPixels);

	while( true )
	{
		/// fill circle
		{
			sbyte* pUpper = pCenter - x + (y * widthPixels);
			sbyte* pLower = pCenter - x - (y * widthPixels);
			*pUpper |= 0x7F;   /// its not filtering but it helps a little
			*pLower |= 0x7F;
			*(pUpper + (x << 1)) |= 0x7F;
			*(pLower + (x << 1)) |= 0x7F;
			switch( x )
			{
			default :
				for( int i = x - 4;  true; )
				{
		            *(++pUpper) = *(++pLower) = 0xFF;
					*(++pUpper) = *(++pLower) = 0xFF;
					if( --i <= 0 )   break;
				}
			case  4 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  3 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  2 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  1 :   *(++pUpper) = *(++pLower) = 0xFF;
			case  0 :   ;
			}

			pUpper = pCenter - y + (x * widthPixels);
			pLower = pCenter - y - (x * widthPixels);
			*pUpper |= 0x7F;
			*pLower |= 0x7F;
			*(pUpper + (y << 1)) |= 0x7F;
			*(pLower + (y << 1)) |= 0x7F;
			switch( y )
			{
			default :
				for( int i = y - 4;  true; )
				{
					*(++pUpper) = *(++pLower) = 0xFF;
					*(++pUpper) = *(++pLower) = 0xFF;
					if( --i <= 0 )   break;
				}
			case  4 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  3 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  2 :   *(++pUpper) = *(++pLower) = 0xFF;
			            *(++pUpper) = *(++pLower) = 0xFF;
			case  1 :   *(++pUpper) = *(++pLower) = 0xFF;
			case  0 :   ;
			}
		}

		if( !(y > x) )   break;

		const sdword dLargerEqualThan0 = ~(d >> 31);

		d   += (de & ~dLargerEqualThan0) | (dse & dLargerEqualThan0);
		de  += 2;
		dse += 2 << (1 & dLargerEqualThan0);
		++x;
		y   -= (1 & dLargerEqualThan0);
	}
}












/**
 * Draw a thick line with no filtering.
 *
 * adapted from a java version in an MIT course somewhere on the web...
 */
/*void Cube::drawLine
(
	sdword x0,
	sdword y0,
	sdword x1,
	sdword y1,
	const  sbyte  color,
	sdword thickness,
	const  sdword widthPixels,
	const  sdword,// heightPixels,
	sbyte  pPixels[]
) /// static
{
	thickness = thickness < 0 ? 0 : thickness;


	/// draw end-caps
	drawEndCaps( x0, y0, x1, y1, color, thickness, widthPixels, pPixels );


	/// compensate thickness for angle
	{
		const sdword xdif       = x1 - x0;
		const sdword ydif       = y1 - y0;
		const float  hypot      = float( std::sqrt( double((xdif * xdif) + (ydif * ydif)) ) );
		const sdword xdifabs    = xdif >= 0 ? xdif : -xdif;
		const sdword ydifabs    = ydif >= 0 ? ydif : -ydif;
		const sdword longerSide = (xdifabs > ydifabs) ? xdifabs : ydifabs;

		thickness = (longerSide != 0) ? ::fpToInt( hypot * (float(thickness) / float(longerSide)) + 0.5f ) : thickness;
		thickness = thickness < 0 ? 0 : thickness;
	}


	sdword dy = y1 - y0;
	sdword dx = x1 - x0;
	sdword stepx;
	sdword stepy;
	//sdword v2dx = 0;
	//sdword id   = ;
	if( dy < 0 )
	{
		dy    = -dy;
		stepy = -widthPixels;
	}
	else
	{
		stepy = widthPixels;
	}
	if( dx < 0 )
	{
		dx    = -dx;
		stepx = -1;
	}
	else
	{
		stepx = 1;
	}
	dy <<= 1;
	dx <<= 1;
	y0 *= widthPixels;
	y1 *= widthPixels;
	pPixels[ x0 + y0 ] = color;
	if( dx > dy )
	{
		sdword fraction = dy - (dx >> 1);
		const sdword outerEdge = (thickness >> 1) * widthPixels;
		while( x0 != x1 )
		{
//			if( fraction >= 0 )
//			{
//				y0       += stepy;
//				fraction -= dx;
//			}
			const sdword f = fraction;
			const sdword fge0 = ~(fraction >> 31);
			y0       += fge0 & stepy;
			fraction -= fge0 & dx;
			x0       += stepx;
			fraction += dy;

			sbyte*  p    = pPixels + x0 + y0;
			sdword  edge = outerEdge;

			if( thickness & 1 )
				*(p - edge) = (sbyte((stepy >> 31) & f)) | (~((stepy >> 31) ) & -f);
			*(p + edge) = (sbyte((stepy >> 31) & -f)) | (~((stepy >> 31) ) & f);
			edge -= widthPixels;

			switch( thickness - 2 )
			{
				default :
				for( int i = thickness - 2 - 23;  true; )   /// only odd thickness > 23
				{
					*(p - edge) = color;
					*(p + edge) = color;   edge -= widthPixels;
					if( --i <= 0 )   break;
				}
				case 23 :   *(p - edge) = color;
				case 22 :   *(p + edge) = color;   edge -= widthPixels;
				case 21 :   *(p - edge) = color;
				case 20 :   *(p + edge) = color;   edge -= widthPixels;
				case 19 :   *(p - edge) = color;
				case 18 :   *(p + edge) = color;   edge -= widthPixels;
				case 17 :   *(p - edge) = color;
				case 16 :   *(p + edge) = color;   edge -= widthPixels;
				case 15 :   *(p - edge) = color;
				case 14 :   *(p + edge) = color;   edge -= widthPixels;
				case 13 :   *(p - edge) = color;
				case 12 :   *(p + edge) = color;   edge -= widthPixels;
				case 11 :   *(p - edge) = color;
				case 10 :   *(p + edge) = color;   edge -= widthPixels;
				case  9 :   *(p - edge) = color;
				case  8 :   *(p + edge) = color;   edge -= widthPixels;
				case  7 :   *(p - edge) = color;
				case  6 :   *(p + edge) = color;   edge -= widthPixels;
				case  5 :   *(p - edge) = color;
				case  4 :   *(p + edge) = color;   edge -= widthPixels;
				case  3 :   *(p - edge) = color;
				case  2 :   *(p + edge) = color;
				case  1 :   *(p)        = color;
				case  0 :   ;
			}
		}
	}
	else
	{
		sdword fraction = dx - (dy >> 1);
		const sdword outerEdge = thickness >> 1;
		while( y0 != y1 )
		{
//			if( fraction >= 0 )
//			{
//				x0       += stepx;
//				fraction -= dy;
//			}
			const sdword fge0 = ~(fraction >> 31);
			x0       += fge0 & stepx;
			fraction -= fge0 & dy;
			y0       += stepy;
			fraction += dx;

			sbyte*  p    = pPixels + x0 + y0;
			sdword  edge = outerEdge;
			switch( thickness )
			{
				default :
				for( int i = thickness - 23;  true; )   /// only odd thickness > 23
				{
					*(p - edge) = color;
					*(p + edge) = color;   --edge;
					if( --i <= 0 )   break;
				}
				case 23 :   *(p - edge) = color;
				case 22 :   *(p + edge) = color;   --edge;
				case 21 :   *(p - edge) = color;
				case 20 :   *(p + edge) = color;   --edge;
				case 19 :   *(p - edge) = color;
				case 18 :   *(p + edge) = color;   --edge;
				case 17 :   *(p - edge) = color;
				case 16 :   *(p + edge) = color;   --edge;
				case 15 :   *(p - edge) = color;
				case 14 :   *(p + edge) = color;   --edge;
				case 13 :   *(p - edge) = color;
				case 12 :   *(p + edge) = color;   --edge;
				case 11 :   *(p - edge) = color;
				case 10 :   *(p + edge) = color;   --edge;
				case  9 :   *(p - edge) = color;
				case  8 :   *(p + edge) = color;   --edge;
				case  7 :   *(p - edge) = color;
				case  6 :   *(p + edge) = color;   --edge;
				case  5 :   *(p - edge) = color;
				case  4 :   *(p + edge) = color;   --edge;
				case  3 :   *(p - edge) = color;
				case  2 :   *(p + edge) = color;
				case  1 :   *(p)        = color;
				case  0 :   ;
			}
		}
	}
}*/


/*/// original java line drawers

public void lineFast(int x0, int y0, int x1, int y1, Color color)
{
	int pix = color.getRGB();
	int dy = y1 - y0;
	int dx = x1 - x0;
	int stepx, stepy;
	int width = raster.getWidth():
	int pixel = raster.getPixelBuffer();
	if (dy < 0)
	{
		dy = -dy;  stepy = -width;
	}
	else
	{
		stepy = -width;
	}
	if (dx < 0)
	{
		dx = -dx;  stepx = -1;
	}
	else
	{
		stepx = 1;
	}
	dy <<= 1;
	dx <<= 1;
	y0 *= width;
	y1 *= width;
	pixel[x0+y0] = pix;
	if (dx > dy)
	{
		int fraction = dy - (dx >> 1);
		while (x0 != x1)
		{
			if (fraction >= 0)
			{
				y0 += stepy;
				fraction -= dx;
			}
			x0 += stepx;
			fraction += dy;
			pixel[x0+y0] = pix;
		}
	}
	else
	{
		int fraction = dx - (dy >> 1);
		while (y0 != y1)
		{
			if (fraction >= 0)
			{
				x0 += stepx;
				fraction -= dy;
			}
			y0 += stepy;
			fraction += dx;
			pixel[x0+y0] = pix;
		}
	}
}


public void lineFast(int x0, int y0, int x1, int y1, Color color)
{
	int pix = color.getRGB();
	int dy = y1 - y0;
	int dx = x1 - x0;
	int stepy;
	if(dy < 0)
	{
		dy = -dy;
		stepy = -((Raster) (raster)).width;
	}
	else
	{
		stepy = ((Raster) (raster)).width;
	}
	int stepx;
	if(dx < 0)
	{
		dx = -dx;
		stepx = -1;
	}
	else
	{
		stepx = 1;
	}
	dy <<= 1;
	dx <<= 1;
	y0 *= ((Raster) (raster)).width;
	y1 *= ((Raster) (raster)).width;
	((Raster) (raster)).pixel[x0 + y0] = pix;
	if(dx > dy)
	{
		int fraction = dy - (dx >> 1);
		while(x0 != x1)
		{
			if(fraction >= 0)
			{
				y0 += stepy;
				fraction -= dx;
			}
			x0 += stepx;
			fraction += dy;
			((Raster) (raster)).pixel[x0 + y0] = pix;
		}
	} else
	{
		int fraction = dx - (dy >> 1);
		while(y0 != y1)
		{
			if(fraction >= 0)
			{
				x0 += stepx;
				fraction -= dy;
			}
			y0 += stepy;
			fraction += dx;
			((Raster) (raster)).pixel[x0 + y0] = pix;
		}
	}
}
*/
