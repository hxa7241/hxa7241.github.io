///  artifex@computer.org  |  2001-07-22  ///


#ifndef Cube_h
#define Cube_h


#include "Primitives.h"
#include <utility>




class Cube
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                Cube( sdword width, sdword height, sdword thickness, float framesPerSecond, sdword randSeed =0 );
	virtual        ~Cube();
	/// ---------------------------------------------------------


	/// adjust
	virtual void    set( sdword width, sdword height, sdword thickness );
	virtual void    notifyOfFrameRate( float framesPerSecond );

	/// update
	virtual void    updateAndDraw( sbyte color, sbyte image[] );


protected: //---------------------------------------------------------------------------------------
	/// update implementation
	static  void    polyPolyline( sbyte color, sdword thickness, sdword width, sbyte pixels[],
	                              const std::pair<sdword,sdword> polylineVerts[], const sdword polylines[], sdword noOfPolylines );

	static  void    drawLine( sdword x0, sdword y0, sdword x1, sdword y1, sbyte color, sdword thickness,
	                          sdword width, sdword height, sbyte pPixels[] );

	static  void    drawEndCaps( sdword x0, sdword y0, sdword x1, sdword y1,
	                             sbyte color, sdword thickness, sdword width, sbyte pPixels[] );
	static  void    drawEndCap( sdword xCenter, sdword yCenter,
	                            sbyte color, sdword thickness, sdword width, sbyte pPixels[] );


private: //-----------------------------------------------------------------------------------------
	/// constants
	static const float rotationIncXDflt_m;
	static const float rotationIncYDflt_m;
	static const float rotationIncZDflt_m;

	static const float unitVerticesX_m[ 8 ];
	static const float unitVerticesY_m[ 8 ];
	static const float unitVerticesZ_m[ 8 ];

	static const sdword noOfPolylines_m;
	static const sdword polylines_m[ 4 ];
	static const sdword pvIndexes_m[ 16 ];

	static const float unitPerspectiveness_m;
	static const float screenScaling_m;

	/// data
	        /// constant for each setting
	        sdword  width_m;
	        sdword  height_m;
	        sdword  thickness_m;

	        float   scaling_m;
	        float   enclosingRadius_m;
	        float   perspectiveness_m;

	        float   verticesX_m[ 8 ];
	        float   verticesY_m[ 8 ];
	        float   verticesZ_m[ 8 ];

			float   frameRateFactor_m;
	        float   rotationIncX_m;
	        float   rotationIncY_m;
	        float   rotationIncZ_m;

	        /// variable for each setting
	        float   rotationX_m;
	        float   rotationY_m;
	        float   rotationZ_m;

	        std::pair<sdword,sdword> screenXYs_m[ 8 ];
	        std::pair<sdword,sdword> polylineVerts_m[ 16 ];


	/// disallow
	                Cube( const Cube& );
	        Cube&   operator=( const Cube& );
};




#endif//Cube_h
