///  artifex@computer.org  |  2001-07-22  ///


#include "ImageGeneratorFire.h"

#include "Blurs.h"




/// statics
const sbyte ImageGeneratorFire::FIRE_RED[]   = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 17, 17, 18, 18, 19, 20, 20, 21, 22, 22, 23, 23, 24, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 32, 32, 33, 34, 34, 35, 36, 36, 37, 38, 38, 39, 40, 40, 41, 41, 42, 43, 43, 44, 44, 45, 46, 46, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 52, 52, 52, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 57, 58, 58, 58, 58, 59, 59, 59, 59, 59, 60, 60, 60, 60, 60, 60, 60, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62, 62 };
const sbyte ImageGeneratorFire::FIRE_GREEN[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 19, 20, 20, 21, 21, 21, 22, 22, 23, 23, 23, 24, 24, 25, 25, 26, 26, 26, 27, 27, 28, 28, 29, 29, 29, 30, 30, 31, 31, 32, 32, 32, 33, 33, 34, 34, 35, 35, 35, 36, 36, 37, 37, 37, 38, 38, 39, 39, 40, 40, 40, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 50, 51, 51, 51, 52, 52, 52, 52, 53, 53, 53, 53, 54, 54, 54, 54, 55, 55, 55, 55, 55, 56, 56, 56, 56, 56, 57, 57, 57, 57, 57, 57, 58, 58, 58, 58, 58, 58, 59, 59, 59, 59, 59, 59, 59, 59, 60, 60, 60, 60, 60, 60 };
const sbyte ImageGeneratorFire::FIRE_BLUE[]  = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11 };

const float ImageGeneratorFire::aspectRatio_m = 0.75f;




/// standard object services --------------------------------
ImageGeneratorFire::ImageGeneratorFire
(
	const sdword, //width,
	const sdword height,
	const sdword randSeed
)
	: stretching_m( 1 + ((height & 0xFFFFFFF8) / (maxHeight_m + 1)) ),
	  height_m( (height / stretching_m) & 0xFFFFFFF8 ),
	  width_m( (sdword( float(height_m) * aspectRatio_m ) + 0x07) & 0xFFFFFFF8 ),
	  flameMap1_m( width_m, height_m, true ),
	  flameMap2_m( width_m, height_m, true ),
	  cube_m( width_m, height_m, sdword((float(width_m) / cubeLineWidthDivisor_m) + 0.5f), 50.0f, randSeed ),
	  warp_m( width_m, height_m, flameResolution_m, randSeed ),
	  random_m( randSeed ),
	  frameCount_m( 0 )
{
	/// init palettes
	initPalettes( palette32_m, palette24_m, palette16_m );


//	/// set rendering stretch factor
//	{
//		/// find nearest integer stretch, max min 1 and 5
//		sdword stretching = sdword(height) / simulationHeight_m;
//		stretching = stretching < 1 ? 1 : ( stretching > 5 ? 5 : stretching );
//
//		stretching_m = stretching;
//
////		/// use if the non int stretching in writeColorGeneral is functional
////		const float aspectRatio = float(simulationWidth_m) / float(simulationHeight_m);   /// TEST ///
////		widthExternal_m  = sdword( float(height) * aspectRatio );
////		heightExternal_m = height;
//	}
}


ImageGeneratorFire::~ImageGeneratorFire()
{
}




/// init ///////////////////////////////////////////////////////////////////////////////////////////
void ImageGeneratorFire::initPalettes
(
	sdword palette32[],
	sdword palette24[],
	sdword palette16[]
)  /// static
{
	for( sdword i = 256;  i-- != 0; )
	{
		const sdword r = (sdword(FIRE_RED[ i ])   << 2) & 0xFF;
		const sdword g = (sdword(FIRE_GREEN[ i ]) << 2) & 0xFF;
		const sdword b = (sdword(FIRE_BLUE[ i ])  << 2) & 0xFF;

		palette32[ i ] = (0xFF000000) | (r << 16) | (g << 8) | b;
		palette24[ i ] = (0x00000000) | (r << 16) | (g << 8) | b;
		palette16[ i ] = ((r & 0xF8) << 7) | ((g & 0xF8) << 2) | ((b & 0xF8) >> 3);

//		/// TEST ///
//		/// straight ramp of gray
//		sdword t = i;//(i >> 1) + sdword(128);
//		//t = (i == 0) ? 0 : t;
//		palette32[ i ] = (0xFF000000) | (t << 16) | (t << 8) | t;
//		palette16[ i ] = ((t & 0xF8) << 7) | ((t & 0xF8) << 2) | ((t & 0xF8) >> 3);
//		//palette32[ i ] = (i <= 4 && i != 0) ? 0xFF00FF00 : palette32[ i ];
	}
}




/// access /////////////////////////////////////////////////////////////////////////////////////////
sdword ImageGeneratorFire::getWidth() const
{
	return width_m * stretching_m;
}


sdword ImageGeneratorFire::getHeight() const
{
	return height_m * stretching_m;
}


const sdword* ImageGeneratorFire::getPalette() const
{
	return palette32_m;
}


sdword ImageGeneratorFire::getSimulationWidth() const
{
	return width_m;
}


sdword ImageGeneratorFire::getSimulationHeight() const
{
	return height_m;
}




/// adjust /////////////////////////////////////////////////////////////////////////////////////////
bool ImageGeneratorFire::decreaseResolution
(
	const sdword width,
	const sdword height
)
{
	return changeResolution( width, height, stretching_m + 1 );
}


bool ImageGeneratorFire::increaseResolution
(
	const sdword width,
	const sdword height
)
{
	return changeResolution( width, height, stretching_m - 1 );
}


bool ImageGeneratorFire::changeResolution
(
	const sdword ,//width,
	const sdword height,
	const sdword stretching
)
{
	bool didChange = false;

	if( (stretching > 0) && (stretching != stretching_m) )
	{
		const sdword newHeight = (height / stretching) & 0xFFFFFFF8;
		if( (newHeight <= maxHeight_m) && (newHeight >= minHeight_m) )
		{
			height_m     = newHeight;
			width_m      = (sdword( float(height_m) * aspectRatio_m ) + 0x07) & 0xFFFFFFF8;
			stretching_m = stretching;

			/// resize flame maps, but copy to new to avoid discontinuity
			flameMap2_m = flameMap1_m;
			flameMap1_m.setSize( width_m, height_m );
			scalePixels( flameMap2_m.getWidth(), flameMap2_m.getHeight(), flameMap1_m.getWidth(), flameMap1_m.getHeight(),
						 flameMap2_m.getMemory(), flameMap1_m.getMemory() );
			flameMap2_m.setSize( width_m, height_m, true );

			cube_m.set( width_m, height_m, sdword((float(width_m) / cubeLineWidthDivisor_m) + 0.5f) );
			warp_m.setWarpMap( width_m, height_m, flameResolution_m );

			didChange = true;
		}
	}

	return didChange;
}


void ImageGeneratorFire::notifyOfFrameRate
(
	const sdword framesPerSecond
)
{
	cube_m.notifyOfFrameRate( float(framesPerSecond) );
	warp_m.notifyOfFrameRate( float(framesPerSecond) );
}




/// update /////////////////////////////////////////////////////////////////////////////////////////
void ImageGeneratorFire::drawNextFrame
(
	const sdword widthTarget,
	const sdword heightTarget,
	const sdword bitsPerPixel,
	void* image
)
{
	sbyte* pFlameMap1 = flameMap1_m.getMemory();
	sbyte* pFlameMap2 = flameMap2_m.getMemory();


	/// prepare warp
	warp_m.makeWarpMap( frameCount_m );

	/// warp
	warp_m.warpImage( width_m, height_m, pFlameMap1, pFlameMap2 );

	/// updraft
	updraft( flameResolution_m, width_m, height_m, pFlameMap2 );

	/// clear to draw cube onto
	sdword* p = reinterpret_cast<sdword*>( pFlameMap1 + (width_m * height_m) );
	for( sdword i = (width_m * height_m) >> 2;  i-- != 0; )
	{
		*(--p) = 0;
	}

	/// draw cube
	cube_m.updateAndDraw( sbyte(0xFF), pFlameMap1 );

	/// cool and heat
	coolAndHeat( coolRate_m, heatUneveness_m, random_m,
	             width_m, height_m, pFlameMap1, pFlameMap2, pFlameMap1 );

	/// spread
	/// (ought to have a parameterised blur here (blur width = width_m / spreadRadiusDivisor_m)
	/// - this is only ok up to the maxHeight_m of 600)
	if( width_m > 300 )
	{
		Blurs::gatherSquare5( 1, width_m, height_m, pFlameMap2, pFlameMap1 );
	}
	else
	{
		Blurs::gatherSquare3( 1, width_m, height_m, pFlameMap2, pFlameMap1 );
	}


	/// color
	writeColor( width_m, height_m, widthTarget, heightTarget, bitsPerPixel,
	            pFlameMap1, image );


	++frameCount_m;
}




/// update implementation //////////////////////////////////////////////////////////////////////////
void ImageGeneratorFire::updraft
(
	const sdword flameResolution,
	const sdword width,
	const sdword height,
	      sbyte  pixels[]
)
{
	/// (ought to be a parameterisable blur - but this works up to the maxHeight_m of 600)

	const sdword updraft = sdword( (float(height * 2) / float(flameResolution * 7)) + 0.5f + 0.4f);
	sdword* p  = reinterpret_cast<sdword*>( pixels );
	sdword* p1 = reinterpret_cast<sdword*>( pixels + (width * updraft) );
	sdword* p2 = reinterpret_cast<sdword*>( pixels + (width * (updraft >> 1)) );

	const sdword*const end = reinterpret_cast<sdword*>( pixels + (width * height) );
	for( ;  p1 < end;  )
	{
		*(p++) = ((*(p1++) >> 1) & 0x7F7F7F7F) + ((*(p2++) >> 1) & 0x7F7F7F7F);
	}
}


void ImageGeneratorFire::coolAndHeat
(
	const sdword coolRate,
	const sdword heatUneveness,
	      RandomFast& randSeries,
	const sdword width,
	const sdword height,
	const sbyte  heatMap[],
	const sbyte  pixelsIn[],
	      sbyte  pixelsOut[]
) /// static
{
	const dword*const quadHeatMap   = reinterpret_cast<const dword*>( heatMap );
	const dword*const quadPixelsIn  = reinterpret_cast<const dword*>( pixelsIn );
	      dword*const quadPixelsOut = reinterpret_cast<dword*>( pixelsOut );

	RandomFast random( randSeries );
	const dword pairCoolRate = (dword(coolRate) << 16) | dword(coolRate);
	const dword noiseMask    = (0x01010101u << heatUneveness) - 0x01010101u;

	for( sdword i = (width * height) >> 2;  i-- != 0; )
	{
		dword flame  = quadPixelsIn[ i ];
		dword flame1 = flame & 0x00FF00FFu;
		dword flame2 = (flame >> 8) & 0x00FF00FFu;

		/// cool
		flame1 -= pairCoolRate;
		flame2 -= pairCoolRate;
		flame1 &= ~flame1 >> 8;
		flame2 &= ~flame2 >> 8;

		flame = (flame1 & 0x00FF00FFu) | ((flame2 & 0x00FF00FFu) << 8);


		/// heat from image
		const dword heat  = quadHeatMap[ i ];
		const dword rand1 = dword(random.nextSdword());
		const dword rand2 = dword(random.nextSdword());
		const dword rand3 = dword(random.nextSdword());
		const dword rand4 = dword(random.nextSdword());
		const dword noise = ~( ( ((rand1 >> 24)) |
		                         ((rand2 & 0xFF000000u) >> 16) |
		                         ((rand3 & 0xFF000000u) >>  8) |
		                         ((rand4 & 0xFF000000u))  ) & noiseMask );
		//const dword noise = ~( ( (rand1 & 0xFF00FF00u) | ( (rand1 & 0xFF00FF00u) >> 8 ) ) & noiseMask );
//		const dword noise = ~( dword(random.nextSdword()) & noiseMask );   /// abuse of the random number generator, not sure it always looks as good
		flame |= (heat & noise);

		quadPixelsOut[ i ] = flame;
	}

	randSeries = random;
}


void ImageGeneratorFire::writeColor
(
    const sdword  widthFlame,
    const sdword  heightFlame,
    const sdword  widthImage,
    const sdword  heightImage,
    const sdword  bitsPerPixel,
    const sbyte   flameMap[],
          void*   image
)
{
	switch( bitsPerPixel )
	{
	case 32 :
		{
			writeColorGeneral( widthFlame, heightFlame, widthImage, heightImage,
			                   palette32_m, flameMap, reinterpret_cast<sdword*>( image ) );

			break;
		}
	case 24 :
		{
			writeColor24bit( widthFlame, heightFlame, widthImage, heightImage,
			                 palette24_m, flameMap, reinterpret_cast<sbyte*>( image ) );
			break;
		}
	case 16 :
		{
			writeColorGeneral( widthFlame, heightFlame, widthImage, heightImage,
			                   palette16_m, flameMap, reinterpret_cast<sword*>( image ) );

			break;
		}
	case  8 :
		{
			const bool didDo = writeColor8bit( widthFlame, heightFlame, widthImage, heightImage,
			                                   flameMap, reinterpret_cast<sbyte*>( image ) );

			if( !didDo )
			{
				writeColorGeneral( widthFlame, heightFlame, widthImage, heightImage,
				                   palette16_m, flameMap, reinterpret_cast<sbyte*>( image ) );
			}

			break;
		}
	}
}


/*
 * specialisation of writeColorGeneral to handle 24 bit color.
 * (3 byte format wont fit the template)
 */
void ImageGeneratorFire::writeColor24bit
(
	const sdword  widthFlame,
	const sdword  heightFlame,
	const sdword  widthImage,
	const sdword  heightImage,
	const sdword  palette[],
	const sbyte   flameMap[],
	      sbyte   image[]
)   /// static
{
	if( (widthFlame <= 0) | (heightFlame <= 0) | (widthImage <= 0) | (heightImage <= 0) )
		return;

	const sdword stretching = heightImage / heightFlame;

	switch( stretching )
	{
	case 4 :
		{
			const sdword widthImageAsDwords = ((widthImage * 3) >> 2);

			const sbyte* pFlame = flameMap + (widthFlame * heightFlame);
			sdword* pImage1 = reinterpret_cast<sdword*>(image) + (((widthImage * heightImage) * 3) >> 2);
			sdword* pImage2 = pImage1 - widthImageAsDwords;
			sdword* pImage3 = pImage2 - widthImageAsDwords;
			sdword* pImage4 = pImage3 - widthImageAsDwords;

			const sdword nextRow = (widthImageAsDwords << 1) + widthImageAsDwords;

			int row = heightFlame;
			do	{

				int column = widthFlame;
				do	{

					const sdword color  = palette[ byte(*(--pFlame)) ] & 0x00FFFFFF;
					const sdword color3 = (color <<  8) | (color >> 16);
					const sdword color2 = (color << 16) | (color >>  8);
					const sdword color1 = (color << 24) | (color >>  0);

					*(--pImage1) = color3;
					*(--pImage1) = color2;
					*(--pImage1) = color1;

					*(--pImage2) = color3;
					*(--pImage2) = color2;
					*(--pImage2) = color1;

					*(--pImage3) = color3;
					*(--pImage3) = color2;
					*(--pImage3) = color1;

					*(--pImage4) = color3;
					*(--pImage4) = color2;
					*(--pImage4) = color1;

				} while( --column > 0 );

				pImage1 -= nextRow;
				pImage2 -= nextRow;
				pImage3 -= nextRow;
				pImage4 -= nextRow;

			} while( --row > 0 );

			break;
		}
	default :
		{
			const sdword columnStep = (stretching * 3);
			const sdword lineBack   = (widthImage * 3) - ((stretching * 3) - 1);
			const sdword upRow      = (stretching - 1) * (widthImage * 3);

			const sbyte* pFlame = flameMap + (widthFlame * heightFlame);
			sbyte*       pImage = image + ((widthImage * heightImage) * 3);

			int row = heightFlame;
			do	{
				pImage -= upRow;

				int column = widthFlame;
				do	{
					pImage -= columnStep;
					--pFlame;

					const sdword color      = palette[ byte( *pFlame ) ];
					const sbyte  colorRed   = static_cast<sbyte>( dword(color) >> 16 );
					const sbyte  colorGreen = static_cast<sbyte>( dword(color) >> 8 );
					const sbyte  colorBlue  = static_cast<sbyte>( dword(color) );
					sbyte* pImageBlock = pImage;

					//if( !((*pImageBlock == colorBlue) & (*(pImageBlock+1) == colorGreen) & (*(pImageBlock+2) == colorRed)) )
					if( (*pImageBlock - colorBlue) | (*(pImageBlock+1) - colorGreen) | (*(pImageBlock+2) - colorRed) )
					{
						for( int y = stretching;  ; )
						{
							for( int x = stretching;  ; )
							{
								*pImageBlock     = colorBlue;
								*(++pImageBlock) = colorGreen;
								*(++pImageBlock) = colorRed;

								if( --x == 0 )
									break;

								++pImageBlock;
							}

							if( --y == 0 )
								break;

							pImageBlock += lineBack;
						}
					}
				} while( --column > 0 );

			} while( --row > 0 );

			break;
		}
	}
}


/*
 * specialisation of writeColorGeneral for accelerating 8bit color.
 * (handles images in 4 pixel chunks, simd style)
 *
 * @return false if the specialisation didnt act, and the general method should be used
 */
bool ImageGeneratorFire::writeColor8bit
(
    const sdword  widthFlame,
    const sdword  heightFlame,
    const sdword  widthImage,
    const sdword  heightImage,
    const sbyte   flameMap[],
          sbyte   image[]
)   /// static
{
	if( (widthFlame <= 0) | (heightFlame <= 0) | (widthImage <= 0) | (heightImage <= 0) )
		return false;

	const int stretching = heightImage / heightFlame;

	bool didDo = false;

	switch( stretching )
	{
	case 1 :
		{
			const sdword length = (widthFlame * heightFlame) >> 2;
			if( length != 0 )
			{
				int i = length >> 1;
				const sdword* pf = reinterpret_cast<const sdword*>( flameMap ) + length;
				      sdword* pi = reinterpret_cast<sdword*>( image ) + length;
				do {

					*(--pi) = *(--pf);
					*(--pi) = *(--pf);

				} while( --i > 0 );
			}

			didDo = true;
			break;
		}
	case 2 :
		{
			const sdword lineBack = (widthImage >> 2) - (stretching - 1);
			const sdword upRow    = (stretching - 1) * (widthImage >> 2);

			const sdword* pFlame = reinterpret_cast<const sdword*>(flameMap) + ((widthFlame >> 2) * heightFlame);
			sdword*       pImage = reinterpret_cast<sdword*>(image) + ((widthImage >> 2) * heightImage);

			int row = heightFlame;
			do	{
				pImage -= upRow;

				int column = widthFlame >> 2;
				do	{
					pImage -= stretching;

					const sdword color   = *(--pFlame);
					const dword  color3  = dword(color) & 0xFF000000u;
					const dword  color2  = dword(color) & 0x00FF0000u;
					const dword  color1  = dword(color) & 0x0000FF00u;
					const dword  color0  = dword(color) & 0x000000FFu;
					const sdword color32 = color3 | (color3 >> 8) | (color2 >> 8) | (color2 >> 16);
					const sdword color10 = (color1 << 16) | (color1 << 8) | (color0 << 8) | color0;

					sdword* pImageBlock = pImage;

					*(pImageBlock++) = color10;
					*pImageBlock     = color32;
					pImageBlock += lineBack;

					*(pImageBlock++) = color10;
					*pImageBlock     = color32;

				} while( --column > 0 );

			} while( --row > 0 );

			didDo = true;
			break;
		}
	case 3 :
		{
			const sdword lineBack = (widthImage >> 2) - (stretching - 1);
			const sdword upRow    = (stretching - 1) * (widthImage >> 2);

			const sdword* pFlame = reinterpret_cast<const sdword*>(flameMap) + ((widthFlame >> 2) * heightFlame);
			sdword*       pImage = reinterpret_cast<sdword*>(image) + ((widthImage >> 2) * heightImage);

			int row = heightFlame;
			do	{
				pImage -= upRow;

				int column = widthFlame >> 2;
				do	{
					pImage -= stretching;

					const sdword color   = *(--pFlame);
					const dword  color3  = dword(color) & 0xFF000000u;
					const dword  color2  = dword(color) & 0x00FF0000u;
					const dword  color1  = dword(color) & 0x0000FF00u;
					const dword  color0  = dword(color) & 0x000000FFu;
					const sdword color32 = color3 | (color3 >> 8) | (color3 >> 16) | (color2 >> 16);
					const sdword color21 = (color2 << 8) | color2 | color1 | (color1 >> 8);
					const sdword color10 = (color1 << 16) | (color0 << 16) | (color0 << 8) | color0;

					sdword* pImageBlock = pImage;

					*(pImageBlock++) = color10;
					*(pImageBlock++) = color21;
					*pImageBlock     = color32;
					pImageBlock += lineBack;

					*(pImageBlock++) = color10;
					*(pImageBlock++) = color21;
					*pImageBlock     = color32;
					pImageBlock += lineBack;

					*(pImageBlock++) = color10;
					*(pImageBlock++) = color21;
					*pImageBlock     = color32;

				} while( --column > 0 );

			} while( --row > 0 );

			didDo = true;
			break;
		}
	}

	return didDo;
}




/// decreaseResolution support /////////////////////////////////////////////////////////////////////
void ImageGeneratorFire::scalePixels
(
	const sdword widthSource,
	const sdword heightSource,
	const sdword widthTarget,
	const sdword heightTarget,
	const sbyte*const  pSource,
	      sbyte*const  pTarget
)
{
	const sdword posSourceRowInc   = -( (heightSource << 8) / heightTarget );
	const sdword posSourcePixelInc = -( (widthSource  << 8) / widthTarget  );

	sdword posSourceRow = heightSource << 8;
	sbyte* pTargetPixel = pTarget + (widthTarget * heightTarget);

	int y = heightTarget;
	do {
		posSourceRow += posSourceRowInc;

		sdword posSourcePixel = ((posSourceRow + 0x00000080) & 0xFFFFFF00) * widthSource;

		int x = widthTarget;
		do {
			--pTargetPixel;
			posSourcePixel += posSourcePixelInc;

			*pTargetPixel = pSource[ (posSourcePixel + 0x00000080) >> 8 ];

		} while( --x > 0 );

	} while( --y > 0 );
}
