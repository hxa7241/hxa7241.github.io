///  artifex@computer.org  |  2001-07-22  ///


#ifndef ImageGeneratorFire_h
#define ImageGeneratorFire_h


#include "Primitives.h"

#include "ImageGenerator.h"
#include "Sheet.h"
#include "Cube.h"
#include "Turbulence.h"
#include "RandomFast.h"




class ImageGeneratorFire
	: public ImageGenerator
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                 ImageGeneratorFire( sdword width, sdword height, sdword randSeed =0 );
	virtual         ~ImageGeneratorFire();
	/// ---------------------------------------------------------


	/// access
	virtual sdword        getWidth()       const;
	virtual sdword        getHeight()      const;
	virtual const sdword* getPalette()     const;

	virtual sdword   getSimulationWidth()  const;
	virtual sdword   getSimulationHeight() const;

	/// adjust
	virtual bool     decreaseResolution( sdword width, sdword height );
	virtual bool     increaseResolution( sdword width, sdword height );
	virtual bool     changeResolution( sdword width, sdword height, sdword stretching );
	virtual void     notifyOfFrameRate( sdword framesPerSecond );

	/// update
	virtual void     drawNextFrame( sdword width, sdword height, sdword bitsPerPixel, void* image );


protected: //---------------------------------------------------------------------------------------
	/// init
	static  void     initPalettes( sdword palette32[], sdword palette24[], sdword palette16[] );

	/// update implementation
	static  void     updraft( sdword flameResolution, sdword width, sdword height, sbyte pixels[] );
	static  void     coolAndHeat( sdword coolRate, sdword heatUneveness, RandomFast& random,
	                              sdword width, sdword height,
	                              const sbyte heatMap[], const sbyte pixelsIn[], sbyte pixelsOut[] );
	        void     writeColor( sdword widthFlame, sdword heightFlame,
	                             sdword widthImage, sdword heightImage, sdword bitsPerPixel,
	                             const sbyte flameMap[], void* image );
	static  template<class COLORMODE>  void  writeColorGeneral(
	                             sdword widthFlame, sdword heightFlame, sdword widthImage, sdword heightImage,
	                             const sdword palette[], const sbyte flameMap[], COLORMODE image[] );
	static  template<class COLORMODE>  COLORMODE getColor( const sdword palette[], const sbyte* pFlame );

	static  void     writeColor24bit( sdword widthFlame, sdword heightFlame, sdword widthImage, sdword heightImage,
	                                  const sdword palette[], const sbyte flameMap[], sbyte image[] );
	static  bool     writeColor8bit ( sdword widthFlame, sdword heightFlame, sdword widthImage, sdword heightImage,
	                                  const sbyte flameMap[], sbyte image[] );

	/// changeResolution support
	static  void     scalePixels( sdword widthSource, sdword heightSource, sdword widthTarget, sdword heightTarget,
	                              const sbyte* pSource, sbyte* pTarget );


private: //-----------------------------------------------------------------------------------------
	/// palette constants
	static const sbyte    FIRE_RED[];
	static const sbyte    FIRE_GREEN[];
	static const sbyte    FIRE_BLUE[];

	/// palette
	        sdword        palette32_m[ 256 ];
	        sdword        palette24_m[ 256 ];
	        sdword        palette16_m[ 256 ];

	/// fire control parameters
	static const sdword   flameResolution_m           = 24;   /// flame features per image width
	static const sdword   spreadRadiusDivisor_m       = 96;   /// divide the width by this to get the spread radius
	static const sdword   cubeLineWidthDivisor_m      = 36;   /// divide the width by this to get the line width
	static const sdword   coolRate_m                  =  8;   /// 0 - 255
	static const sdword   heatUneveness_m             =  7;   /// 0 - 8

	/// simulation and image size
	//static const int simulationWidth_m  = 288;//576;//192;//288;//   /// must both be multiples of 8
	//static const int simulationHeight_m = 384;//768;//256;//384;//
	static const sdword maxHeight_m     = 600;
	static const sdword minHeight_m     = 136;
	static const float  aspectRatio_m;
	        sdword        stretching_m;
	        sdword        height_m;    /// must both be multiples of 8
	        sdword        width_m;     ///

	/// fire temperature maps
	        Sheet<sbyte>  flameMap1_m;
	        Sheet<sbyte>  flameMap2_m;

	/// simulation parts
	        Cube          cube_m;
	        Turbulence    warp_m;

	/// util
	        RandomFast    random_m;
	        sdword        frameCount_m;


	/// disallow
	                    ImageGeneratorFire( const ImageGeneratorFire& );
	ImageGeneratorFire& operator=( const ImageGeneratorFire& );

};








/// TEMPLATE MEMBERS ///

template<class COLORMODE>
void ImageGeneratorFire::writeColorGeneral
(
	const sdword  widthFlame,
	const sdword  heightFlame,
	const sdword  widthImage,
	const sdword  heightImage,
	const sdword  palette[],
	const sbyte   flameMap[],
	COLORMODE     image[]
)   /// static
{
	if( (widthFlame <= 0) | (heightFlame <= 0) | (widthImage <= 0) | (heightImage <= 0) )
		return;


	const sdword stretching = heightImage / heightFlame;
	const sdword lineBack   = widthImage - (stretching - 1);
	const sdword upRow      = (stretching - 1) * widthImage;

	const sbyte* pFlame = flameMap + (widthFlame * heightFlame);
	COLORMODE*   pImage = image + (widthImage * heightImage);

	int row = heightFlame;
	do	{
		pImage -= upRow;

		int column = widthFlame;
		do	{
			pImage -= stretching;
			--pFlame;

			const COLORMODE color  = getColor<COLORMODE>( palette, pFlame );
			COLORMODE* pImageBlock = pImage;

			if( color != *pImageBlock )
			{
				for( int y = stretching;  ; )
				{
					for( int x = stretching;  ; )
					{
						*pImageBlock = color;

						if( --x == 0 )
							break;

						++pImageBlock;
					}

					if( --y == 0 )
						break;

					pImageBlock += lineBack;
				}
			}
		} while( --column > 0 );

	} while( --row > 0 );



	/*/// non integer stretching version
	const sdword ratio        = (heightImage << 16) / heightFlame;
	const sdword stretching   = ratio >> 16;
	const sdword subPixelStep = ratio & 0xFFFF;

	const sbyte* pFlame = flameMap + (widthFlame * heightFlame);
	COLORMODE*   pImage = image + (widthImage * heightImage);

	for( sdword row = heightFlame, subPixelPosY = 0;  row-- > 0; )
	{
		subPixelPosY += subPixelStep;
		const sdword extraRow = subPixelPosY >> 16;
		subPixelPosY &= 0xFFFF;

		const sdword stretchingY = stretching + extraRow;
		const sdword upRow       = (stretchingY - 1) * widthImage;

		pImage -= upRow;

		for( sdword column = widthFlame, subPixelPosX = 0;  column-- > 0; )
		{
			subPixelPosX += subPixelStep;
			const sdword extraColumn = subPixelPosX >> 16;
			subPixelPosX &= 0xFFFF;

			const sdword stretchingX = stretching + extraColumn;
			const sdword lineBack    = widthImage - (stretchingX - 1);

			pImage -= stretchingX;
			--pFlame;

			const COLORMODE color  = getColor<COLORMODE>( palette, pFlame );
			COLORMODE* pImageBlock = pImage;

			if( color != *pImageBlock )
			{
				for( int y = stretchingY;  true; )
				{
					for( int x = stretchingX;  true; )
					{
						*pImageBlock = color;

						if( --x == 0 )   break;

						++pImageBlock;
					}

					if( --y == 0 )   break;

					pImageBlock += lineBack;
				}
			}
		}
	}*/
}


template<class COLORMODE>
inline
COLORMODE ImageGeneratorFire::getColor
(
	const sdword  palette[],
	const sbyte*  pFlame
)
{
	return  COLORMODE( palette[ byte( *pFlame ) ] );
}


template<>
inline
sbyte ImageGeneratorFire::getColor<sbyte>
(
	const sdword  [],
	const sbyte*  pFlame
)
{
	return  *pFlame;
}




#endif//ImageGeneratorFire_h
