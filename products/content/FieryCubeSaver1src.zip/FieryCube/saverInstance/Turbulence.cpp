///  artifex@computer.org  |  2001-07-22  ///


#include "Turbulence.h"

#include "Blurs.h"

#include "FpToInt.h"
#include "stdwin.h"
//#include <fstream>   /// TEST ///




/// standard object services //////////////////////////////////////////////////////////////////////
Turbulence::Turbulence
(
	const sdword width,
	const sdword height,
	const sdword resolution,
	const sdword randSeed
)
	: random_m( randSeed )
{
	Turbulence::setWarpMap( width, height, resolution );
}


Turbulence::~Turbulence()
{
}




////////////////////////////////////////////////////////////////////////////////////////////////////
void Turbulence::setWarpMap
(
	const sdword widthImage,
	const sdword heightImage,
	const sdword resolution
)
{
	/// set params
	width_m                 = resolution > 1 ? resolution : 1;
	height_m                = sdword( (double(heightImage) / double(widthImage)) * double(width_m) );
	interpolationFraction_m = 2;
	//updraftSpeed1616_m      = sdword( (float((heightImage << 16) * 2) / float(resolution * 7)) + 0.5f );

	const double strengthX  = (double(widthImage) / double(width_m)) / 2.0;
	const double strengthY  = strengthX * 2.0;


	/// set maps size
	warpMapX_m.setSize( width_m, height_m, true );
	warpMapY_m.setSize( width_m, height_m, true );
	warp_m.setSize( width_m, height_m, true );
	//warpMapX_m.setSize( width_m, height_m, true );
	//warpMapY_m.setSize( width_m, height_m, true );
	//interpolatedWarpX_m.setSize( width_m, height_m, true );
	//interpolatedWarpY_m.setSize( width_m, height_m, true );
	//warpIncrementX_m.setSize( width_m, height_m, true );
	//warpIncrementY_m.setSize( width_m, height_m, true );


	/// dot with noise
	const sdword length = width_m * height_m;
	for( sdword i = length /4;  i-- > 0; )
	{
		const sdword indx1 = (random_m.nextSdword() & sdword(0x7FFFFFFF)) % length;
		warpMapX_m.getMemory()[ indx1 ] = sdword(((random_m.nextFloat() * 2.0f) - 1.0f) * strengthX * 65536.0) + 0x00010000;
		warpMapY_m.getMemory()[ indx1 ] = sdword(((random_m.nextFloat() * 2.0f) - 1.0f) * strengthY * 65536.0) + 0x00010000;
	}
}






void Turbulence::notifyOfFrameRate
(
	const float framesPerSecond
)
{
	const float  temp = (framesPerSecond / 7.5f);
	const sdword log2 = ((*(reinterpret_cast<const sdword*>( &temp )) >> 23) & 0xFF) - 127;

	interpolationFraction_m = (log2 > 1 ? log2 : 1);
}


void Turbulence::makeWarpMap( const sdword frameCount )
{
	/// only every few frames
	if( ( frameCount & ((1 << interpolationFraction_m) -1) ) == 0 )
	{
		const sdword length = width_m * height_m;

		/// pick new position for warp maps
		const sdword offset = (random_m.nextSdword() & sdword(0x7FFFFFFF)) % length;

		/// set warp increments to new position vals minus current vals
		sdword pos = length - offset - 1;
		for( sdword i = length;  i-- != 0; )
		{
			//warpIncrementX_m[ i ] = warpMapX_m[ pos ] - (interpolatedWarpX_m[ i ] >> interpolationFraction_m);
			//warpIncrementY_m[ i ] = warpMapY_m[ pos ] - (interpolatedWarpY_m[ i ] >> interpolationFraction_m);

			WarpThings& warp = warp_m.getMemory()[ i ];
			warp.incrementX = warpMapX_m[ pos ] - (warp.interpolatedX >> interpolationFraction_m);
			warp.incrementY = warpMapY_m[ pos ] - (warp.interpolatedY >> interpolationFraction_m);

			const sdword bt = (pos == 0) - sdword(1);
			const sdword bf = ~bt;
			pos = (bt & (pos-1)) | (bf & (length-1));
			//pos = (pos != 0) ? pos-1 : length-1;
		}
	}
}


/*
 * misses out the pixels at the bottom, - the piece thats not a whole warp block size in height thats left over
 *
 * looks complicated - and thats because it is. but its much faster than the original simple version...
 */
void Turbulence::warpImage
(
	const sdword width,
	const sdword height,
	const sbyte  pixelsIn[],
	      sbyte  pixelsOut[]
)
{
//static int  function = 0;
//static DWORD timesum = 0;
//
//DWORD time1 = 0;
//
//if( function < 100 )
//{
//	LARGE_INTEGER count;
//	::QueryPerformanceCounter( &count );
//	time1 = count.LowPart;
//}


//if( function > 0 ) {
//for( int i = width * height;  i-- > 0; )
//{
//	pixelsOut[ i ] = pixelsIn[ i ];
//}
//return; }

//std::ofstream log( "log.txt" );


	const sdword widthWarp     = width_m;
	const sdword heightWarp    = height_m;
	const sdword width1616     = width  << 16;
	const sdword height1616    = height << 16;
	const sdword blockSize1616 = (width << 16) / widthWarp;//8;//gridResolution_m;

//log << "width: " << width << "  height: " << height << "  widthWarp: " << widthWarp << "  heightWarp: " << heightWarp << "  updraft: " << (float(updraftSpeed1616_m) / 65536.0f) << "  blockSize1616: " << (float(blockSize1616) / 65536.0f) << "\n";

	/// set to last row end
	const WarpThings* pWarpUpper = warp_m.getMemory() + (widthWarp * heightWarp);
	const WarpThings* pWarpLower = warp_m.getMemory() + widthWarp;
	sdword inPosX;// = width1616;
	sdword inPosY = heightWarp * blockSize1616;//height1616;

	/// do blocks, bottom row to top row
	for( int row = heightWarp;  true; )
	{
//log << "\nstart row " << row << "\n";

		const sdword previousInPosY = inPosY;

		inPosX  = width1616;
		inPosY -= blockSize1616;

		const sdword inPosXInt     = (inPosX + 0x8000) & 0xFFFF0000;
		const sdword inPosYInt     = (inPosY + 0x8000) & 0xFFFF0000;
		const sdword blockSizeIntY = (((previousInPosY + 0x8000) & 0xFFFF0000) - inPosYInt) >> 16;

//log << "inPosX: " << (float(inPosX) / 65536.0f) << "  inPosY: " << (float(inPosY) / 65536.0f) <<
//"  pWarpUpper: " << (int)(pWarpUpper - warp_m.getMemory()) << "  pWarpLower: " << (int)(pWarpLower - warp_m.getMemory()) << "\n";

		/// calculate absolute corner positions
		sdword rghtTopX = ((pWarpUpper - widthWarp)->interpolatedX >> interpolationFraction_m) + inPosXInt;
		sdword rghtTopY = ((pWarpUpper - widthWarp)->interpolatedY >> interpolationFraction_m) + inPosYInt;// + updraftSpeed1616_m;
		sdword rghtBotX = ((pWarpLower - widthWarp)->interpolatedX >> interpolationFraction_m) + inPosXInt;
		sdword rghtBotY = ((pWarpLower - widthWarp)->interpolatedY >> interpolationFraction_m) + inPosYInt + (blockSizeIntY << 16);// + updraftSpeed1616_m;

		/// clamp corner positions
		rghtTopX &= ~(rghtTopX >> 31);
		rghtTopX += ((width1616  - rghtTopX) >> 31) & ((width1616  - rghtTopX) - 1);
		rghtTopY &= ~(rghtTopY >> 31);
		rghtTopY += ((height1616 - rghtTopY) >> 31) & ((height1616 - rghtTopY) - 1);
		rghtBotX &= ~(rghtBotX >> 31);
		rghtBotX += ((width1616  - rghtBotX) >> 31) & ((width1616  - rghtBotX) - 1);
		rghtBotY &= ~(rghtBotY >> 31);
		rghtBotY += ((height1616 - rghtBotY) >> 31) & ((height1616 - rghtBotY) - 1);

		/// do row of blocks, right to left
		for( int column = widthWarp;  true; )
		{
//log << "\n\t" << "start column: " << column << "\n";
			const sdword previousInPosX = inPosX;

			--pWarpUpper;
			--pWarpLower;
			inPosX -= blockSize1616;

			const sdword inPosXInt     = (inPosX + 0x8000) & 0xFFFF0000;
			const sdword blockSizeIntX = (((previousInPosX + 0x8000) & 0xFFFF0000) - inPosXInt) >> 16;

//log << "\t" << "inPosX: " << (float(inPosX) / 65536.0f) << "  inPosY: " << (float(inPosY) / 65536.0f) <<
//"  pWarpUpper: " << (int)(pWarpUpper - warp_m.getMemory()) << "  pWarpLower: " << (int)(pWarpLower - warp_m.getMemory()) << "\n";
//log << "\t" << "blockSizeIntX: " << blockSizeIntX << "  blockSizeIntY: " << blockSizeIntY << "\n";

			/// calculate absolute corner positions
			sdword leftTopX = (pWarpUpper->interpolatedX >> interpolationFraction_m) + inPosXInt;
			sdword leftTopY = (pWarpUpper->interpolatedY >> interpolationFraction_m) + inPosYInt;// + updraftSpeed1616_m;
			sdword leftBotX = (pWarpLower->interpolatedX >> interpolationFraction_m) + inPosXInt;
			sdword leftBotY = (pWarpLower->interpolatedY >> interpolationFraction_m) + inPosYInt + (blockSizeIntY << 16);// + updraftSpeed1616_m;

//log << "\t" << "leftTop: " << (float(leftTopX) / 65536.0f) << " " << (float(leftTopY) / 65536.0f) << "\t";
//log << "\t" << "rghtTop: " << (float(rghtTopX) / 65536.0f) << " " << (float(rghtTopY) / 65536.0f) << "\n";
//log << "\t" << "leftBot: " << (float(leftBotX) / 65536.0f) << " " << (float(leftBotY) / 65536.0f) << "\t";
//log << "\t" << "rghtBot: " << (float(rghtBotX) / 65536.0f) << " " << (float(rghtBotY) / 65536.0f) << "\n";

			/// clamp corner positions
			leftTopX &= ~(leftTopX >> 31);
			leftTopX += ((width1616  - leftTopX) >> 31) & ((width1616  - leftTopX) - 1);
			leftTopY &= ~(leftTopY >> 31);
			leftTopY += ((height1616 - leftTopY) >> 31) & ((height1616 - leftTopY) - 1);
			leftBotX &= ~(leftBotX >> 31);
			leftBotX += ((width1616  - leftBotX) >> 31) & ((width1616  - leftBotX) - 1);
			leftBotY &= ~(leftBotY >> 31);
			leftBotY += ((height1616 - leftBotY) >> 31) & ((height1616 - leftBotY) - 1);

			/// calc edge gradient increments
			const sdword incTopX  = (rghtTopX - leftTopX) / blockSizeIntX;
			const sdword incTopY  = (rghtTopY - leftTopY) / blockSizeIntX;
			//const sdword incBotX  = (rghtBotX - leftBotX) / blockSizeIntX;
			//const sdword incBotY  = (rghtBotY - leftBotY) / blockSizeIntX;
			const sdword incLeftX = (leftBotX - leftTopX) / blockSizeIntY;
			const sdword incLeftY = (leftBotY - leftTopY) / blockSizeIntY;
			const sdword incRghtX = (rghtBotX - rghtTopX) / blockSizeIntY;
			const sdword incRghtY = (rghtBotY - rghtTopY) / blockSizeIntY;

//log << "\t" << "incTop:  " << (float(incTopX ) / 65536.0f) << " " << (float(incTopY ) / 65536.0f) << "\n";
//log << "\t" << "incLeft: " << (float(incLeftX) / 65536.0f) << " " << (float(incLeftY) / 65536.0f) << "\n";
//log << "\t" << "incRght: " << (float(incRghtX) / 65536.0f) << " " << (float(incRghtY) / 65536.0f) << "\n";

			/// prepare block interpolation variables
			const sdword incIncX      = (incRghtX - incLeftX) / blockSizeIntX;
			const sdword incIncY      = (incRghtY - incLeftY) / blockSizeIntX;
			const sdword pOutNextLine = width - (blockSizeIntX - 1);
			sdword incX = incTopX;
			sdword incY = incTopY;
			sdword posX = leftTopX;
			sdword posY = leftTopY;
			sbyte* pOut = pixelsOut + (inPosXInt >> 16) + ((inPosYInt >> 16) * width);

//log << "\t" << "incIncX: " << (float(incIncX) / 65536.0f) << "  pOutNextLine: " << pOutNextLine << "\n";
//log << "\t" << "incIncY: " << (float(incIncY) / 65536.0f) << "\n";

			/// ( pOutNextLine, incLeftX, incLeftY, incIncX, incIncY; pixelsIn, width, pOut, posX, posY, incX, incY )
			/// interpolate block, doing horizontal lines top to bottom
			for( int j = blockSizeIntY;  true; )
			{
				const sdword lineStartPosX = posX;
				const sdword lineStartPosY = posY;

//log << "\t\t" << "---\n";
//log << "\t\t";
				/// ( pixelsIn, width, pOut, posX, posY, incX, incY )
				/// interpolate horizontal line, doing texels left to right
				/// (fall-through)
				switch( blockSizeIntX )
				{
				default :
					for( int i = blockSizeIntX - 8;  true; )
					//for( int i = blockSizeIntX - 1;  true; )
					{
						/// warp pixel into new position
						//*pOut = pixelsIn[ ((posX + 0x00008000) >> 16) + (((posY + 0x00008000) >> 16) * width) ];
						*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
////log << "xy: " << ((posX ) >> 16) << " " << ((posY ) >> 16) << "  idx: " << (((posX ) >> 16) + (((posY ) >> 16) * width)) << "  ";
////log << "  xy: " << (pOut - pixelsOut) - (((pOut - pixelsOut)/width) * width) << " " << (pOut - pixelsOut)/width << "  pOut: " << (pOut - pixelsOut) << "  |  ";
//log << "xy: " << ((posX ) >> 16) << " " << ((posY ) >> 16) << "  |  ";
//if( (((pOut - pixelsOut) - (((pOut - pixelsOut)/width) * width)) != ((posX) >> 16)) || (((pOut - pixelsOut)/width) != ((posY) >> 16)) || ((pOut - pixelsOut) != (((posX ) >> 16) + (((posY ) >> 16) * width))) )
//log << " fail ";
						/// move pixels positions along line
						++pOut;
						posX += incX;
						posY += incY;

						if( --i <= 0 )   break;
					}
				case 8 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 7 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 6 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 5 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 4 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 3 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 2 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
					++pOut;   posX += incX;   posY += incY;
				case 1 :
					*pOut = pixelsIn[ (posX >> 16) + ((posY >> 16) * width) ];
//log << "xy: " << ((posX ) >> 16) << " " << ((posY ) >> 16) << "  |  ";
//if( (((pOut - pixelsOut) - (((pOut - pixelsOut)/width) * width)) != ((posX) >> 16)) || (((pOut - pixelsOut)/width) != ((posY) >> 16)) || ((pOut - pixelsOut) != (((posX ) >> 16) + (((posY ) >> 16) * width))) )
//log << " fail ";
//log << "\n";
				case 0 : ;
				}

				/// check loop end here to avoid incrementing last time thru
				if( --j <= 0 )   break;

				/// move pixel positions back to next line start
				pOut += pOutNextLine;
				posX  = lineStartPosX + incLeftX;
				posY  = lineStartPosY + incLeftY;

				/// make new increments
				incX += incIncX;
				incY += incIncY;
			}

			if( --column <= 0 )   break;

			///
			rghtTopX = leftTopX;
			rghtTopY = leftTopY;
			rghtBotX = leftBotX;
			rghtBotY = leftBotY;
		}

		if( --row <= 0 )   break;

		pWarpLower = pWarpUpper + widthWarp;
	}


	/// increment interpolated warp pixels
	WarpThings* pW = warp_m.getMemory() + (widthWarp * heightWarp);
	for( sdword i = widthWarp * heightWarp;  i-- > 0; )
	{
		--pW;
		pW->interpolatedX += pW->incrementX;
		pW->interpolatedY += pW->incrementY;
	}


//if( function < 100 )
//{
//	LARGE_INTEGER count;
//	::QueryPerformanceCounter( &count );
//	DWORD elapsed = count.LowPart - time1;
//	timesum += elapsed;
//
//	if( function == 99 )
//	{
//		std::ofstream log( "log.txt" );
//		log << "ave time: " << ( timesum / 100 ) << "\n";
//	}
//}
//++function;
}


/*void Turbulence::warpImage
(
	const sdword width,
	const sdword height,
	const sdword pixelsIn[],
	      sdword pixelsOut[]
)
{
	for( sdword i = width * height;  i-- != 0; )
	{
		/// add incrs to currents
		//const sdword currentX = interpolatedWarpX_m[ i ];
		//const sdword currentY = interpolatedWarpY_m[ i ];
		//interpolatedWarpX_m[ i ] += warpIncrementX_m[ i ];
		//interpolatedWarpY_m[ i ] += warpIncrementY_m[ i ];
		WarpThings& warp = warp_m.getMemory()[ i ];
		const sdword currentX = warp.interpolatedX;
		const sdword currentY = warp.interpolatedY;
		warp.interpolatedX += warp.incrementX;
		warp.interpolatedY += warp.incrementY;

		/// >> vals from currents
		sdword warpX = ((currentX >> interpolationFraction_m) + 0x00008000) >> 16;
		sdword warpY = ((currentY >> interpolationFraction_m) + 0x00008000) >> 16;

		/// bias upwards
		warpY += updraftSpeed_m;

		/// derive index from shifted vals
		sdword warpedIndex = i + warpX + (warpY * width_m);

		/// clamp roughly
		warpedIndex &= ~(warpedIndex >> 31);   /// clamp to 0 min
		const sdword end    = (width_m * height_m) - 1;
		const sdword maxCmp = (warpedIndex - (end + 1)) >> 31;
		warpedIndex = (warpedIndex & maxCmp) | (end & ~maxCmp);   /// clamp to max
		//warpedIndex = (warpedIndex < 0)   ? 0   : warpedIndex;
		//warpedIndex = (warpedIndex > end) ? end : warpedIndex;

		/// warp pixel into new position
		pixelsOut[ i ] = pixelsIn[ warpedIndex ];
	}
}*/
