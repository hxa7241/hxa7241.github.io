///  artifex@computer.org  |  2001-07-22  ///


#ifndef Turbulence_h
#define Turbulence_h


#include "Primitives.h"

#include "Sheet.h"
#include "RandomFast.h"




class Turbulence
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                Turbulence( sdword width, sdword height, sdword resolution, sdword randSeed =0 );
	virtual        ~Turbulence();
	/// ---------------------------------------------------------


	        void    setWarpMap( sdword width, sdword height, sdword resolution );
	        void    notifyOfFrameRate( float framesPerSecond );

	        void    makeWarpMap( sdword frameCount );
	        void    warpImage( sdword width, sdword height, const sbyte  pixelsIn[], sbyte  pixelsOut[] );


protected: //---------------------------------------------------------------------------------------


private: //-----------------------------------------------------------------------------------------
	/// fields
	        RandomFast    random_m;

	        sdword        width_m;
	        sdword        height_m;

	        sdword        interpolationFraction_m;
	        //sdword        updraftSpeed1616_m;   /// now done separately from this warp class

	struct WarpThings
	{
		WarpThings() : interpolatedX(0), interpolatedY(0), incrementX(0), incrementY(0) {}
		sdword interpolatedX;
		sdword interpolatedY;
		sdword incrementX;
		sdword incrementY;
	};
	        Sheet<sdword>     warpMapX_m;
	        Sheet<sdword>     warpMapY_m;
	        Sheet<WarpThings> warp_m;

	        /*Sheet<sdword> warpMapX_m;
	        Sheet<sdword> warpMapY_m;
	        Sheet<sdword> interpolatedWarpX_m;
	        Sheet<sdword> interpolatedWarpY_m;
	        Sheet<sdword> warpIncrementX_m;
	        Sheet<sdword> warpIncrementY_m;*/


	/// disallow
	                Turbulence( const Turbulence& );
	        Turbulence& operator=( const Turbulence& );
};




#endif//Turbulence_h
