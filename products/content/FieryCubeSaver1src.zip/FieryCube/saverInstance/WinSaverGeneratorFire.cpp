///  artifex@computer.org  |  2001-07-22  ///


#include "WinSaverGeneratorFire.h"

#include <stdio>
//#include <fstream>   /// TEST ///




/// standard object services //////////////////////////////////////////////////////////////////////
WinSaverGeneratorFire::WinSaverGeneratorFire
(
	HDC frontDc,
	const sdword width,
	const sdword height
)
	: WinSaverGenerator<ImageGeneratorFire>( frontDc, width, height ),
	  frameCount_m( 0 ),
	  framesPerSecondLast_m( 0.0 ),
	  framesPerSecondAverage_m( 0.0 )
{
}


WinSaverGeneratorFire::~WinSaverGeneratorFire()
{
}




/// update /////////////////////////////////////////////////////////////////////////////////////////
bool WinSaverGeneratorFire::drawFrame
(
	HDC screenDC,
	const sdword width,
	const sdword height,
	const char   keyPress
)
{
	bool handledKeyPress = false;


	/// do frame rate things
	updateFrameRate();

	controlFrameRate( screenDC, width, height );


	/// draw some background things
	if( (width > 0) && (height > 0) )
	{
		drawNameCheck( screenDC, width, height );

		handledKeyPress |= drawInfo( screenDC, frameCount_m, framesPerSecondLast_m, framesPerSecondAverage_m,
		                             width, height, pBackBuffer_m->getWinDib()->getBitsPerPixel(),
		                             generator_m.getSimulationWidth(), generator_m.getSimulationHeight(), keyPress );
	}


	/// some key press handling
	handledKeyPress |= manuallyChangeResolution( screenDC, width, height, keyPress );


	/// call base
	const bool shouldContinue = WinSaverGenerator<ImageGeneratorFire>::drawFrame( screenDC, width, height, keyPress );

	return shouldContinue || handledKeyPress;
}


void WinSaverGeneratorFire::drawNameCheck
(
	HDC screenDC,
	const sdword,
	const sdword height
) /// static
{
	static bool done = false;
	if( !done )
	{
		LPTSTR pByline   = "www.hxa7241.org";
		const DWORD size = 15;

		HFONT font = ::CreateFont( (height / 48), 0, 900, 0, 0,
		                           false, false, false,
		                           DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		                           VARIABLE_PITCH | FF_SWISS, "verdana" );
		HFONT dfltFont = static_cast<HFONT>( ::SelectObject( screenDC, font ) );
		::SetBkColor( screenDC, COLORREF( 0x00000000 ) );
		::SetTextColor( screenDC, COLORREF( 0x004F4F4F ) );

		::TextOut( screenDC, (height / 48), height-(height/24), pByline, size );

		::DeleteObject( ::SelectObject( screenDC, dfltFont ) );
	}
	done = true;
}


bool WinSaverGeneratorFire::drawInfo
(
	HDC screenDC,
	const sdword frameCount,
	const double fpsLast,
	const double fpsAverage,
	const sdword width,
	const sdword height,
	const sdword bitsPerPixel,
	const sdword simWidth,
	const sdword simHeight,
	const char   keyPress
) /// static
{
	static bool keyToggle     = false;
	static bool lastKeyToggle = false;

	bool handledKeyPress = false;

	if( (keyPress == 'f') || (keyPress == 'F') )
	{
		keyToggle = !keyToggle;

		handledKeyPress = true;
	}

	const bool justToggledOff = !keyToggle && lastKeyToggle;
	if( keyToggle || justToggledOff )
	{
		char pLastFrameRate[ 18 ];
		char pAveFrameRate[ 18 ];
		char pFrameCount[ 18 ];
		char pSimulationDims[ 18 ];
		char pImageDims[ 18 ];
		const int lastFrameRateLen = std::sprintf( pLastFrameRate,  "%.3f f/s ",     fpsLast );
		const int aveFrameRateLen  = std::sprintf( pAveFrameRate,   "%.3f f/s ave ", fpsAverage );
		const int frameCountLen    = std::sprintf( pFrameCount,     "%u f ",         frameCount );
		const int simDimsLen       = std::sprintf( pSimulationDims, "%u %u (1/%u) ", simWidth, simHeight, sdword( (float(height) / float(simHeight)) + 0.5f ) );
		const int imageDimsLen     = std::sprintf( pImageDims,      "%u %u %u ",     width, height, bitsPerPixel );


		const int letterHeight = (height / 40);
		HFONT font = ::CreateFont( letterHeight, 0, 0, 0, 0,
								   false, false, false,
								   DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
								   FIXED_PITCH | FF_MODERN | 0x04, "courier new" );
		HFONT dfltFont = static_cast<HFONT>( ::SelectObject( screenDC, font ) );
		::SetBkColor( screenDC, COLORREF( 0x00000000 ) );
		::SetTextColor( screenDC, COLORREF( 0x00FFFFFF ) );

		if( keyToggle )
		{
			::TextOut( screenDC, letterHeight, letterHeight * 2,  pAveFrameRate,   DWORD(aveFrameRateLen) );
			::TextOut( screenDC, letterHeight, letterHeight * 4,  pLastFrameRate,  DWORD(lastFrameRateLen) );
			::TextOut( screenDC, letterHeight, letterHeight * 6,  pFrameCount,     DWORD(frameCountLen) );
			::TextOut( screenDC, letterHeight, letterHeight * 8, pSimulationDims, DWORD(simDimsLen) );
			::TextOut( screenDC, letterHeight, letterHeight * 10, pImageDims,      DWORD(imageDimsLen) );
		}
		else   /// just toggled off, so blank out the stats
		{
			static const char blank[] = "                 ";
			::TextOut( screenDC, letterHeight, letterHeight * 2,  blank, DWORD(17) );
			::TextOut( screenDC, letterHeight, letterHeight * 4,  blank, DWORD(17) );
			::TextOut( screenDC, letterHeight, letterHeight * 6,  blank, DWORD(17) );
			::TextOut( screenDC, letterHeight, letterHeight * 8,  blank, DWORD(17) );
			::TextOut( screenDC, letterHeight, letterHeight * 10, blank, DWORD(17) );
		}

		::DeleteObject( ::SelectObject( screenDC, dfltFont ) );
	}

	lastKeyToggle = keyToggle;


	return handledKeyPress;
}


bool WinSaverGeneratorFire::manuallyChangeResolution
(
	HDC screenDC,
	const sdword width,
	const sdword height,
	const char   keyPress
)
{
//static std::ofstream log( "mcr.txt" );

	static bool   changedPreviously = false;
	static bool   measuring         = false;
	static sdword fps               = 0;

	bool handledKeyPress = false;

	switch( keyPress )
	{
	case 'g' :
	case 'G' :
		adjustResolution( false, screenDC, width, height );
		measureFrameRate( true, fps );
		measuring = true;
		handledKeyPress = true;
//log << "reduce" << "\n";
		break;
	case 'h' :
	case 'H' :
		adjustResolution( true, screenDC, width, height );
		measureFrameRate( true, fps );
		measuring = true;
		handledKeyPress = true;
//log << "increase" << "\n";
		break;
	default:
		if( changedPreviously )
		{
//log << "   changed previously" << "\n";
			generator_m.notifyOfFrameRate( framesPerSecondLast_m );
		}
		else if( measuring )
		{
//log << "   measuring" << "\n";
			measuring = !measureFrameRate( false, fps );
			if( !measuring )
			{
//log << "   notifying" << "\n";
//log << "   ---" << "\n\n";
				generator_m.notifyOfFrameRate( framesPerSecondLast_m );
			}
		}
		break;
	}

	changedPreviously = handledKeyPress;

	return handledKeyPress;
}




void WinSaverGeneratorFire::controlFrameRate
(
	HDC screenDC,
	const sdword width,
	const sdword height
)
{
	static bool isInitialAdjusterActivated = true;
	//static bool isDelayedAdjusterActivated = false;


	if( isInitialAdjusterActivated )
	{
		sdword framesPerSecond = 0;
		if( measureFrameRate( false, framesPerSecond ) )
		{
			const sdword targetFramesPerSecond = generator_m.getSimulationHeight() > 250 ? targetFramesPerSecond_m : targetFramesPerSecond_m / 2;
			if( framesPerSecond < targetFramesPerSecond )
			{
				if( adjustResolution( false, screenDC, width, height ) )
				{
				}
				else
				{
					generator_m.notifyOfFrameRate( framesPerSecond );
					isInitialAdjusterActivated = false;
					frameCount_m = 0;
				}
			}
			else
			{
				generator_m.notifyOfFrameRate( framesPerSecond );
				isInitialAdjusterActivated = false;
				frameCount_m = 0;
			}
		}

		//isDelayedAdjusterActivated = !isInitialAdjusterActivated;
	}
	/*else if( isDelayedAdjusterActivated )
	{
		static bool   isFinalRateMeasurerActivated = false;
		static sdword startTime = ::GetTickCount();

		if( (::GetTickCount() - startTime) > 10000 )
		{
			sdword framesPerSecond = 0;
			if( measureFrameRate( false, framesPerSecond ) )
			{
				if( !isFinalRateMeasurerActivated )
				{
					const sdword targetFramesPerSecond = generator_m.getSimulationHeight() > 250 ? targetFramesPerSecond_m : targetFramesPerSecond_m / 2;
					if( framesPerSecond >= targetFramesPerSecond )
					{
						if( generator_m.increaseResolution( width, height ) )
						{
							delete pBackBuffer_m;
							pBackBuffer_m = new WinBackBuffer( screenDC, generator_m.getWidth(), generator_m.getHeight(), generator_m.getPalette() );
						}
						else
						{
							generator_m.notifyOfFrameRate( framesPerSecond );
							isDelayedAdjusterActivated = false;
						}
					}
					else
					{
						if( (generator_m.getSimulationHeight() > minHeightResolution_m) && generator_m.decreaseResolution( width, height ) )
						{
							delete pBackBuffer_m;
							pBackBuffer_m = new WinBackBuffer( screenDC, generator_m.getWidth(), generator_m.getHeight(), generator_m.getPalette() );
						}

						isFinalRateMeasurerActivated = true;
					}
				}
				else
				{
					generator_m.notifyOfFrameRate( framesPerSecond );
					isDelayedAdjusterActivated = false;
				}
			}
		}
	}*/
}


bool WinSaverGeneratorFire::measureFrameRate
(
	const bool restart,
	sdword& fps
) /// static
{
	static sdword startTime  = 0;
	static sdword frameCount = 0;
	static bool   isMeasurementStarted = false;

	if( !isMeasurementStarted || restart )
	{
		startTime  = ::GetTickCount();
		frameCount = 0;
		isMeasurementStarted = true;
	}
	else
	{
		const sdword currentTime = ::GetTickCount();
		const sdword duration    = (currentTime - startTime);

		if( duration >= 2000 )
		//if( frameCount >= 20 )
		{
			fps = (frameCount * 1000) / duration;
			isMeasurementStarted = false;
		}
	}

	++frameCount;

	return !isMeasurementStarted;
}


void WinSaverGeneratorFire::updateFrameRate()
{
	const sdword currentTime = ::GetTickCount();

	static sdword startTime = currentTime;
	static sdword lastTime  = currentTime;

	if( frameCount_m > 0 )
	{
		framesPerSecondLast_m    = 1.0 / (double(currentTime - lastTime) / 1000.0);
		framesPerSecondAverage_m = double(frameCount_m) / (double(currentTime - startTime) / 1000.0);
	}
	else
	{
		startTime                = currentTime;
		framesPerSecondLast_m    = 0.0;
		framesPerSecondAverage_m = 0.0;

		startTime = currentTime;
	}

	lastTime = currentTime;
	++frameCount_m;
}


bool WinSaverGeneratorFire::adjustResolution
(
	const bool increase,
	HDC screenDC,
	const sdword width,
	const sdword height
)
{
	bool didChange = false;

	if( increase )
	{
		didChange = generator_m.increaseResolution( width, height );
	}
	else
	{
		if( generator_m.getSimulationHeight() > minHeightResolution_m )
		{
			didChange = generator_m.decreaseResolution( width, height );
		}
	}

	if( didChange )
	{
		delete pBackBuffer_m;
		pBackBuffer_m = new WinBackBuffer( screenDC, generator_m.getWidth(), generator_m.getHeight(), generator_m.getPalette() );
	}

	return didChange;
}
