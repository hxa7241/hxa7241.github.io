///  artifex@computer.org  |  2001-07-22  ///


#ifndef WinSaverGeneratorFire_h
#define WinSaverGeneratorFire_h


#include "Primitives.h"
#include "stdwin.h"

#include "WinSaverGenerator.h"
#include "ImageGeneratorFire.h"




class WinSaverGeneratorFire
	: public WinSaverGenerator<ImageGeneratorFire>
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                WinSaverGeneratorFire( HDC frontDc, sdword width, sdword height );

	virtual        ~WinSaverGeneratorFire();
	/// ---------------------------------------------------------


	/// update
	virtual bool    drawFrame( HDC screenDC, sdword width, sdword height, char keyPress );


protected: //---------------------------------------------------------------------------------------
	static  void    drawNameCheck( HDC screenDC, sdword width, sdword height );
	static  bool    drawInfo( HDC screenDC,
	                          sdword frameCount, double fpsLast, double fpsAverage,
	                          sdword width, sdword height, sdword bitsPerPixel,
	                          sdword simWidth, sdword simHeight,
	                          char keyPress );
			bool    manuallyChangeResolution( HDC screenDC, sdword width, sdword height, char keyPress );

	        void    controlFrameRate( HDC screenDC, sdword width, sdword height );
	static  bool    measureFrameRate( bool restart, sdword& framesPerSecond );
	        void    updateFrameRate();
	        bool    adjustResolution( bool increaseOrDecrease, HDC screenDC, sdword width, sdword height );


	static const sdword targetFramesPerSecond_m = 45;
	static const sdword minHeightResolution_m   = 136;


private: //-----------------------------------------------------------------------------------------
//	/// frame rate data
	        sdword  frameCount_m;
	        double  framesPerSecondLast_m;
	        double  framesPerSecondAverage_m;


	/// disallow
	                       WinSaverGeneratorFire( const WinSaverGeneratorFire& );
	WinSaverGeneratorFire& operator=( const WinSaverGeneratorFire& );
};




#endif//WinSaverGeneratorFire_h
