///  artifex@computer.org  |  2001-07-22  ///


#ifndef ImageGenerator_h
#define ImageGenerator_h


#include "Primitives.h"




class ImageGenerator
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	virtual         ~ImageGenerator() {}
	/// ---------------------------------------------------------


	virtual sdword        getWidth()   const = 0;
	virtual sdword        getHeight()  const = 0;
	virtual const sdword* getPalette() const = 0;

	/// update
	virtual void     drawNextFrame( sdword width, sdword height, sdword bitsPerPixel, void* image ) = 0;


protected: //---------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                 ImageGenerator() {}
	/// ---------------------------------------------------------


private: //-----------------------------------------------------------------------------------------
	/// disallow
	                 ImageGenerator( const ImageGenerator& );
	ImageGenerator&  operator=( const ImageGenerator& );

};




#endif//ImageGenerator_h
