///  artifex@computer.org  |  2001-07-22  ///


#include "WinBackBuffer.h"

#include "WinDib.h"




/// standard object services //////////////////////////////////////////////////////////////////////
WinBackBuffer::WinBackBuffer
(
	HDC frontDc,
	const sdword width,
	const sdword height,
	const sdword palette[]
)
	: dc_m( 0 ),
	  dfltBitmap_m( 0 ),
	  pWinDib_m( 0 )
{
	/// make DC
	dc_m = ::CreateCompatibleDC( frontDc );
	if( dc_m == 0 )
	{
		//const DWORD errorCode = ::GetLastError();
		throw "WinBackbuffer::construct()\n\nCreateCompatibleDC() failed\n";
	}


	/// make WinDib
	try
	{
		const bool isUsingPalette = bool( ::GetDeviceCaps( frontDc, RASTERCAPS ) & RC_PALETTE );
		if( isUsingPalette )
		{
			RGBQUAD pal[256];
			for( int i = 256;  i-- != 0; )
			{
				pal[ i ].rgbRed   = BYTE( (palette[ i ] >> 16) & 0xFF );
				pal[ i ].rgbGreen = BYTE( (palette[ i ] >>  8) & 0xFF );
				pal[ i ].rgbBlue  = BYTE( (palette[ i ]      ) & 0xFF );
				pal[ i ].rgbReserved = 0;
			}

			pWinDib_m = new WinDib( width, height, 8, pal );
		}
	   else
	   {
			sdword bitsPerPixel = sdword( ::GetDeviceCaps( frontDc, BITSPIXEL ) );
			if( bitsPerPixel == 1 )
			{
				bitsPerPixel = sdword( ::GetDeviceCaps( frontDc, PLANES ) );
			}

			pWinDib_m = new WinDib( width, height, bitsPerPixel, 0 );
	   }
	}
	catch( ... )
	{
		::DeleteDC( dc_m );
		throw;
	}
	if( pWinDib_m == 0 )
	{
		::DeleteDC( dc_m );
		throw "WinBackbuffer::Construct()\n\nCouldnt get memory for WinDib\n";
	}


	/// put WinDib into DC
	dfltBitmap_m = ::SelectObject( dc_m, pWinDib_m->getBitmapHandle() );
	if( dfltBitmap_m == 0 )
	{
		//const DWORD errorCode = ::GetLastError();
		delete pWinDib_m;
		::DeleteDC( dc_m );
		throw "WinBackbuffer::Construct()\n\nSelection of WinDib into DC failed\n";
	}
}


WinBackBuffer::~WinBackBuffer()
{
	::SelectObject( dc_m, dfltBitmap_m );
	delete pWinDib_m;
	::DeleteDC( dc_m );
}




////////////////////////////////////////////////////////////////////////////////////////////////////
HDC WinBackBuffer::getDC()
{
	return dc_m;
}


WinDib* WinBackBuffer::getWinDib()
{
	return pWinDib_m;
}


sdword WinBackBuffer::getWidth() const
{
	return pWinDib_m->getWidth();
}


sdword WinBackBuffer::getHeight() const
{
	return pWinDib_m->getHeight();
}


/**
 * Align the centers of the pixmaps, and do a blit.
 */
void WinBackBuffer::blitToCenter
(
	HDC targetDc,
	const sdword targetWidth,
	const sdword targetHeight
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		const sdword sourceWidth  = pWinDib_m->getWidth();
		const sdword sourceHeight = pWinDib_m->getHeight();

		/// center the images over each other...
		const sdword width         = sourceWidth  < targetWidth  ? sourceWidth  : targetWidth;
		const sdword height        = sourceHeight < targetHeight ? sourceHeight : targetHeight;
		const sdword offsetX       = (targetWidth  - sourceWidth)  >> 1;
		const sdword offsetY       = (targetHeight - sourceHeight) >> 1;
		const sdword offsetTargetX = offsetX >= 0 ?  offsetX : 0;
		const sdword offsetTargetY = offsetY >= 0 ?  offsetY : 0;
		const sdword offsetSourceX = offsetX <  0 ? -offsetX : 0;
		const sdword offsetSourceY = offsetY <  0 ? -offsetY : 0;

		::BitBlt( targetDc, offsetTargetX, offsetTargetY, width, height,
		          dc_m,     offsetSourceX, offsetSourceY,
		          SRCCOPY );
	}
}


/**
 * Stretch the source to fit both target dimensions, and do a blit.
 */
void WinBackBuffer::blitToStretch
(
	HDC targetDc,
	const sdword targetWidth,
	const sdword targetHeight
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		const sdword sourceWidth  = pWinDib_m->getWidth();
		const sdword sourceHeight = pWinDib_m->getHeight();

		if( (targetWidth == sourceWidth) && (targetHeight == sourceHeight) )
		{
			::BitBlt( targetDc, 0, 0, targetWidth, targetHeight,
			          dc_m,     0, 0,
			          SRCCOPY );
		}
		else
		{
			::SetStretchBltMode( dc_m, WHITEONBLACK );
			::StretchBlt( targetDc, 0, 0, targetWidth, targetHeight,
			              dc_m,     0, 0, sourceWidth, sourceHeight,
			              SRCCOPY );
		}
	}
}


/**
 * Scale the source uniformly to fit the target, and do a blit.
 */
void WinBackBuffer::blitToScale
(
	HDC    targetDc,
	sdword targetWidth,
	sdword targetHeight
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		const sdword sourceWidth  = pWinDib_m->getWidth();
		const sdword sourceHeight = pWinDib_m->getHeight();

		const float sourceAspect = float(sourceWidth) / float(sourceHeight);
		const float targetAspect = float(targetWidth) / float(targetHeight);

		sdword targetLeft = 0;
		sdword targetTop  = 0;

		if( sourceAspect > targetAspect )
		{
			/// top and bottom borders
			targetTop    = ( targetHeight - sdword( sourceAspect * float(targetWidth) ) ) / sdword(2);
			targetHeight = targetHeight - (targetTop * sdword(2));
		}
		else
		{
			/// left and right borders
			targetLeft  = ( targetWidth - sdword( sourceAspect * float(targetHeight) ) ) / sdword(2);
			targetWidth = targetWidth - (targetLeft * sdword(2));
		}

		::SetStretchBltMode( dc_m, WHITEONBLACK );
		::StretchBlt( targetDc, targetLeft, targetTop, targetWidth, targetHeight,
		              dc_m,     0,          0,         sourceWidth, sourceHeight,
		              SRCCOPY );
	}
}
