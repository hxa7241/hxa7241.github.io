///  artifex@computer.org  |  2001-07-22  ///


#ifndef WinBackBuffer_h
#define WinBackBuffer_h


#include "Primitives.h"
#include "stdwin.h"

class WinDib;




class WinBackBuffer
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                   WinBackBuffer( HDC frontDc, sdword width, sdword height, const sdword palette[] );

	virtual           ~WinBackBuffer();
	/// ---------------------------------------------------------


	virtual HDC        getDC();
	virtual WinDib*    getWinDib();
	virtual sdword     getWidth()                                                          const;
	virtual sdword     getHeight()                                                         const;

	virtual void       blitToCenter ( HDC dc, sdword width, sdword height )                const;
	virtual void       blitToStretch( HDC dc, sdword width, sdword height )                const;
	virtual void       blitToScale  ( HDC dc, sdword width, sdword height )                const;


protected: //---------------------------------------------------------------------------------------


private: //-----------------------------------------------------------------------------------------
	/// data
	        HDC        dc_m;
	        HGDIOBJ    dfltBitmap_m;
	        WinDib*    pWinDib_m;


	/// disallow
	                   WinBackBuffer( const WinBackBuffer& );
	    WinBackBuffer& operator=( const WinBackBuffer& );
};




#endif//WinBackBuffer_h
