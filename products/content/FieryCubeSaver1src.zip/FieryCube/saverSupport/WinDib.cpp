///  artifex@computer.org  |  2001-07-22  ///


#include "WinDib.h"




/// standard object services //////////////////////////////////////////////////////////////////////
WinDib::WinDib
(
	const sdword width,
	const sdword height
)
	: pBitmapInfo_m( 0 ),
	  bitmapHandle_m( 0 ),
	  pPixels_m( 0 ),
	  widthInBytes_m( 0 )
{
	WinDib::constructBitmap( width, height, e32BitsPerPixel, 0,
	                         widthInBytes_m, pBitmapInfo_m, bitmapHandle_m, pPixels_m );
}


WinDib::WinDib
(
	const sdword width,
	const sdword height,
	const sdword bitsPerPixel,
	const RGBQUAD palette[256]
)
	: pBitmapInfo_m( 0 ),
	  bitmapHandle_m( 0 ),
	  pPixels_m( 0 ),
	  widthInBytes_m( 0 )
{
	WinDib::constructBitmap( width, height, bitsPerPixel, palette,
	                         widthInBytes_m, pBitmapInfo_m, bitmapHandle_m, pPixels_m );
}


WinDib::~WinDib()
{
	::DeleteObject( bitmapHandle_m );
	delete[] reinterpret_cast<byte*>( pBitmapInfo_m );
}




/// construction ///////////////////////////////////////////////////////////////////////////////////
void WinDib::constructBitmap
(
	const sdword  width,
	const sdword  height,
	      sdword  bitsPerPixel,
	const RGBQUAD palette[256],
	sdword&       widthInBytes,  /// out
	BITMAPINFO*&  pBitmapInfo,   /// out
	HBITMAP&      bitmapHandle,  /// out
	void*&        pPixels        /// out
)  /// static
{
	if( (width < 0) || (height < 0) )
	{
		throw "WinDib::constructBitmap()\n\nwidth, height negative\n";
	}

	bitsPerPixel &= 0xFFFFFFF8;
	bitsPerPixel = (bitsPerPixel <  8) ?  8 : bitsPerPixel;
	bitsPerPixel = (bitsPerPixel > 32) ? 32 : bitsPerPixel;


	/// rows are padded at the end to make the width a dword multiple
	widthInBytes = ((width * sdword(bitsPerPixel / 8)) + 3) & ~3;


	/// allocate data structure
	static const sdword bitmapInfoExtraBytes[] = { 256 * sizeof(RGBQUAD), 3 * sizeof(sdword), 0, 0 };

	const sdword bitmapInfoSizeInBytes = sizeof(BITMAPINFO) + bitmapInfoExtraBytes[ (bitsPerPixel / 8) - 1 ];
	pBitmapInfo = reinterpret_cast<BITMAPINFO*>(new byte[ bitmapInfoSizeInBytes ]);

	if( pBitmapInfo == 0 )
	{
		throw "WinDib::constructBitmap()\n\nCouldn't get memory for BitmapInfo\n";
	}


	/// fill data structure
	pBitmapInfo->bmiHeader.biSize           =  sizeof( BITMAPINFOHEADER );   /// BitmapInfoSizeInBytes;
	pBitmapInfo->bmiHeader.biWidth          =  long(width);
	pBitmapInfo->bmiHeader.biHeight         =  -long(height);                /// neg means top down
	pBitmapInfo->bmiHeader.biPlanes         =  1;                            /// always 1
	pBitmapInfo->bmiHeader.biBitCount       =  word(bitsPerPixel);           /// 1, 4, 8, 16, 24, 32
	pBitmapInfo->bmiHeader.biCompression    =  BI_RGB;
	pBitmapInfo->bmiHeader.biSizeImage      =  0;                            /// 0 = full size no compress
	pBitmapInfo->bmiHeader.biXPelsPerMeter  =  1;                            /// ?
	pBitmapInfo->bmiHeader.biYPelsPerMeter  =  1;                            /// ?
	pBitmapInfo->bmiHeader.biClrUsed        =  0;                            /// 0 = all possible
	pBitmapInfo->bmiHeader.biClrImportant   =  0;                            /// 0 = all

	if( bitsPerPixel == e16BitsPerPixel )
	{
	   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 0 ] = DWORD(0x001F001F);   // blue   0000000000011111,0000000000011111
	   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 1 ] = DWORD(0x07E007E0);   // green  0000011111100000,0000011111100000
	   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 2 ] = DWORD(0xF800F800);   // red    1111100000000000,1111100000000000
	}
	else if( bitsPerPixel == e8BitsPerPixel )
	{
		if( palette != 0 )
		{
		   for( int i = 256;  i-- != 0; )
		   {
		      pBitmapInfo->bmiColors[ i ] = palette[ i ];
		   }
		}
	}


	/// make the bitmap
	bitmapHandle = ::CreateDIBSection( 0, pBitmapInfo, DIB_RGB_COLORS, &pPixels, 0, 0 );
	if( bitmapHandle == 0 )
	{
		//const DWORD errorCode = ::GetLastError();
		delete[] reinterpret_cast<byte*>( pBitmapInfo );
		throw  "WinDib::ConstructBitmap()\n\n::CreateDIBSection() failed\n";
	}
}




////////////////////////////////////////////////////////////////////////////////////////////////////
void* WinDib::getPixels()
{
	return pPixels_m;
}


void WinDib::setFrom
(
	const sdword, //width,
	const sdword, //height,
	const sdword[] //image[],
)
{
	/*if( (width >= 0) && (height >= 0) )
	{
		/// easy 32 bit
		if( pBitmapInfo_m->bmiHeader.biBitCount == 32 )
		{
			const sdword* pImage = image.getMemory();
			const sdword  length = image.getLength();

			const sdword* pImagePtr = pImage + length;
			      sdword* pDibPtr   = static_cast<sdword*>( pPixels_m ) + length;

			for( ;  pImagePtr > pImage;  )
			{
				*(--pDibPtr) = *(--pImagePtr);
			}
		}
	}*/
}


HBITMAP WinDib::getBitmapHandle() const
{
	return bitmapHandle_m;
}


sdword WinDib::getWidth() const
{
	return sdword( pBitmapInfo_m->bmiHeader.biWidth );
}


sdword WinDib::getHeight() const
{
	return sdword( -(pBitmapInfo_m->bmiHeader.biHeight) );
}


sdword WinDib::getBitsPerPixel() const
{
	return sdword( pBitmapInfo_m->bmiHeader.biBitCount );
}


sdword WinDib::getWidthInBytes() const
{
	return widthInBytes_m;
}
