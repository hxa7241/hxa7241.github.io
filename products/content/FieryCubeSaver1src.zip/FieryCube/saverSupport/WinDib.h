///  artifex@computer.org  |  2001-07-22  ///


#ifndef WinDib_h
#define WinDib_h


#include "Primitives.h"
#include "stdwin.h"




class WinDib
{
public: //------------------------------------------------------------------------------------------
	enum EBitsPerPixel { e8BitsPerPixel  =  8, e16BitsPerPixel = 16,
	                     e24BitsPerPixel = 24, e32BitsPerPixel = 32 };

	/// standard object services --------------------------------
	                WinDib( sdword width, sdword height );
	                WinDib( sdword width, sdword height, sdword bitsPerPixel, const RGBQUAD palette[256] =0 );

	virtual        ~WinDib();
	/// ---------------------------------------------------------


	virtual void*   getPixels();
	virtual void    setFrom( sdword width, sdword height, const sdword sheet[] );

	virtual HBITMAP getBitmapHandle() const;
	virtual sdword  getWidth()        const;
	virtual sdword  getHeight()       const;

	virtual sdword  getBitsPerPixel() const;
	virtual sdword  getWidthInBytes() const;


protected: //---------------------------------------------------------------------------------------


private: //-----------------------------------------------------------------------------------------
	/// construction
	static  void constructBitmap( sdword width, sdword height, sdword bitsPerPixel, const RGBQUAD palette[256],
	                              sdword& widthInBytes, BITMAPINFO*& pBitmapInfo, HBITMAP& bitmapHandle,
	                              void*& pPixels );


	/// data
	        BITMAPINFO*  pBitmapInfo_m;
	        HBITMAP      bitmapHandle_m;
	        void*        pPixels_m;

	        sdword       widthInBytes_m;


	/// disallow
	                WinDib( const WinDib& );
	       WinDib&  operator=( const WinDib& );
};




#endif//WinDib_h
