///  artifex@computer.org  |  2001-07-22  ///


#ifndef WinSaverGenerator_h
#define WinSaverGenerator_h


#include "Primitives.h"
#include "stdwin.h"

#include "ImageGenerator.h"
#include "WinBackBuffer.h"
#include "WinDib.h"




template<class IMAGEGENERATOR>
class WinSaverGenerator
{
public: //------------------------------------------------------------------------------------------
	/// standard object services --------------------------------
	                WinSaverGenerator( HDC frontDc, sdword width, sdword height );

	virtual        ~WinSaverGenerator();
	/// ---------------------------------------------------------


	/// update
	virtual bool    drawFrame( HDC screenDC, sdword width, sdword height, char keyPress );


protected: //---------------------------------------------------------------------------------------
	//virtual void    handleException( sdword code, const char message[],
	//                                 HDC screenDC, sdword width, sdword height ) const;

	/// data
	        IMAGEGENERATOR  generator_m;
	        WinBackBuffer*  pBackBuffer_m;

	        /// palette things
	struct LOGPALETTE256 { WORD palVersion; WORD palNumEntries; PALETTEENTRY palPalEntry[256]; };
	        LOGPALETTE256   logPalette_m;
	        HPALETTE        hPalette_m;


private: //-----------------------------------------------------------------------------------------

	/// disallow
	                   WinSaverGenerator( const WinSaverGenerator& );
	WinSaverGenerator& operator=( const WinSaverGenerator& );
};








/// TEMPLATE MEMBERS ///

/// standard object services //////////////////////////////////////////////////////////////////////
template<class IMAGEGENERATOR>
WinSaverGenerator<IMAGEGENERATOR>::WinSaverGenerator
(
	HDC frontDc,
	const sdword width,
	const sdword height
)
	: generator_m( width, height, ::GetTickCount() ),
	  pBackBuffer_m( new WinBackBuffer( frontDc, generator_m.getWidth(), generator_m.getHeight(), generator_m.getPalette() ) ),
	  hPalette_m( 0 )
{
	/// setup palette
	if( pBackBuffer_m->getWinDib()->getBitsPerPixel() == 8 )
	{
		logPalette_m.palVersion    = WORD(0x300);
		logPalette_m.palNumEntries = WORD(256);

		const sdword* pPalette = generator_m.getPalette();
		for( int i = 256;  i-- != 0; )
		{
			logPalette_m.palPalEntry[ i ].peRed   = BYTE( (pPalette[ i ] >> 16) & 0xFF );
			logPalette_m.palPalEntry[ i ].peGreen = BYTE( (pPalette[ i ] >>  8) & 0xFF );
			logPalette_m.palPalEntry[ i ].peBlue  = BYTE( (pPalette[ i ]      ) & 0xFF );
			logPalette_m.palPalEntry[ i ].peFlags = BYTE(PC_NOCOLLAPSE);
		}

		hPalette_m = ::CreatePalette( reinterpret_cast<LOGPALETTE*>( &logPalette_m ) );
	}
}


template<class IMAGEGENERATOR>
WinSaverGenerator<IMAGEGENERATOR>::~WinSaverGenerator()
{
	::DeleteObject( hPalette_m );
	delete pBackBuffer_m;
}




/// update /////////////////////////////////////////////////////////////////////////////////////////
template<class IMAGEGENERATOR>
bool WinSaverGenerator<IMAGEGENERATOR>::drawFrame
(
	HDC screenDC,
	const sdword width,
	const sdword height,
	const char   keyPress
)
{
	if( (width > 0) && (height > 0) )
	{
		/// draw the frame
		const sdword backBufWidth        = pBackBuffer_m->getWidth();
		const sdword backBufHeight       = pBackBuffer_m->getHeight();
		const sdword backBufBitsPerPixel = pBackBuffer_m->getWinDib()->getBitsPerPixel();

		generator_m.drawNextFrame( backBufWidth,
		                           backBufHeight,
		                           backBufBitsPerPixel,
		                           pBackBuffer_m->getWinDib()->getPixels() );

		/// palette stuff
		HPALETTE dfltPalette = 0;
		if( backBufBitsPerPixel == 8 )
		{
			dfltPalette = ::SelectPalette( screenDC, hPalette_m, false );
			::RealizePalette( screenDC );
		}

		/// call the appropriate blit
		if( (width >= backBufWidth) || (height >= backBufHeight) )
		{
			pBackBuffer_m->blitToCenter( screenDC, width, height );
		}
		else
		{
			pBackBuffer_m->blitToScale( screenDC, width, height );
		}

		/// palette stuff
		if( backBufBitsPerPixel == 8 )
		{
			::SelectPalette( screenDC, dfltPalette, false );
		}
	}

	return (keyPress == 0);
}




/*template<class IMAGEGENERATOR>
void WinSaverGenerator<IMAGEGENERATOR>::handleException
(
	const sdword code,
	const char message[],
	HDC screenDC,
	const sdword,// width,
	const sdword height
) const
{
	/// setup font things
	const int fontSize = height / 32;
	HFONT font = ::CreateFont( fontSize, 0, 0, 0, 0,
	                           false, false, false,
	                           DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
	                           FIXED_PITCH | FF_MODERN, "lucida console" );
	HFONT dfltFont = static_cast<HFONT>( ::SelectObject( screenDC, font ) );
	::SetBkColor( screenDC, COLORREF( 0x00000000 ) );
	::SetTextColor( screenDC, COLORREF( 0x00FFFFFF ) );


	/// output a message to screen
	sdword linePos = 10;
	//const lineInc = fontSize;
	LPTSTR text = "exception caught:";
	const DWORD textLength = 17;
	::TextOut( screenDC, 10, linePos, text, textLength );
	if( code != 0 )
	{
		char buffer[] = "           ";
		int len = std::sprintf( buffer, "code %u", code );
		::TextOut( screenDC, 10, linePos += fontSize, buffer, len );

		//LPVOID lpMsgBuf;
		//::FormatMessage(
		//    FORMAT_MESSAGE_ALLOCATE_BUFFER |
		//    FORMAT_MESSAGE_FROM_SYSTEM |
		//    FORMAT_MESSAGE_IGNORE_INSERTS,
		//    NULL,
		//    GetLastError(),
		//    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		//    (LPTSTR) &lpMsgBuf,
		//    0,
		//    NULL
		//);
		// Process any inserts in lpMsgBuf.
		// ...
		// Display the string.
		//::MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
		// Free the buffer.
		//::LocalFree( lpMsgBuf );
	}
	if( message != 0 )
	{
		::TextOut( screenDC, 10, linePos += fontSize, message, ::strlen(message) );
	}


	/// clear up font things
	::DeleteObject( ::SelectObject( screenDC, dfltFont ) );


	//throw 0;
}*/




#endif//WinSaverGenerator_h
