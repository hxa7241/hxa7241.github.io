///  artifex@computer.org  |  2001-07-22  ///


#ifndef stdwin_h
#define stdwin_h




//#define WIN32_LEAN_AND_MEAN
#include <windows.h>




#endif//stdwin_h

