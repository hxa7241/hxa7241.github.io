#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




require 'time'

require 'Hxa7241_General'




module HxaBuild


# Some metadata for a file.
#
# The purpose is to hold some short 'indicator' of a file's content,
# that is comparable -- so whether a file has changed can be
# efficiently determined (in a conservatively inacurate way).
#
# == invariants
# * @stamp is a Time
#
# == implementation
# The indicator is a time stamp. It could be a hash in a future
# version.

class FileData

	def initialize( filePathname )

		@stamp = File.mtime( filePathname )

	end


	def eql?( other )

		object_id.eql?( other.object_id ) ||
			( self.class.eql?( other.class ) &&
			  @stamp.eql?( other.stamp ) )

	end


	def ==( other )

		self.eql?( other )

	end


	def ===( other )

		self.eql?( other )

	end


	def to_s

		@stamp.iso8601

	end


protected

	attr_accessor :stamp

end




# Some metadata for a source file.
#
# Adds dependency data to the base class.
# For C++ or C language source only at present.
#
# == see
# FileData
# Dependencys
#
# == invariants
# * @dependencys is a Dependencys

class SourceFileData < FileData

	def initialize( filePathname, other=nil )

		super filePathname

		# reuse dependencys if same stamp as other
		@dependencys = if other && self.stamp == other.stamp
			other.dependencys.cloneDeep?
		else
			Dependencys.new( filePathname )
		end

	end


	def eql?( other )

		super( other ) &&
			@dependencys.eql?( other.dependencys )

	end


	def ==( other )

		self.eql?( other )

	end


	def ===( other )

		self.eql?( other )

	end


	def eachDependency( &p )

		@dependencys.each( &p )

	end


	def to_s

		super + '  ' + @dependencys.to_s

	end


protected

	attr_accessor :dependencys

end




# Dependency metadata for a source file.
#
# Holds only direct dependencys.
#
# == invariants
# * @fileNames is an Array of String file names/pathnames
#
# == implementation
# For C++ or C language source only at present.

class Dependencys

	def initialize( filePathname )

		@fileNames = Array.new

		# extract included filenames from file
		File.open( filePathname, 'r' ) do |file|

			# select conforming lines: starting with '#include'
			file.each_line do |line|
				if line =~ /\A\s*#include\s*["<](.+?)[">]/

					# store filename in Array
					filename = $1.strip
					@fileNames.push( filename )
				end
			end

		end

		@fileNames.uniq!

	end


	def eql?( other )

		object_id.eql?( other.object_id ) ||
			( self.class.eql?( other.class ) &&
			  @fileNames.eql?( other.fileNames ) )

	end


	def ==( other )

		self.eql?( other )

	end


	def ===( other )

		self.eql?( other )

	end


	def each( &p )

		@fileNames.each( &p )

	end


	def to_s

		@fileNames.join( ', ' )

	end


protected

	attr_accessor :fileNames

end


end # module HxaBuild
