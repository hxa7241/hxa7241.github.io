#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




require 'Find'

require 'Hxa7241_General'
require 'StackSet'
require 'FileData'




module HxaBuild


# A set of metadata of files.
#
# Aggregates metadatas of a number of files.
#
# == see
# FileData
#
# == invariants
# * @fileDatas is a Hash of String filepathnames => FileData
# * @nameIndex is a Hash of String filebasenames => Array filepathnames
# * @directoryList is a Array of directory pathnames
# (these containers could all be empty)
#
# == implementation
# makeFileData? is a 'Factory Method'.

class FileDataSet

	def initialize( directorys, fileTypeRx, other=nil )

		# main data structure, with unique full pathname keys
		# String pathname => FileData
		@fileDatas = Hash.new

		# index for looking up pathname synonyms from file basenames
		# String basename => Array pathnames
		@nameIndex = Hash.new

		# list of directorys in the tree
		@directoryList = Array.new

		buildDataSets!( directorys, fileTypeRx, other )

	end


	def FileDataSet.read( filePathname )

		instance = nil

		begin
			File.open( filePathname, 'r' ) do |file|
				instance = Marshal.load( file )
			end
		rescue
			instance = FileDataSet.new( nil, nil )
		end

		instance

	end


	def write?( filePathname )

		File.open( filePathname, 'w' ) do |file|
			Marshal.dump( self, file )
		end

		self

	end


	def eql?( other )

		object_id.eql?( other.object_id ) ||
			( self.class.eql?( other.class ) &&
			  @fileDatas == other.fileDatas )

	end


	def ==( other )

		self.eql?( other )

	end


	def isFileChanged?( oldFileDataSet, filePathname )

		# if the file is different from old one, or the old one doesnt exist
		@fileDatas.key?( filePathname ) &&
		   (@fileDatas[filePathname] != oldFileDataSet.fileDatas[filePathname])

	end


	def isFileExist?( regexp )

		isExist = false;

		@fileDatas.each_key do |filePathname|
			if filePathname =~ regexp
				isExist = true
				break
			end
		end

		isExist

	end


#	def isFileExist?( filePathname )
#
#		@fileDatas.has_key?( filePathname )
#
#	end


#	def each( &p )
#
#		@fileDatas.each( &p )
#
#	end


	def eachFilePathname( &p )

		@fileDatas.each_key( &p )

	end


	def getDirectorys?

		@directoryList

	end


	def delete!( *fileToDeletes )

		fileToDeletes.each do |key|
			# remove from main list
			@fileDatas.delete( key )

			# remove from synonym index
			fileBasename = File.basename( key )
			fileList = @nameIndex[ fileBasename ]
			fileList.delete( key )

			if fileList.empty?
				@nameIndex.delete( fileBasename )
			end
		end

	end


	def to_s

		s = "#{@fileDatas}\n"

		@nameIndex.each do |key, value|
			s += "#{key} =>\n"
			value.each do |element|
				s += "   #{element}\n"
			end
		end

		s += "\n#{@directoryList}"

	end


protected

	attr_reader :fileDatas, :nameIndex, :directoryList


private

	def buildDataSets!( directorys, fileTypeRx, other=nil )

		# check parameter validity, otherwise leave attributes empty
		if directorys && fileTypeRx

			# scan directory trees
			Find.find( *directorys ) do |fileOrDirName|
				filePathname = File.expand_path( fileOrDirName )

				# filter file types
				if FileTest.file?( fileOrDirName ) && fileOrDirName =~ /#{fileTypeRx}/

					# accumulate fileData into main Hash
					fileData = makeFileData?( filePathname, (other && other.fileDatas[filePathname]) )
					@fileDatas[ filePathname ] = fileData

					# accumulate names into index
					fileBasename = File.basename( filePathname )
					fileList     = @nameIndex.fetch( fileBasename ) { |key| @nameIndex[key] = [] }
					fileList.push( filePathname )

				elsif FileTest.directory?( fileOrDirName )

					# accumulate directory name into list
					@directoryList.push( filePathname )

				end
			end

		end

	end


	def makeFileData?( filePathname, other )

		FileData.new( filePathname )

	end

end




# A set of metadata of source files.
#
# Customizes FileDataSet to store and use SourceFileData.
#
# == see
# FileDataSet
# SourceFileData
#
# == implementation
# makeFileData? is a 'Factory Method' override.

class SourceFileDataSet < FileDataSet

	def initialize( directorys, fileTypeRx, other=nil )

		super

	end


	def getDependencys?( filePathname )

		fileData = @fileDatas[filePathname]

		dependencys = Hash.new

		fileData && fileData.eachDependency do |name|

			pathnames = @nameIndex[name]
			pathnames && pathnames.each do |element|
				dependencys[element] = true
			end

		end

		dependencys.keys

	end


	def isFileChanged?( oldSourceFileDatas, filePathname )

		# is file changed, or affected by its dependencys being changed
		isAffected = false

		# make non-duplicate list for file pathnames
		# (disallowing duplicates prevents infinite circular dependencys)
		dependencys = Hxa7241::StackSet.new
		dependencys.push!( filePathname )

		# traverse dependencys (list expanded during iteration)
		dependencys.each do |dependencyPathname|
			Hxa7241.log "    dependency: #{dependencyPathname}\n", 2

			# if file exists and changed from old (or not in old)
			if super( oldSourceFileDatas, dependencyPathname )
				# file is affected, no more dependency following needed
				Hxa7241.log "    [recompile]\n", 2
				isAffected = true
				false
			else
				# add next dependencys pathnames to list, and continue
				Hxa7241.log "    [add dependencys] ", 2
				subdependencys = getDependencys?( dependencyPathname )
				Hxa7241.log "#{subdependencys.length}\n    dd: #{subdependencys}\n", 2
				dependencys.push!( subdependencys )
				true
			end

		end

		isAffected

	end


private

	def makeFileData?( filePathname, other )

		SourceFileData.new( filePathname, other )

	end

end


end # module HxaBuild
