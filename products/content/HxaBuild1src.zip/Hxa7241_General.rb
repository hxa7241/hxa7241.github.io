#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




class Object

  def cloneDeep?

    Marshal.load( Marshal.dump( self ) )

  end

end




class Array

	def to_s

		s = ''
		each do |element|
			s += "#{element}\n"
		end
		s

	end

end




class Hash

	def to_s

		s = ''
		each do |key, value|
			s += "#{key} => #{value}\n"
		end
		s

	end

end




module Hxa7241

	@@logLevel = 0


	def Hxa7241.getLogLevel?
		@@logLevel
	end


	def Hxa7241.setLogLevel!( level )
		@@logLevel = level
	end


	def Hxa7241.log( item, level=0 )

		if level <= @@logLevel
			print item
		end

	end

end
