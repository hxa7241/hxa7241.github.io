#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




BEGIN {
	# add the directory containing this file to the require/load search list
	$:.push( File.dirname( $0 ) )
}


require 'Find'
require 'ftools'
require 'time'

require 'Hxa7241_General'
require 'OptionsHxaBuild'
require 'FileDataSet'




module HxaBuild

	# Entry point for commandline invocation.
	#
	def HxaBuild.main

		puts @@BANNER

		# check for help requested
		if $*.join( ' ' ) =~ HxaBuild.getSwitchTest( "help|\\?" )

			puts @@HELP
			puts @@RUBY_VER

		else

			puts Time.now.iso8601 + "\n"

			if $*.join( ' ' ) =~ HxaBuild.getSwitchTest( "msg", true )
				Hxa7241.setLogLevel!( $3.to_i )
			end

			Hxa7241.log "\n- reading options...", 1
			options = OptionsHxaBuild.new( $* )
			Hxa7241.log " done\n", 1

			isSucceeded = case $*.join( ' ' )
				when HxaBuild.getSwitchTest( "clean" )
					HxaBuild.clean( options )

				when HxaBuild.getSwitchTest( "rebuildall" )
					HxaBuild.rebuildall( options )

				else # build
					HxaBuild.build( options )
			end

			puts "\n= completed " + (isSucceeded ? "successfully" : "failurefully") + ""

		end

	end


	# Deletes intermediate/object files.
	#
	def HxaBuild.clean( options )

		Hxa7241.log "= cleaning..."

		objectFiles = Array.new

		# prepare file filter expression
		objFilesRx = options.getFileTypeFilter( 'objectExtList' )

		# scan object directorys
		Find.find( options['objDir'] ) do |fileOrDirName|

			# accumulate object files
			if FileTest.file?( fileOrDirName ) && fileOrDirName =~ /#{objFilesRx}/
				objectFiles.push( fileOrDirName )
			end

		end

		File.delete( *objectFiles )

		Hxa7241.log " deleted object files\n"

		true

	end


	# Rebuilds everything.
	#
	def HxaBuild.rebuildall( options )

		HxaBuild.clean( options )

		File.delete( HxaBuild.getSrcDatafilePathname( options ) ) if
			FileTest.exist?( HxaBuild.getSrcDatafilePathname( options ) )
		File.delete( HxaBuild.getLinkDatafilePathname( options ) ) if
			FileTest.exist?( HxaBuild.getLinkDatafilePathname( options ) )

		Hxa7241.log "- deleted build data store\n"

		HxaBuild.build( options )

	end


	# Builds that which depends on that which has changed.
	#
	def HxaBuild.build( options )

		isOk = true

		# load old file data, construct new file data
		oldSourceFileDatas = SourceFileDataSet.read( HxaBuild.getSrcDatafilePathname( options ) )
		newSourceFileDatas = SourceFileDataSet.new( options['srcDirList'],
		                                            options.getFileTypeFilter( 'sourceExtList' ),
		                                            oldSourceFileDatas )

		isOk &= HxaBuild.updateCompile( options, newSourceFileDatas, oldSourceFileDatas )

		# update file data store
		newSourceFileDatas.write?( HxaBuild.getSrcDatafilePathname( options ) )

		Hxa7241.log "::: SourceFileDatas\n#{newSourceFileDatas}\n", 3

		# load old file data, construct new file data
		oldLinkFileDatas = FileDataSet.read( HxaBuild.getLinkDatafilePathname( options ) )
		newLinkFileDatas = FileDataSet.new( options['linkDirList'],
		                                    options.getFileTypeFilter( 'linkableExtList' ),
		                                    oldLinkFileDatas )

		isOk &= HxaBuild.updateLink( options, newLinkFileDatas, oldLinkFileDatas, newSourceFileDatas )

		Hxa7241.log "::: LinkFileDatas\n#{newLinkFileDatas}\n", 3

		# update file data store
		newLinkFileDatas.write?( HxaBuild.getLinkDatafilePathname( options ) )

		isOk

	end


private

	def HxaBuild.getSwitchTest( switch, isValued=false )

		switch  = '(' + switch + ')'
		switch += '(.+?)' if isValued

		/(\A|\s)[-\/]#{switch}(\s|\Z)/

	end


	# Checks dependencys and (maybe) requests compilation.
	#
	# Iterates through file data, and for each compilable file follows
	# dependency references and checks changes, and checks object file
	# existence, to decide if compilation is needed.
	#
	def HxaBuild.updateCompile( options, newSourceFileDatas, oldSourceFileDatas )

		Hxa7241.log "\n= updating compile...\n\n"

		compilationCounter = 0
		errorCounter       = 0

		# prepare compilable-file filter
		compilableFileRx = /#{options.getFileTypeFilter( 'compilableExtList' )}/

		# step through new compilable-files
		newSourceFileDatas.eachFilePathname do |filePathname|
			if filePathname =~ compilableFileRx
				compilableFilePathname = filePathname
				Hxa7241.log "source: #{compilableFilePathname}\n", 1

				isFileChanged = newSourceFileDatas.isFileChanged?( oldSourceFileDatas, compilableFilePathname )
				isObjNeeded   = !FileTest.exist?( options.getObjFromSrc?( compilableFilePathname ) )
				Hxa7241.log "  is changed = #{isFileChanged}   is obj needed = #{isObjNeeded}\n", 1

				# recompile if file changed, or corresponding obj file doesnt exist
				if isFileChanged || isObjNeeded
					compilationCounter += 1
					isOk = compileFile( options, newSourceFileDatas.getDirectorys?, compilableFilePathname )
					errorCounter += 1 unless isOk
				end
			end
		end

		if compilationCounter > 0
			Hxa7241.log "files compiled = #{compilationCounter}\n"
			Hxa7241.log errorCounter > 0 ? "*** errors = #{errorCounter}\n" : "~~~ all ok\n"
		else
			Hxa7241.log "no compiling needed\n"
		end

		0 == errorCounter

	end


	# Issues compilation command for a file.
	#
	def HxaBuild.compileFile( options, includeDirs, filePathname )

		# command eg:
		# c:\h\dev\mingw\bin\gcc -c -x c++ -c -D _BUILD_WIN -Isrc/general -Isrc/platform/win
		# -std=c++98 -pedantic -O0 -Wall -W -Wabi -Wold-style-cast -Woverloaded-virtual -Wcast-align
		# -Wwrite-strings -Winline src/general/%1.cpp -o obj/%1.o

		Hxa7241.log "- compiling... #{filePathname}\n"

		# derive object file pathname
		objectFilePathname = options.getObjFromSrc?( filePathname )

		Hxa7241.log "  source: #{filePathname}\n  object: #{objectFilePathname}\n", 2

		# confirm output directory
		objectPath = File.dirname( objectFilePathname )
		unless FileTest.exist?( objectPath )
			File.makedirs( objectPath )
		end

		# select appropriate command
		command = if filePathname =~ /#{options.getFileTypeFilter( 'rcExtList' )}/
			options['rccompilecommand']
		else
			options['compilecommand']
		end

		Hxa7241.log "  command: #{command}\n", 1

		# insert variables into command string
		insertions = { 'sourcefile' => filePathname,
		               'objectfile' => objectFilePathname,
		               'incdirs'    => includeDirs + options['incPlatformDirList'] }
		command = HxaBuild.fillTemplateString( command, insertions, true )

		# execute command
		Hxa7241.log "  command: #{command}\n", 1
		Hxa7241.log '  ' + `#{command}` + "\n"

		0 == $?

	end


	# Checks any object and lib changes, and maybe requests link.
	#
	# Also deletes object files that dont have source files.
	#
	def HxaBuild.updateLink( options, newLinkFileDatas, oldLinkFileDatas, sourceFileDatas )

		Hxa7241.log "\n= updating link...\n\n"

		# make list of orphan object files
		filesToDelete = Array.new
		objFileRx = options.getFileTypeFilter( 'objectExtList' )
		newLinkFileDatas.eachFilePathname do |filePathname|
			if filePathname =~ /#{objFileRx}/

				srcFileRegexp = options.getSrcRegexpFromObj?( filePathname )
				unless sourceFileDatas.isFileExist?( /#{srcFileRegexp}/ )
					filesToDelete.push( filePathname )
				end

			end
		end

		# delete orphan objects
		File.delete( *filesToDelete )
		newLinkFileDatas.delete!( *filesToDelete )

		# re-link if any changes, or exe missing
		isObjFilesChanged = newLinkFileDatas != oldLinkFileDatas
		isExeFileNeeded   = !FileTest.exist?( options['exePathname'] )
		Hxa7241.log "  object files changed = #{isObjFilesChanged}   exe file needed = #{isExeFileNeeded}\n", 1
		if isObjFilesChanged || isExeFileNeeded
			isOk = link( options, newLinkFileDatas )
			Hxa7241.log isOk ? "~~~ all ok\n" : "*** failed\n"
			isOk
		else
			Hxa7241.log "no linking needed\n"
			true
		end

	end


	# Issues link command.
	#
	def HxaBuild.link( options, linkFileDatas )

		Hxa7241.log "- linking... #{options['exePathname']}\n"

		# gather link file pathnames
		objFiles = ""
		libFiles = ""
		libRx    = options.getFileTypeFilter( 'libExtList' )
		linkFileDatas.eachFilePathname do |filePathname|
			if filePathname =~ /#{libRx}/
				libFiles += filePathname + ' '
			else
				objFiles += filePathname + ' '
			end
		end

		Hxa7241.log "  command: #{options['linkcommand']}\n", 1

		# insert variables into command
		insertions = { 'objfiles'    => objFiles,
		               'libfiles'    => libFiles,
		               'exepathname' => options['exePathname'],
		               'libdirs'     => options['libPlatformDirList'] }
		command = HxaBuild.fillTemplateString( options['linkcommand'], insertions, true )

		# execute command
		Hxa7241.log "  command: #{command}\n", 1
		linkResponse = `#{command}`
		Hxa7241.log '  ' + linkResponse + "\n" unless linkResponse.empty?

		0 == $?

	end


	def HxaBuild.fillTemplateString( template, variables, isClearUnknown )

		template.gsub( /\$\{(.+?)\}/ ) do |slot|

			$1 =~ /((.+?),)?(.+)/

			if variables[ $3 ]
				unless $1
					variables[ $3 ]
				else
					$2 + variables[ $3 ].join( $2 )
				end
#				$1 ? $2 + variables[ $3 ].join( $2 ) : variables[ $3 ]
			else
				isClearUnknown ? '' : slot
			end

		end

	end


	def HxaBuild.getSrcDatafilePathname( options )

		File.join( options['homeDir'], @@SRC_DATAFILE )

	end


	def HxaBuild.getLinkDatafilePathname( options )

		File.join( options['homeDir'], @@LINK_DATAFILE )

	end


	@@SRC_DATAFILE  = 'HxaBuild-s.data'
	@@LINK_DATAFILE = 'HxaBuild-o.data'

	@@BANNER = "\n-------------------------------------------------------------\n" +
	           " HxaBuild v1\n" +
	           " Copyright (c) 2005,  Harrison Ainsworth.\n\n" +
	           " http://hxa7241.org/\n" +
	           "-------------------------------------------------------------\n\n"

	@@HELP   = "HxaBuild automates C++ project building.\n" +
	           "\npreparation:\n" +
	           "   adjust values in the options file\n" +
	           "\nusage:\n" +
	           "   HxaBuild.rb [-clean|-rebuildall] [-msg<n>] [optionsfilepathname]\n" +
	           "   HxaBuild.rb -help|-?\n" +
	           "\nswitches:\n" +
	           "   -clean       delete intermediate (object) files\n" +
	           "   -rebuildall  clean + delete data store + build\n" +
	           "   -msg<0-4>    set message level: higher == more\n" +
	           "   -help|-?     prints this message\n" +
	           "\nparameters:\n" +
	           "   optionsfilepathname  defaults to 'HxaBuild-options.txt'\n"

	@@RUBY_VER = "\n[ RUBY #{RUBY_VERSION}  #{RUBY_RELEASE_DATE}  #{RUBY_PLATFORM} ]"

end




HxaBuild.main
