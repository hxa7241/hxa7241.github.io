#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




module Hxa7241


# Set of name-value pairs read from a file.
#
# The file that is read must be an ascii text file.
# Each line is either blank, a comment -- starting with #, or a
# name-value pair -- of the form: name = some value 75835 etc.
#
# == invariants
# * @filePathname is nil or a String
# * @nameValuePairs is a Hash of Strings and Strings

class Options

	def initialize( filePathname )

		setDefaults!

		begin
			@filePathname = File.expand_path( filePathname )

			Options.deserializeFile( @filePathname, @nameValuePairs )
		rescue
#			puts '--- warning: ' + $!
#			puts 'using default options'

			@filePathname = nil
		end

	end


	def []( key )

		value = @nameValuePairs[ key ]
		value && value.clone

	end


	def to_s( isSorted=true )

		s = "[#{@filePathname.to_s}]\n"

		if isSorted
			@nameValuePairs.sort.each do |e|
				s += "#{e[0]} => #{e[1]}\n"
			end
		else
			s += "#{@nameValuePairs}"
		end

		s

	end


private

	def setDefaults!

		@nameValuePairs = Hash.new

	end


	def Options.deserializeFile( filePathname, nameValuePairs )

		File.open( filePathname, 'r' ) do |file|

			# select conforming lines: starting with 'name ='
			file.each_line do |line|
				if line =~ /\A\s*(\w+)\s*=/

					# store name and value in Hash
					nameValuePairs[ $1.strip ] = $'.strip
				end
			end

		end

	end

end


end # module Hxa7241
