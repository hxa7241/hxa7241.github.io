#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




require 'Options'




module HxaBuild


# All options and configurations for a build.
#
# == see
# Options.rb
# HxaBuild.rb
#
# == invariants
# * each @nameValuePairs value must be a valid string
# * values of paths have directory separators as /
# * values of lists have separators as ;
# * values of lists have no trailing separator
# * values of name extensions have no .

class OptionsHxaBuild < Hxa7241::Options

	def initialize( commandlineOrFilePathname )

		filePathname = OptionsHxaBuild.getFilePathname( commandlineOrFilePathname )
		super( filePathname )

		OptionsHxaBuild.regulariseValues( @nameValuePairs )

		OptionsHxaBuild.expandProjectPathValues(
			@nameValuePairs,
			@nameValuePairs['homeDir'],
			['exeDir', 'objDir', 'libDirList', 'srcDirList'] )

		# add some secondary derived values
		secondarys = {
			'sourceExtList'     => ['cppExtList', 'hppExtList', 'rcExtList'],
			'compilableExtList' => ['cppExtList', 'rcExtList'],
			'objectExtList'     => ['objExtList', 'resExtList'],
			'linkableExtList'   => ['objExtList', 'resExtList', 'libExtList'],
			'linkDirList'       => ['objDir', 'libDirList'] }
		secondarys.each do |key, value|
			@nameValuePairs[key] = @nameValuePairs.values_at( *value ).join( ';' )
		end
		@nameValuePairs['exePathname'] = @nameValuePairs['exeDir'] + '/' +
		                                 @nameValuePairs.values_at( 'exename', 'exeExt' ).join( '.' )

	end


	# Returns a string, or an Array of Strings.
	#
	def []( key )

		value = super

		if value
			if key =~ /List\Z/
				value.split( ';' )
			else
				value
			end
		end

	end


	def getObjFromSrc?( filePathname )

		fromDirsEsc = OptionsHxaBuild.getEscapedStringForRegexp( @nameValuePairs['srcDirList'] )
		toDir       = @nameValuePairs['objDir']

		# replace base directory with other directory
		movedFilePathname = if filePathname =~ /\A(#{fromDirsEsc.tr( ';', '|' )})#{'\\' + File::SEPARATOR}/
			# from known from-dir, goes into: base to-dir / last part of from-dir / rest of from path
			File.join( toDir, File.basename( $1 ), $' )
		else
			# not from known from-dir, goes into base to-dir
			File.join( toDir, File.basename( filePathname ) )
		end

		# replace name extension
		fromToExts = [ [ @nameValuePairs['cppExtList'], @nameValuePairs['objExtList'] ],
		               [ @nameValuePairs['rcExtList'],  @nameValuePairs['resExtList'] ] ]
		OptionsHxaBuild.changeNameExtension( movedFilePathname, fromToExts )

	end


	def getSrcRegexpFromObj?( filePathname )

		fromDirsEsc = OptionsHxaBuild.getEscapedStringForRegexp( @nameValuePairs['objDir'] )
		toDirs      = @nameValuePairs['srcDirList']

		# replace base directory with other directory
		movedFilePathname =
		if filePathname =~
		/\A(#{fromDirsEsc.tr( ';', '|' )})(#{'\\' + File::SEPARATOR}.+?)#{'\\' + File::SEPARATOR}/
			furtherPart  = $'
			firstPartEsc = OptionsHxaBuild.getEscapedStringForRegexp( $2 )
			if toDirs =~ /(\A|;)([^;]+?#{firstPartEsc})(;|\Z)/
				File.join( $2, furtherPart )
			end
		end
		# not from known from-dir, goes into base to-dir
		movedFilePathname = movedFilePathname ||
		   File.join( OptionsHxaBuild.getFirstOfList( toDirs ), File.basename( filePathname ) )

		# replace name extension
		fromToExts = [ [ @nameValuePairs['objExtList'], @nameValuePairs['cppExtList'] ],
		               [ @nameValuePairs['resExtList'], @nameValuePairs['rcExtList']  ] ]
		adjustedFilePathname = nil
		fromToExts.each do |fromTo|
			from = fromTo[0]
			to   = fromTo[1]
			from = OptionsHxaBuild.getEscapedStringForRegexp( from )
			if movedFilePathname =~ /\.(#{from.tr( ';', '|' )})\Z/
				leftPart = OptionsHxaBuild.getEscapedStringForRegexp( $` )
				to       = OptionsHxaBuild.getEscapedStringForRegexp( to )
				adjustedFilePathname = "#{leftPart}\\.(#{to.tr( ';', '|' )})"
				break
			end
		end
		movedFilePathname = adjustedFilePathname ||
			OptionsHxaBuild.getEscapedStringForRegexp( movedFilePathname )

		'\A' + movedFilePathname + '\Z'

	end


	def getFileTypeFilter( key )

		valueEsc = OptionsHxaBuild.getEscapedStringForRegexp( @nameValuePairs[key] )
		"(\\.#{valueEsc.gsub( /;/, '|\.' )})\\Z"

	end


private

	def setDefaults!

		currentDir = File.expand_path( '.' )

		@nameValuePairs = {
			'version'            => '1',

			'homeDir'            => currentDir,
			'exeDir'             => currentDir,
			'objDir'             => File.join( currentDir, 'obj' ),
			'libDirList'         => File.join( currentDir, 'lib' ),
			'srcDirList'         => File.join( currentDir, 'src' ),

			'libPlatformDirList' => '',
			'incPlatformDirList' => '',

			'cppExtList'         => 'cpp;cxx;cc;cp;c;CPP;CXX;CC;CP;C',
			'hppExtList'         => 'hpp;hxx;hh;h;HPP;HXX;HH;H',
			'rcExtList'          => 'rc;RC',
			'objExtList'         => 'o;O',
			'resExtList'         => 'o;O',
			'libExtList'         => 'lib;LIB',
			'exeExt'             => 'exe',

			'exename'            => 'mydefaultprogramname',

			'compilecommand'     => '-c -x c++ -ansi -std=c++98 -pedantic -fno-gnu-keywords ' +
			                        '-fno-enforce-eh-specs -Wall -Wextra -Wabi -Wold-style-cast ' +
			                        '-Woverloaded-virtual -Wsign-promo -Wcast-align -Wwrite-strings ' +
			                        '-Wunreachable-code -Winline -Wdisabled-optimization ' +
			                        '${ -I,incdirs} ${sourcefile} -o ${objectfile}',
			'linkcommand'        => 'gcc -o ${exepathname} ${objfiles} ${libfiles}',
			'rccompilecommand'   => 'windres ${ -I,incdirs} -i ${sourcefile} -o ${objectfile}'
		}

	end


	def OptionsHxaBuild.getFilePathname( commandlineOrFilePathname )

		for token in commandlineOrFilePathname
			# is first char not a switch indicator: - or /
			if token =~ /\A[^-\/]/
				filePathname = token
				break
			end
		end

		filePathname || @@FILEPATHNAME_DEFAULT

	end


	def OptionsHxaBuild.regulariseValues( nameValuePairs )

		nameValuePairs.each do |key, value|

			# make all path separators /
			if key =~ /Dir/
				value.tr!( '\\', '/' )
			end

#			# make all list separators ;
#			# (no, they all have to be ; already, since : causes confusion with win32 paths)
#			if key =~ /List\Z/
#				value.tr!( ':', ';' )
#			end

			# remove trailing list separators
			if key =~ /List\Z/
				value.chomp!( ';' )
			end

			# make all exts without .
			if key =~ /Ext/
				value.tr!( '.', '' )
			end
		end

	end


	def OptionsHxaBuild.expandProjectPathValues( nameValuePairs, basePath, names )

		basePath = File.expand_path( basePath )

		names.each do |name|
			nameValuePairs[name].gsub!( /(.+?)(;|\Z)/ ) do |match|
				File.expand_path( $1, basePath ) + $2
			end
		end

	end


	def OptionsHxaBuild.changeNameExtension( filename, fromToExts )

		fromToExts.each do |fromTo|
			from = fromTo[0]
			to   = fromTo[1]
			from = OptionsHxaBuild.getEscapedStringForRegexp( from )
			if filename =~ /\.(#{from.tr( ';', '|' )})\Z/
				filename = $` + '.' + OptionsHxaBuild.getFirstOfList( to )
				break
			end
		end

		filename

	end


	def OptionsHxaBuild.getFirstOfList( list )

		/\A(.+?)(;|\Z)/.match( list )[1]

	end


	def OptionsHxaBuild.getEscapedStringForRegexp( string )

		# this doesnt cover all situations. eg. [] class clauses
		# . | ( ) [ { + \ ^ $ * ?
		string.gsub( /[.|()\[{+\\^$*?]/, '\\\\\&' );

	end


	@@FILEPATHNAME_DEFAULT = 'HxaBuild-options.txt'

end


end # module HxaBuild
