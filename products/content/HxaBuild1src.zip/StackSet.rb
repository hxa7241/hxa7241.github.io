#--------------------------------------------------------------------#
#                                                                    #
#  HxaBuild version 1                                                #
#  Copyright (c) 2005,  Harrison Ainsworth.                          #
#                                                                    #
#  http://hxa7241.org/                                               #
#                                                                    #
#--------------------------------------------------------------------#

#--------------------------------------------------------------------#
#                                                                    #
#  This program is free software; you can redistribute it and/or     #
#  modify it under the terms of the GNU General Public License as    #
#  published by the Free Software Foundation; either version 2 of    #
#  the License, or (at your option) any later version.               #
#                                                                    #
#  This program is distributed in the hope that it will be useful,   #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of    #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the      #
#  GNU General Public License for more details.                      #
#                                                                    #
#  You should have received a copy of the GNU General Public License #
#  along with this program; if not, write to the Free Software       #
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,             #
#  MA 02111-1307, USA                                                #
#                                                                    #
#--------------------------------------------------------------------#




module Hxa7241


# A stack/array that will only push unique elements.
# And allows pushes during iteration, without changing the order.

class StackSet

	def initialize

		@array = Array.new
		@hash  = Hash.new

	end


	def each

		i = 0
		while i < @array.length && yield( @array[i] )
			i += 1
		end

		self

	end


	def push!( value )

		value.each do |element|
			unless @hash.key?( element )
				@hash[element] = true
				@array.push( element )
			end
		end

		self

	end


	def to_s

		@array.to_s

	end

end


end # module Hxa7241
