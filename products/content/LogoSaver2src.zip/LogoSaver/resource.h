#define DLG_CONFIG                      104
#define IDC_FLASH                       1000

#define IDB_LOGO_IMAGE_1                 305

#define IDS_LOGO_FILENAME               2001
