/*--------------------------------------------------------------------

   logo screensaver
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "resource.h"

#include "WinSaverGeneratorLogo.h"


using namespace hxa7241::logosaver;




enum EState { START, FADE_IN, DO_NOTHING, FADE_OUT };
static const dword  STATE_DURATIONS[] = { 0, 1000, 8000, 1000 };
static const dword  TIMER_PERIOD      = 50;
//static const EState NEXT_STATES[]     = { FADE_IN, DO_NOTHING, FADE_OUT, START };




/// standard object services -----------------------------------------------------------------------
WinSaverGeneratorLogo::WinSaverGeneratorLogo
(
	HINSTANCE   hInstance,
	HDC         frontDc,
	const dword ,//width,
	const dword //height
)
 :	pLogoImage_m   ( constructLogoImage( hInstance ) ),
	backBuffer_m   ( frontDc, pLogoImage_m->getWidth(), pLogoImage_m->getHeight() ),
	random_m       ( ::GetTickCount() ),
	state_m        ( START ),
	lastStateTime_m( 0 ),
	positionX_m    ( 0 ),
	positionY_m    ( 0 )
{
}


WinSaverGeneratorLogo::~WinSaverGeneratorLogo()
{
	delete pLogoImage_m;
}




/// commands ---------------------------------------------------------------------------------------
bool WinSaverGeneratorLogo::drawFrame
(
	HDC         screenDC,
	const dword width,
	const dword height,
	const char  keyPress
)
{
	if( (screenDC != 0) &
	    (width  >= pLogoImage_m->getWidth()) &
	    (height >= pLogoImage_m->getHeight()) )
	{
		const dword currentTime = dword(::GetTickCount());
		const dword elapsedTime = currentTime - lastStateTime_m;

		switch( state_m )
		{
			case START :
			{
				setPosition( width, height );
				break;
			}
			case FADE_IN  :
			case FADE_OUT :
			{
				const dword alpha = makeAlpha( state_m, elapsedTime );

				writeLogoToBuffer( *pLogoImage_m, alpha, *(backBuffer_m.getWin32Dib()) );

				backBuffer_m.blitToPosition( positionX_m, positionY_m, screenDC );

				break;
			}
			default :
			{
				break;
			}
		}

		if( elapsedTime >= STATE_DURATIONS[state_m] )
		{
			lastStateTime_m = currentTime;
			state_m         = (state_m + 1) & 0x03;//NEXT_STATES[state_m];
		}
	}

	return (keyPress == 0);
}


dword WinSaverGeneratorLogo::getTimerPeriodMillisecs()
{
	return TIMER_PERIOD;
}




/// implemention -----------------------------------------------------------------------------------
Win32Dib* WinSaverGeneratorLogo::constructLogoImage
(
	HINSTANCE hInstance
)
{
	Win32Dib* pLogoImage;

	try
	{
		/// try reading logo from the optional file
		TCHAR pFilename[32] = TEXT("");
		::LoadString( hInstance, IDS_LOGO_FILENAME, pFilename, sizeof(pFilename)/sizeof(TCHAR) );

		pLogoImage = new Win32Dib( pFilename );
	}
	catch( ... )
	{
		/// default to built in resource logo
		pLogoImage = new Win32Dib( hInstance, IDB_LOGO_IMAGE_1 );
	}

	return pLogoImage;
}


void WinSaverGeneratorLogo::setPosition
(
	const dword screenWidth,
	const dword screenHeight
)
{
	dword rangeX = screenWidth  - pLogoImage_m->getWidth()  + 1;
	dword rangeY = screenHeight - pLogoImage_m->getHeight() + 1;
	rangeX &= ~(rangeX >> 31);
	rangeY &= ~(rangeY >> 31);
	//rangeX = rangeX >= 0 ? rangeX : 0;
	//rangeY = rangeY >= 0 ? rangeY : 0;

	positionX_m = udword((random_m.getDword() & 0xFFFF) * rangeX) >> 16;
	random_m.next();

	positionY_m = udword((random_m.getDword() & 0xFFFF) * rangeY) >> 16;
	random_m.next();
}


dword WinSaverGeneratorLogo::makeAlpha
(
	const dword state,
	const dword elapsedTime
)
{
	dword alpha = ((elapsedTime << 8) - elapsedTime) / STATE_DURATIONS[state];
	if( alpha < 0 )
	{
		alpha = 0;
	}
	else if( alpha > 0xFF )
	{
		alpha = 0xFF;
	}
	//alpha &= ~(alpha >> 31);
	//alpha += (((0xFF - alpha) >> 31) & (0xFF - alpha));

	if( state == FADE_OUT )
	{
		alpha ^= 0x000000FF;
	}
	//alpha ^= ((state_m == FADE_OUT) - 1) & 0x000000FF;

	return alpha;
}


void WinSaverGeneratorLogo::writeLogoToBuffer
(
	const Win32Dib& logo,
	const dword     alpha,
	Win32Dib&       buffer
)
{
	/// only 32bit pixels version implemented at present...
	if( logo.getBitsPerPixel() == 32 )
	{
		const dword backLength = buffer.getWidth() * buffer.getHeight();
		const dword logoLength = logo.getWidth()   * logo.getHeight();
		const dword length     = logoLength < backLength ? logoLength : backLength;

		const dword* pLogo    = reinterpret_cast<const dword*>( logo.getPixels() );
		dword*       pBack    = reinterpret_cast<dword*>( buffer.getPixels() );
		dword*const  pBackEnd = pBack + length;
		for( ;  pBack < pBackEnd;  ++pBack, ++pLogo )
		{
			*pBack = scalePixelByAlpha( *pLogo, alpha ) | 0xFF000000;
		}
	}
}


dword WinSaverGeneratorLogo::scalePixelByAlpha
(
	const dword pixel,
	const dword alpha
)
{
	/// precondition: 0 <= alpha <= 0xFF

	dword pixelScaled;

	//const dword alpha = udword(pixel) >> 24;
	if( alpha == 0 )
	{
		pixelScaled = 0;
	}
	else if( alpha == 0xFF )
	{
		pixelScaled = pixel;
	}
	else
	{
		const dword rgb = pixel | 0xFF000000;

		dword b02 = (alpha * (rgb & 0x00FF00FF)) + 0x00800080;
		b02 = ((b02 + ((b02 >> 8) & 0x00FF00FF)) >> 8) & 0x00FF00FF;

		dword b13 = (alpha * ((rgb >> 8) & 0x00FF00FF)) + 0x00800080;
		b13 = (b13 + ((b13 >> 8) & 0x00FF00FF)) & 0xFF00FF00;

		pixelScaled = b02 | b13;
	}

	return pixelScaled;
}
