/*--------------------------------------------------------------------

   logo screensaver
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef WinSaverGeneratorLogo_h
#define WinSaverGeneratorLogo_h


#include "Primitives.h"
#include "stdwin.h"
#include "Win32Dib.h"
#include "Win32BackBuffer.h"
#include "RandomGood.h"




#include "hxa7241_logosaver.h"
namespace hxa7241 { namespace logosaver {
	using namespace hxa7241::primitives;
	using hxa7241::win32::Win32Dib;
	using hxa7241::win32::Win32BackBuffer;
	using hxa7241::utility::RandomGood;


class WinSaverGeneratorLogo
{
/// standard object services -----------------------------------------------------------------------
public:
	         WinSaverGeneratorLogo( HINSTANCE hInstance,
	                                HDC       frontDc,
	                                dword     width,
	                                dword     height );
	        ~WinSaverGeneratorLogo();
private:
	         WinSaverGeneratorLogo( const WinSaverGeneratorLogo& );
	WinSaverGeneratorLogo& operator=( const WinSaverGeneratorLogo& );


/// commands ---------------------------------------------------------------------------------------
public:
	        bool  drawFrame( HDC   screenDC,
	                         dword width,
	                         dword height,
	                         char  keyPress );
	static  dword getTimerPeriodMillisecs();


/// implemention -----------------------------------------------------------------------------------
protected:
	static  Win32Dib* constructLogoImage( HINSTANCE hInstance );

	        void  setPosition( dword screenWidth,
	                           dword screenHeight );

	static  dword makeAlpha( dword state,
	                         dword elapsedTime );
	static  void  writeLogoToBuffer( const Win32Dib&,
	                                 dword alpha,
	                                 Win32Dib& );
	static  dword scalePixelByAlpha( dword pixel,
	                                 dword alpha );


/// fields -----------------------------------------------------------------------------------------
private:
	Win32Dib*       pLogoImage_m;
	Win32BackBuffer backBuffer_m;
	RandomGood      random_m;

	dword state_m;
	dword lastStateTime_m;
	dword positionX_m;
	dword positionY_m;
};


}}




#endif//WinSaverGeneratorLogo_h
