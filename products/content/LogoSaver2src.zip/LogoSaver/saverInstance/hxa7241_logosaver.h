/*--------------------------------------------------------------------

   logo screensaver
   Copyright � 2003,  Harrison Ainsworth.  All rights reserved.

   www.hxa7241.org

--------------------------------------------------------------------*/


#ifndef hxa7241_logosaver_p
#define hxa7241_logosaver_p




namespace hxa7241
{
	namespace logosaver
	{
		class WinSaverGeneratorLogo;
	}
}




#endif//hxa7241_logosaver_p
