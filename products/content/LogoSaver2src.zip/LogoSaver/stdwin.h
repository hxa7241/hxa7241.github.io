/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef stdwin_h
#define stdwin_h




#define WIN32_LEAN_AND_MEAN
#include <windows.h>




#endif//stdwin_h

