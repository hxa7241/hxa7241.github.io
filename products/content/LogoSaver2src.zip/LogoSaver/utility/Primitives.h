/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


/// some definitely sized integer primitive types


#ifndef Primitives_h
#define Primitives_h


#include <float>




namespace hxa7241 { namespace primitives {


/// types ------------------------------------------------------------------------------------------

	typedef  signed   char   byte;
	typedef  unsigned char   ubyte;

	typedef  signed   short  word;
	typedef  unsigned short  uword;

	typedef  signed   int    dword;
	typedef  unsigned int    udword;


/// constants --------------------------------------------------------------------------------------

	const byte   BYTE_MIN    = -byte(128);
	const byte   BYTE_MAX    = byte(127);
	const int    BYTE_BITS   = 8;

	const ubyte  UBYTE_MIN   = byte(0);
	const ubyte  UBYTE_MAX   = byte(255);
	const int    UBYTE_BITS  = 8;


	const word   WORD_MIN    = -word(32768);
	const word   WORD_MAX    = word(32767);
	const int    WORD_BITS   = 16;

	const uword  UWORD_MIN   = uword(0);
	const uword  UWORD_MAX   = uword(65535);
	const int    UWORD_BITS  = 16;


	const dword  DWORD_MIN   = -dword(2147483648u);
	const dword  DWORD_MAX   = dword(2147483647);
	const int    DWORD_BITS  = 32;

	const udword UDWORD_MIN  = udword(0);
	const udword UDWORD_MAX  = udword(4294967295u);
	const int    UDWORD_BITS = 32;


	#define FLOAT_MIN_POS     (float(FLT_MIN))
	#define FLOAT_MIN_NEG     (float(-FLT_MAX))
	#define FLOAT_MAX         (float(FLT_MAX))
	#define FLOAT_EPSILON     (float(FLT_EPSILON))
	#define FLOAT_ALMOST_ONE  (float(1.0f - FLT_EPSILON))
	#define FLOAT_SMALL       (float(1.0e-12f))
	#define FLOAT_LARGE       (float(1.0e+12f))

	#define DOUBLE_MIN_POS    (double(DBL_MIN))
	#define DOUBLE_MIN_NEG    (double(-DBL_MAX))
	#define DOUBLE_MAX        (double(DBL_MAX))
	#define DOUBLE_EPSILON    (double(DBL_EPSILON))
	#define DOUBLE_ALMOST_ONE (double(1.0 - DBL_EPSILON))


//	const float  FLOAT_MIN        = float(FLT_MIN);
//	const float  FLOAT_MAX        = float(FLT_MAX);
//	const float  FLOAT_EPSILON    = float(FLT_EPSILON);
//	const float  FLOAT_ALMOST_ONE = float(1.0f - FLT_EPSILON);


}}




#endif//Primitives_h
