/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "Random.h"   /// own header is included last
