/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Random_h
#define Random_h


#include "Primitives.h"
#include "Sequence.h"




#include "hxa7241_utility.h"
namespace hxa7241 { namespace utility {
	using namespace hxa7241::primitives;


/**
 * abstract base for a random sequence.<br/><br/>
 *
 * returned values should be signed dwords in the range [MIN_VALUE, MAX_VALUE],
 * and floats in the range [0, 1).
 */
class Random
	: public Sequence
{
/// standard object services -----------------------------------------------------------------------
protected:
	         Random() {}
public:
	virtual ~Random() {}
protected:
	         Random( const Random& )   {}
	Random& operator=( const Random& ) { return *this; }


/// commands ---------------------------------------------------------------------------------------
public:
	virtual void  setSeed( dword ) =0;

	virtual void  next()           =0;


/// queries ----------------------------------------------------------------------------------------
public:
	virtual dword getDword() const =0;
	virtual float getFloat() const =0;

	virtual float getItem()  const { return getFloat(); }
};


}}




#endif//Random_h
