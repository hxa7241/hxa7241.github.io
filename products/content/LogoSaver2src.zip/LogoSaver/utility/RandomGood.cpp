/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "RandomGood.h"   /// own header is included last


using namespace hxa7241::utility;




/// statics
const float RandomGood::AM = float( 1.0 / 2147483648.0 );




/// standard object services -----------------------------------------------------------------------
RandomGood::RandomGood
(
	const dword seed
)
 :	Random()
{
	RandomGood::setSeed( seed );
}


RandomGood::~RandomGood()
{
}


RandomGood::RandomGood( const RandomGood& other )
 :	Random()
{
	RandomGood::operator=( other );
}


RandomGood& RandomGood::operator=( const RandomGood& other )
{
	if( &other != this )
	{
		Random::operator=( other );

		idum_m = other.idum_m;
		iy_m   = other.iy_m;

		for( int j = NTAB;  j-- > 0; )
		{
			iv_m[ j ] = other.iv_m[ j ];
		}
	}

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
void RandomGood::setSeed
(
	dword seed
)
{
	seed = (seed + 1) & 0x7FFFFFFF;
	seed = seed != 0 ? seed : 1;                    /// prevent  idum = 0

	idum_m = seed;

	for( int j = NTAB + 7;  j >= 0;  j-- )          /// load the shuffle table (after 8 warm-ups)
	{
		const dword k = idum_m / IQ;                ///
		idum_m = IA * (idum_m - k * IQ) - IR * k;   /// (same as sequence part)
		idum_m += (idum_m >> 31) & IM;              ///
		//if( idum_m < 0 ) idum_m += IM;            ///

		if( j < NTAB ) iv_m[ j ] = idum_m;
	}

	iy_m = iv_m[ 0 ];
}


void RandomGood::next()
{
	const dword k = idum_m / IQ;                /// Compute  idum  =  (IA * idum) % IM  without
	idum_m = IA * (idum_m - k * IQ) - IR * k;   ///    overflow, by Shrage's method
	idum_m += (idum_m >> 31) & IM;              /// (avoid jump)
	//if( idum_m < 0 ) idum_m += IM;            ///

	const int j = iy_m / NDIV;                  /// In the range  0...NTAB-1
	iy_m        = iv_m[ j ];                    /// Output previously stored value,
	iv_m[ j ]   = idum_m;                       ///    and refill the shuffle table
}




/// queries ----------------------------------------------------------------------------------------
dword RandomGood::getDword() const
{
	return iy_m;                                /// result not quite 0 ... SDWORD max
}


float RandomGood::getFloat() const
{
	return float(udword(iy_m)) * AM;
}
