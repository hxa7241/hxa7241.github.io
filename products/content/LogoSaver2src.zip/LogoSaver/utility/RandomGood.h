/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef RandomGood_h
#define RandomGood_h


#include "Primitives.h"
#include "Random.h"




#include "hxa7241_utility.h"
namespace hxa7241 { namespace utility {
	using namespace hxa7241::primitives;


/**
 * good random number generator.<br/><br/>
 *
 * gives a signed dword in the range [1, MAX_VALUE], and a float in the
 * range (0, 1).<br/><br/>
 *
 * adapted from: <cite>'Numerical Recipes In C', ch7 p280-281, www.nr.com.</cite>
 */
class RandomGood
	: public Random
{
public:
/// standard object services -----------------------------------------------------------------------
	explicit RandomGood( dword seed =0 );

	virtual ~RandomGood();
	         RandomGood( const RandomGood& );
	RandomGood& operator=( const RandomGood& );


/// commands ---------------------------------------------------------------------------------------
	virtual void  setSeed( dword );
	virtual void  next();


/// queries ----------------------------------------------------------------------------------------
	virtual dword getDword() const;
	virtual float getFloat() const;


/// fields -----------------------------------------------------------------------------------------
private:
	/// constants
	static const dword IA   = 16807;
	static const dword IM   = 2147483647;
	static const dword IQ   = 127773;
	static const dword IR   = 2836;
	static const dword NTAB = 32;
	static const dword NDIV = 1 + (IM-1) / NTAB;
	static const float AM;

	dword idum_m;
	dword iy_m;
	dword iv_m[ NTAB ];
};


}}




#endif//RandomGood_h
