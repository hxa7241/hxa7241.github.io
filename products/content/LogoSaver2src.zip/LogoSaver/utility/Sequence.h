/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Sequence_h
#define Sequence_h


#include "Primitives.h"




#include "hxa7241_utility.h"
namespace hxa7241 { namespace utility {
	using namespace hxa7241::primitives;


/**
 * abstract base for a sequence.<br/><br/>
 */
class Sequence
{
/// standard object services -----------------------------------------------------------------------
protected:
	         Sequence() {}
public:
	virtual ~Sequence() {}
protected:
	         Sequence( const Sequence& )   {}
	Sequence& operator=( const Sequence& ) { return *this; }


/// commands ---------------------------------------------------------------------------------------
public:
	virtual void  next()          =0;


/// queries ----------------------------------------------------------------------------------------
public:
	virtual float getItem() const =0;
};


}}




#endif//Sequence_h
