/*--------------------------------------------------------------------

   utility library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef hxa7241_utility_p
#define hxa7241_utility_p




namespace hxa7241
{
	namespace utility
	{
		class Random;
		class RandomGood;
		class Sequence;
	}
}




#endif//hxa7241_utility_p
