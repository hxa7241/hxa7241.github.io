/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "Win32Dib.h"
//#include "Win32Exception.h"

#include "Win32BackBuffer.h"


using namespace hxa7241::win32;




/// statics
const char Win32BackBuffer::CLASS_NAME[]          = "hxa7241::win32::Win32BackBuffer";
const char Win32BackBuffer::EXCEPTION_MESSAGE_1[] = "CreateCompatibleDC() for construction failed";
const char Win32BackBuffer::EXCEPTION_MESSAGE_2[] = "Couldnt get memory for Win32Dib for construction";
const char Win32BackBuffer::EXCEPTION_MESSAGE_3[] = "Selection of Win32Dib into DC for construction failed";




/// standard object services -----------------------------------------------------------------------
Win32BackBuffer::Win32BackBuffer
(
	HDC         frontDc,
	const dword width,
	const dword height,
	const dword palette[]
)
 :	dc_m           ( 0 ),
	defaultBitmap_m( 0 ),
	pWin32Dib_m    ( 0 )
{
	construct( frontDc, width, height, 0, palette );
}


Win32BackBuffer::Win32BackBuffer
(
	HDC         frontDc,
	const dword width,
	const dword height,
	const dword bitsPerPixel,
	const dword palette[]
)
 :	dc_m           ( 0 ),
	defaultBitmap_m( 0 ),
	pWin32Dib_m    ( 0 )
{
	construct( frontDc, width, height, bitsPerPixel, palette );
}


Win32BackBuffer::Win32BackBuffer
(
	HDC         frontDc,
	const dword width,
	const dword height
)
 :	dc_m           ( 0 ),
	defaultBitmap_m( 0 ),
	pWin32Dib_m    ( 0 )
{
	construct( frontDc, width, height, 32, 0 );
}


Win32BackBuffer::~Win32BackBuffer()
{
	::SelectObject( dc_m, defaultBitmap_m );
	delete pWin32Dib_m;
	::DeleteDC( dc_m );
}




/// construction -----------------------------------------------------------------------------------
void Win32BackBuffer::construct
(
	HDC         frontDc,
	const dword width,
	const dword height,
	const dword bitsPerPixel,
	const dword palette[]
)
{
	//static const char METHOD_NAME[] = "constructor";

	/// make DC
	dc_m = ::CreateCompatibleDC( frontDc );
	if( dc_m == 0 )
	{
		//const DWORD errorCode = ::GetLastError();
		//throw hxa7241::win32::Win32Exception( EXCEPTION_MESSAGE_1, errorCode, CLASS_NAME, METHOD_NAME );
		throw EXCEPTION_MESSAGE_1;
	}


	/// make Win32Dib
	try
	{
		if( bitsPerPixel == 0 )
		{
			const bool isUsingPalette = bool( ::GetDeviceCaps( frontDc, RASTERCAPS ) & RC_PALETTE );
			if( isUsingPalette )
			{
				RGBQUAD pal[256];
				for( int i = 256;  i-- != 0; )
				{
					pal[ i ].rgbRed      = BYTE( (palette[ i ] >> 16) & 0xFF );
					pal[ i ].rgbGreen    = BYTE( (palette[ i ] >>  8) & 0xFF );
					pal[ i ].rgbBlue     = BYTE( (palette[ i ]      ) & 0xFF );
					pal[ i ].rgbReserved = 0;
				}

				pWin32Dib_m = new Win32Dib( width, height, 8, pal );
			}
			else
			{
				dword bitsPerPixel = dword( ::GetDeviceCaps( frontDc, BITSPIXEL ) );
				if( bitsPerPixel == 1 )
				{
					bitsPerPixel = dword( ::GetDeviceCaps( frontDc, PLANES ) );
				}

				pWin32Dib_m = new Win32Dib( width, height, bitsPerPixel, 0 );
			}
		}
		else
		{
			pWin32Dib_m = new Win32Dib( width, height, bitsPerPixel, 0 );
		}
	}
	catch( ... )
	{
		::DeleteDC( dc_m );
		throw;
	}
	if( pWin32Dib_m == 0 )
	{
		::DeleteDC( dc_m );
		throw EXCEPTION_MESSAGE_2;
		//throw hxa7241::utility::Exception( EXCEPTION_MESSAGE_2, CLASS_NAME, METHOD_NAME );
	}


	/// put Win32Dib into DC
	defaultBitmap_m = ::SelectObject( dc_m, pWin32Dib_m->getBitmapHandle() );
	if( defaultBitmap_m == 0 )
	{
		//const DWORD errorCode = ::GetLastError();
		delete pWin32Dib_m;
		::DeleteDC( dc_m );
		throw EXCEPTION_MESSAGE_3;
		//throw hxa7241::win32::Win32Exception( EXCEPTION_MESSAGE_3, errorCode, CLASS_NAME, METHOD_NAME );
	}
}




/// commands ---------------------------------------------------------------------------------------
HDC Win32BackBuffer::getDC()
{
	return dc_m;
}


Win32Dib* Win32BackBuffer::getWin32Dib()
{
	return pWin32Dib_m;
}




/// queries ----------------------------------------------------------------------------------------
dword Win32BackBuffer::getWidth() const
{
	return pWin32Dib_m->getWidth();
}


dword Win32BackBuffer::getHeight() const
{
	return pWin32Dib_m->getHeight();
}


void Win32BackBuffer::blitToCenter
(
	const dword targetWidth,
	const dword targetHeight,
	HDC         targetDc
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		/// calc geometry
		const POINT targetWidHei = { targetWidth, targetHeight };
		const POINT sourceWidHei = { pWin32Dib_m->getWidth(), pWin32Dib_m->getHeight() };
		POINT widHei;
		POINT offsetTarget;
		POINT offsetSource;
		calcCentering( targetWidHei, sourceWidHei, widHei, offsetTarget, offsetSource );


		/// do image
		::BitBlt( targetDc, offsetTarget.x, offsetTarget.y, widHei.x, widHei.y,
		          dc_m,     offsetSource.x, offsetSource.y,
		          SRCCOPY );
	}
}


void Win32BackBuffer::blitToStretch
(
	const dword targetWidth,
	const dword targetHeight,
	HDC         targetDc
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		const dword sourceWidth  = pWin32Dib_m->getWidth();
		const dword sourceHeight = pWin32Dib_m->getHeight();

		if( (targetWidth == sourceWidth) && (targetHeight == sourceHeight) )
		{
			::BitBlt( targetDc, 0, 0, targetWidth, targetHeight,
			          dc_m,     0, 0,
			          SRCCOPY );
		}
		else
		{
			::SetStretchBltMode( dc_m, WHITEONBLACK );
			::StretchBlt( targetDc, 0, 0, targetWidth, targetHeight,
			              dc_m,     0, 0, sourceWidth, sourceHeight,
			              SRCCOPY );
		}
	}
}


void Win32BackBuffer::blitToScale
(
	const dword targetWidth,
	const dword targetHeight,
	HDC         targetDc
) const
{
	if( (targetWidth >= 0) && (targetHeight >= 0) )
	{
		const dword sourceWidth  = pWin32Dib_m->getWidth();
		const dword sourceHeight = pWin32Dib_m->getHeight();

		const float sourceAspect = float(sourceWidth) / float(sourceHeight);
		const float targetAspect = float(targetWidth) / float(targetHeight);

		dword targetLeft = 0;
		dword targetTop  = 0;

		if( sourceAspect > targetAspect )
		{
			/// top and bottom borders
			targetTop    = ( targetHeight - dword( sourceAspect * float(targetWidth) ) ) / dword(2);
			targetHeight = targetHeight - (targetTop * dword(2));
		}
		else
		{
			/// left and right borders
			targetLeft  = ( targetWidth - dword( sourceAspect * float(targetHeight) ) ) / dword(2);
			targetWidth = targetWidth - (targetLeft * dword(2));
		}

		::SetStretchBltMode( dc_m, WHITEONBLACK );
		::StretchBlt( targetDc, targetLeft, targetTop, targetWidth, targetHeight,
		              dc_m,     0,          0,         sourceWidth, sourceHeight,
		              SRCCOPY );
	}
}


void Win32BackBuffer::blitToPosition
(
	const dword positionX,
	const dword positionY,
	HDC         targetDc
) const
{
	const dword sourceWidth  = pWin32Dib_m->getWidth();
	const dword sourceHeight = pWin32Dib_m->getHeight();

	::BitBlt( targetDc, positionX, positionY, sourceWidth, sourceHeight,
			  dc_m,     0,         0,
			  SRCCOPY );
}


void Win32BackBuffer::blitToPositionWithBorder
(
	const POINT& targetWidHei,
	const RECT*  pSourcePortion,
	HBRUSH       borderBrush,
	POINT&       position,
	HDC          targetDc
) const
{
	/// could use a bit of arithmetic refactoring...

	if( (targetWidHei.x >= 0) && (targetWidHei.y >= 0) )
	{
		/// calc geometry
		const POINT sourceWidHei = { pWin32Dib_m->getWidth(), pWin32Dib_m->getHeight() };
		POINT widHei;
		POINT offsetTarget;
		POINT offsetSource;
		calcCentering( targetWidHei, sourceWidHei, widHei, offsetTarget, offsetSource );


		const bool widerTarget   = (offsetSource.x <= 0);
		const bool heigherTarget = (offsetSource.y <= 0);

		/// do borders
		if( pSourcePortion == 0 )
		{
			/// left and right
			if( widerTarget )//((targetWidHei.x - sourceWidHei.x) > 0)
			{
				/// left
				RECT borderRect = { 0, offsetTarget.y, offsetTarget.x, offsetTarget.y + widHei.y };
				::FillRect( targetDc, &borderRect, borderBrush );

				/// right
				borderRect.left  = offsetTarget.x + sourceWidHei.x;
				borderRect.right = targetWidHei.x;
				::FillRect( targetDc, &borderRect, borderBrush );
			}

			/// top and bottom
			if( heigherTarget )//(targetWidHei.y - sourceWidHei.y) > 0
			{
				/// top
				RECT borderRect = { 0, 0, targetWidHei.x, offsetTarget.y };
				::FillRect( targetDc, &borderRect, borderBrush );

				/// bottom
				borderRect.top    = offsetTarget.y + sourceWidHei.y;
				borderRect.bottom = targetWidHei.y;
				::FillRect( targetDc, &borderRect, borderBrush );
			}
		}

		/// adjust positioning
		{
			if( !widerTarget )//( offsetSource.x > 0 )
			{
				position.x = (position.x > 0) ? 0 : position.x;

				const dword lowerLimit = targetWidHei.x - sourceWidHei.x;
				position.x = (position.x < lowerLimit) ? lowerLimit : position.x;

				offsetSource.x = -position.x;
			}

			if( !heigherTarget )//( offsetSource.y > 0 )
			{
				position.y = (position.y > 0) ? 0 : position.y;

				const dword lowerLimit = targetWidHei.y - sourceWidHei.y;
				position.y = (position.y < lowerLimit) ? lowerLimit : position.y;

				offsetSource.y = -position.y;
			}
		}

		/// intersect portion rect
		if( pSourcePortion != 0 )
		{
			const dword xDif = pSourcePortion->left - offsetSource.x;
			const dword yDif = pSourcePortion->top  - offsetSource.y;

			offsetSource.x = xDif <= 0 ? offsetSource.x : offsetSource.x + xDif;
			offsetSource.y = yDif <= 0 ? offsetSource.y : offsetSource.y + yDif;
			offsetTarget.x = xDif <= 0 ? offsetTarget.x : offsetTarget.x + xDif;
			offsetTarget.y = yDif <= 0 ? offsetTarget.y : offsetTarget.y + yDif;

			widHei.x = widHei.x <= (pSourcePortion->right  - offsetSource.x) ? widHei.x : (pSourcePortion->right  - offsetSource.x);
			widHei.y = widHei.y <= (pSourcePortion->bottom - offsetSource.y) ? widHei.y : (pSourcePortion->bottom - offsetSource.y);
		}

		/// do image
		if( (widHei.x > 0) & (widHei.y > 0) )
		{
			::BitBlt( targetDc, offsetTarget.x, offsetTarget.y, widHei.x, widHei.y,
					  dc_m,     offsetSource.x, offsetSource.y,
					  SRCCOPY );
		}
	}
}




/// implementation ---------------------------------------------------------------------------------
void Win32BackBuffer::calcCentering
(
	const POINT& targetWidHei,
	const POINT& sourceWidHei,
	POINT&       widHei,
	POINT&       offsetTarget,
	POINT&       offsetSource
)
{
	/// center the images over each other...

	widHei.x = sourceWidHei.x < targetWidHei.x ? sourceWidHei.x : targetWidHei.x;
	widHei.y = sourceWidHei.y < targetWidHei.y ? sourceWidHei.y : targetWidHei.y;

	const LONG offsetX = (targetWidHei.x - sourceWidHei.x) >> 1;
	const LONG offsetY = (targetWidHei.y - sourceWidHei.y) >> 1;

	offsetTarget.x = offsetX >= 0 ?  offsetX : 0;
	offsetTarget.y = offsetY >= 0 ?  offsetY : 0;
	offsetSource.x = offsetX <  0 ? -offsetX : 0;
	offsetSource.y = offsetY <  0 ? -offsetY : 0;
}
