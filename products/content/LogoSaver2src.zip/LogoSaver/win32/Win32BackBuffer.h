/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Win32BackBuffer_h
#define Win32BackBuffer_h


#include "Primitives.h"
#include "stdwin.h"




#include "hxa7241_win32.h"
namespace hxa7241 { namespace win32 {
	using namespace hxa7241::primitives;


/**
 * OO wrapper for win32 dc and bitmap combination.
 *
 * provides constructors for kinds of backbuffer, and various blits to
 * other target dcs.
 *
 * @see
 * Win32Dib
 */
class Win32BackBuffer
{
/// standard object services -----------------------------------------------------------------------
public:
                      /** make backbuffer same as device. */
	                  Win32BackBuffer( HDC         frontDc,
	                                   dword       width,
	                                   dword       height,
	                                   const dword palette[] );
                      /** make backbuffer of specific kind. */
	                  Win32BackBuffer( HDC         frontDc,
	                                   dword       width,
	                                   dword       height,
	                                   dword       bitsPerPixel,
	                                   const dword palette[] );
                      /** make backbuffer 32bit. */
	                  Win32BackBuffer( HDC   frontDc,
	                                   dword width,
	                                   dword height );

	virtual          ~Win32BackBuffer();
private:
	                  Win32BackBuffer( const Win32BackBuffer& );
	Win32BackBuffer&  operator=( const Win32BackBuffer& );


/// commands ---------------------------------------------------------------------------------------
public:
	virtual HDC       getDC();
	virtual Win32Dib* getWin32Dib();


/// queries ----------------------------------------------------------------------------------------
public:
	virtual dword     getWidth()                                                              const;
	virtual dword     getHeight()                                                             const;

	/** align the centers of the pixmaps, and do a blit. */
	virtual void      blitToCenter ( dword width,
	                                 dword height,
	                                 HDC   targetDc )                                         const;
	/** stretch the source to fit both target dimensions, and do a blit. */
	virtual void      blitToStretch( dword width,
	                                 dword height,
	                                 HDC   targetDc )                                         const;
	/** scale the source uniformly to fit the target, and do a blit. */
	virtual void      blitToScale  ( dword width,
	                                 dword height,
	                                 HDC   targetDc )                                         const;
	/** blit source to the position on target */
	virtual void      blitToPosition( dword positionX,
	                                  dword positionY,
	                                  HDC   targetDc )                                        const;
	/**
	 * Centered blit with filled borders, or positioned blit - depending on relative
	 * size of source and target.
	 */
	virtual void      blitToPositionWithBorder( const POINT& targetSize,
	                                            const RECT*  pSourcePortion,
	                                            HBRUSH       border,
	                                            POINT&       position,
	                                            HDC          targetDc )                       const;


/// implementation ---------------------------------------------------------------------------------
private:
	        void      construct( HDC         frontDc,
	                             dword       width,
	                             dword       height,
	                             dword       bitsPerPixel,
	                             const dword palette[] );

	static  void      calcCentering( const POINT& targetWidHei,
	                                 const POINT& sourceWidHei,
	                                 POINT&       widHei,
	                                 POINT&       offsetTarget,
	                                 POINT&       offsetSource );


/// fields -----------------------------------------------------------------------------------------
private:
	HDC       dc_m;
	HGDIOBJ   defaultBitmap_m;
	Win32Dib* pWin32Dib_m;

	static const char CLASS_NAME[];
	static const char EXCEPTION_MESSAGE_1[];
	static const char EXCEPTION_MESSAGE_2[];
	static const char EXCEPTION_MESSAGE_3[];
};


}}




#endif//Win32BackBuffer_h
