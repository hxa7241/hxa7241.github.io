/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


//#include "Win32Exception.h"
//#include <fstream>   /// TEST ///

#include "Win32Dib.h"


using namespace hxa7241::win32;




/// statics
const char Win32Dib::CLASS_NAME[]          = "hxa7241::win32::Win32Dib";
const char Win32Dib::EXCEPTION_MESSAGE_1[] = "constructBitmap failed";
const char Win32Dib::EXCEPTION_MESSAGE_2[] = "loadBitmap failed";
const char Win32Dib::EXCEPTION_MESSAGE_3[] = "readBitmap failed";




/// standard object services -----------------------------------------------------------------------
Win32Dib::Win32Dib
(
	const dword   width,
	const dword   height,
	const dword   bitsPerPixel,
	const RGBQUAD palette[256]
)
 :	pBitmapInfo_m      ( 0 ),
	bitmapHandle_m     ( 0 ),
	pPixels_m          ( 0 ),
	isPixelsAllocated_m( false ),
	widthInBytes_m     ( 0 )
{
	Win32Dib::constructBitmap( width, height, bitsPerPixel, palette,
	                           pBitmapInfo_m, bitmapHandle_m, pPixels_m, widthInBytes_m );
}


Win32Dib::Win32Dib
(
	const dword width,
	const dword height
)
 :	pBitmapInfo_m      ( 0 ),
	bitmapHandle_m     ( 0 ),
	pPixels_m          ( 0 ),
	isPixelsAllocated_m( false ),
	widthInBytes_m     ( 0 )
{
	Win32Dib::constructBitmap( width, height, e32BitsPerPixel, 0,
	                           pBitmapInfo_m, bitmapHandle_m, pPixels_m, widthInBytes_m );
}


Win32Dib::Win32Dib
(
	const HINSTANCE hInstance,
	const dword     resourceId
)
 :	pBitmapInfo_m      ( 0 ),
	bitmapHandle_m     ( 0 ),
	pPixels_m          ( 0 ),
	isPixelsAllocated_m( false ),
	widthInBytes_m     ( 0 )
{
	Win32Dib::loadBitmap32( hInstance, resourceId, pBitmapInfo_m, bitmapHandle_m, pPixels_m, widthInBytes_m );
}


Win32Dib::Win32Dib
(
	const TCHAR* pFilePathname
)
 :	pBitmapInfo_m      ( 0 ),
	bitmapHandle_m     ( 0 ),
	pPixels_m          ( 0 ),
	isPixelsAllocated_m( false ),
	widthInBytes_m     ( 0 )
{
//std::ofstream log( "log.txt" );   /// TEST ///
//std::ofstream log( "log.txt", std::ios_base::ate );   /// TEST ///
//log << "Win32Dib::constructor read" << '\n';   /// TEST ///

	Win32Dib::readBitmap32( pFilePathname, pBitmapInfo_m, bitmapHandle_m, pPixels_m, widthInBytes_m );
}


Win32Dib::~Win32Dib()
{
	if( isPixelsAllocated_m )
	{
		delete[] reinterpret_cast<dword*>( pPixels_m );
	}
	::DeleteObject( bitmapHandle_m );
	delete[] reinterpret_cast<byte*>( pBitmapInfo_m );
}




/// construction implementation --------------------------------------------------------------------
void Win32Dib::constructBitmap
(
	const dword   width,
	const dword   height,
	      dword   bitsPerPixel,
	const RGBQUAD palette[256],
	BITMAPINFO*&  pBitmapInfo,   /// out
	HBITMAP&      bitmapHandle,  /// out
	void*&        pPixels,       /// out
	dword&        widthInBytes   /// out
)
{
	//static const char METHOD_NAME[] = "constructBitmap";

	bool isSucceeded = false;

	if( (width >= 0) & (height >= 0) )
	{
		bitsPerPixel &= 0xFFFFFFF8;
		bitsPerPixel = (bitsPerPixel <  8) ?  8 : bitsPerPixel;
		bitsPerPixel = (bitsPerPixel > 32) ? 32 : bitsPerPixel;


		/// rows are padded at the end to make the width a dword multiple
		widthInBytes = ((width * dword(bitsPerPixel / 8)) + 3) & ~3;


		/// allocate info structure
		static const dword bitmapInfoExtraBytes[] = { 256 * sizeof(RGBQUAD), 3 * sizeof(dword), 0, 0 };

		const dword bitmapInfoSizeInBytes = sizeof(BITMAPINFO) + bitmapInfoExtraBytes[ (bitsPerPixel / 8) - 1 ];
		pBitmapInfo = reinterpret_cast<BITMAPINFO*>(new byte[ bitmapInfoSizeInBytes ]);
		if( pBitmapInfo != 0 )
		{
			/// fill info structure part 1
			pBitmapInfo->bmiHeader.biSize           =  sizeof( BITMAPINFOHEADER );   /// BitmapInfoSizeInBytes;
			pBitmapInfo->bmiHeader.biWidth          =  long(width);
			pBitmapInfo->bmiHeader.biHeight         =  -long(height);                /// neg means top down
			pBitmapInfo->bmiHeader.biPlanes         =  1;                            /// always 1
			pBitmapInfo->bmiHeader.biBitCount       =  word(bitsPerPixel);           /// 1, 4, 8, 16, 24, 32
			pBitmapInfo->bmiHeader.biCompression    =  BI_RGB;
			pBitmapInfo->bmiHeader.biSizeImage      =  0;                            /// 0 = full size no compress
			pBitmapInfo->bmiHeader.biXPelsPerMeter  =  1;                            /// ?
			pBitmapInfo->bmiHeader.biYPelsPerMeter  =  1;                            /// ?
			pBitmapInfo->bmiHeader.biClrUsed        =  0;                            /// 0 = all possible
			pBitmapInfo->bmiHeader.biClrImportant   =  0;                            /// 0 = all

			/// fill info structure part 2
			if( bitsPerPixel == e16BitsPerPixel )
			{
			   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 0 ] = DWORD(0x001F001F);   /// blue   0000000000011111,0000000000011111
			   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 1 ] = DWORD(0x07E007E0);   /// green  0000011111100000,0000011111100000
			   reinterpret_cast<DWORD*const>(pBitmapInfo->bmiColors)[ 2 ] = DWORD(0xF800F800);   /// red    1111100000000000,1111100000000000
			}
			else if( bitsPerPixel == e8BitsPerPixel )
			{
				if( palette != 0 )
				{
				   for( int i = 256;  i-- != 0; )
				   {
					  pBitmapInfo->bmiColors[ i ] = palette[ i ];
				   }
				}
			}


			/// make the bitmap
			bitmapHandle = ::CreateDIBSection( 0, pBitmapInfo, DIB_RGB_COLORS, &pPixels, 0, 0 );
			if( bitmapHandle != 0 )
			{
				isSucceeded = true;
			}
			else
			{
				delete[] reinterpret_cast<byte*>( pBitmapInfo );
			}
		}
	}

	if( !isSucceeded )
	{
		//const DWORD errorCode = ::GetLastError();
		//throw hxa7241::win32::Win32Exception( EXCEPTION_MESSAGE_1, errorCode, CLASS_NAME, METHOD_NAME );
		throw EXCEPTION_MESSAGE_1;
	}
}


void Win32Dib::loadBitmap32
(
	const HINSTANCE hInstance,
	const dword     resourceId,
	BITMAPINFO*&    pBitmapInfo,
	HBITMAP&        bitmapHandle,
	void*&          pPixels,
	dword&          widthInBytes
)
{
	//static const char METHOD_NAME[] = "loadBitmap32";

	bool isSucceeded = false;

	/// load resource bitmap
	HBITMAP bitmapHandleTemp = ::LoadBitmap( hInstance, MAKEINTRESOURCE( resourceId ) );
	if( bitmapHandleTemp != 0 )
	{
		/// get dimensions of resource bitmap
		BITMAP bitmapInfoTemp;
		if( 0 != ::GetObject( bitmapHandleTemp, sizeof(bitmapInfoTemp), &bitmapInfoTemp ) )
		{
			try
			{
				/// make 32bit bitmap
				Win32Dib::constructBitmap( bitmapInfoTemp.bmWidth, bitmapInfoTemp.bmHeight, e32BitsPerPixel, 0,
				                           pBitmapInfo, bitmapHandle, pPixels, widthInBytes );

				/// get bits from loaded bitmap to 32bit bitmap
				HDC dc = ::CreateCompatibleDC( 0 );
				if( dc != 0 )
				{
					isSucceeded = (0 != ::GetDIBits( dc, bitmapHandleTemp, 0, bitmapInfoTemp.bmHeight, pPixels, pBitmapInfo, DIB_RGB_COLORS ));

					::DeleteDC( dc );
				}
			}
			catch( ... )
			{
				::DeleteObject( bitmapHandleTemp );

				throw;
			}
		}

		::DeleteObject( bitmapHandleTemp );
	}

	if( !isSucceeded )
	{
		::DeleteObject( bitmapHandle );
		delete[] reinterpret_cast<byte*>( pBitmapInfo );

		throw EXCEPTION_MESSAGE_2;
	}
}


void Win32Dib::readBitmap32
(
	const TCHAR* pFilePathname,
	BITMAPINFO*& pBitmapInfo,
	HBITMAP&     bitmapHandle,
	void*&       pPixels,
	dword&       widthInBytes
)
{
	//static const char METHOD_NAME[] = "readBitmap32";

	bool isSucceeded = false;


	/// read temp bitmap in its own format
	BITMAPINFO* pBitmapInfoTemp  = 0;
	HBITMAP     bitmapHandleTemp = 0;
	void*       pPixelsTemp      = 0;
	dword       widthInBytesTemp = 0;
	Win32Dib::readBitmap( pFilePathname, pBitmapInfoTemp, bitmapHandleTemp, pPixelsTemp, widthInBytesTemp );


	/// convert to 32bit pixel format
	try
	{
		dword width  = pBitmapInfoTemp->bmiHeader.biWidth;
		dword height = pBitmapInfoTemp->bmiHeader.biHeight;
		height = height >= 0 ? height : -height;

		Win32Dib::constructBitmap( width, height, e32BitsPerPixel, 0,
		                           pBitmapInfo, bitmapHandle, pPixels, widthInBytes );

		HDC dc = ::CreateCompatibleDC( 0 );
		if( dc != 0 )
		{
			isSucceeded = (0 != ::SetDIBits( dc, bitmapHandle, 0, height, pPixelsTemp, pBitmapInfoTemp, DIB_RGB_COLORS ));

			::DeleteDC( dc );
		}
	}
	catch( ... )
	{
		::DeleteObject( bitmapHandleTemp );
		delete[] reinterpret_cast<byte*>( pBitmapInfoTemp );

		throw;
	}


	/// clear temp
	::DeleteObject( bitmapHandleTemp );
	delete[] reinterpret_cast<byte*>( pBitmapInfoTemp );


	if( !isSucceeded )
	{
		::DeleteObject( bitmapHandle );
		delete[] reinterpret_cast<byte*>( pBitmapInfo );

		throw EXCEPTION_MESSAGE_3;
	}
}


void Win32Dib::readBitmap
(
	const TCHAR* pFilePathname,
	BITMAPINFO*& pBitmapInfo,
	HBITMAP&     bitmapHandle,
	void*&       pPixels,
	dword&       widthInBytes
)
{
	//static const char METHOD_NAME[] = "readBitmap";

	bool isSucceeded = false;

	HANDLE hFile = ::CreateFile( pFilePathname, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, 0 );
	if( hFile != INVALID_HANDLE_VALUE )
	{
		DWORD byteCountRead = 0;

		/// read file header
		BITMAPFILEHEADER bmpFileHeader;
		if( ::ReadFile( hFile, &bmpFileHeader, sizeof(BITMAPFILEHEADER), &byteCountRead, 0 ) )
		{
			const DWORD sizeofBitmapinfo = bmpFileHeader.bfOffBits - sizeof(BITMAPFILEHEADER);

			/// allocate bitmapinfo
			pBitmapInfo = reinterpret_cast<BITMAPINFO*>(new byte[ sizeofBitmapinfo ]);
			if( pBitmapInfo != 0 )
			{
				/// read BITMAPINFO
				if( ::ReadFile( hFile, pBitmapInfo, sizeofBitmapinfo, &byteCountRead, 0 ) )
				{
					/// make the bitmap
					bitmapHandle = ::CreateDIBSection( 0, pBitmapInfo, DIB_RGB_COLORS, &pPixels, 0, 0 );
					if( bitmapHandle != 0 )
					{
						/// read pixels
						const DWORD sizeofPixels = bmpFileHeader.bfSize - sizeof(BITMAPFILEHEADER) - sizeofBitmapinfo;
						isSucceeded = ::ReadFile( hFile, pPixels, sizeofPixels, &byteCountRead, 0 );

						widthInBytes = (((pBitmapInfo->bmiHeader.biWidth * pBitmapInfo->bmiHeader.biBitCount) + 31) & ~31) / 8;

						if( !isSucceeded )
						{
							::DeleteObject( bitmapHandle );
						}
					}
				}

				if( !isSucceeded )
				{
					delete[] reinterpret_cast<byte*>(pBitmapInfo);
				}
			}
		}

		::CloseHandle( hFile );
	}

	if( !isSucceeded )
	{
		throw EXCEPTION_MESSAGE_3;
	}
}



/// commands ---------------------------------------------------------------------------------------
/*void Win32Dib::setFrom
(
	const dword,  //width,
	const dword,  //height,
	const dword[] //image[],
)
{
	if( (width >= 0) && (height >= 0) )
	{
		/// easy 32 bit
		if( pBitmapInfo_m->bmiHeader.biBitCount == 32 )
		{
			const dword* pImage = image.getMemory();
			const dword  length = image.getLength();

			const dword* pImagePtr = pImage + length;
			      dword* pDibPtr   = static_cast<dword*>( pPixels_m ) + length;

			for( ;  pImagePtr > pImage;  )
			{
				*(--pDibPtr) = *(--pImagePtr);
			}
		}
	}
}*/




/// queries ----------------------------------------------------------------------------------------
dword Win32Dib::getWidth() const
{
	return dword( pBitmapInfo_m->bmiHeader.biWidth );
}


dword Win32Dib::getHeight() const
{
	const dword height = pBitmapInfo_m->bmiHeader.biHeight;
	return height >= 0 ? height : -height;
}


void* Win32Dib::getPixels() const
{
	return pPixels_m;
}


HBITMAP Win32Dib::getBitmapHandle() const
{
	return bitmapHandle_m;
}


dword Win32Dib::getBitsPerPixel() const
{
	return dword( pBitmapInfo_m->bmiHeader.biBitCount );
}


dword Win32Dib::getWidthInBytes() const
{
	return widthInBytes_m;
}
