/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Win32Dib_h
#define Win32Dib_h


#include "Primitives.h"
#include "stdwin.h"




#include "hxa7241_win32.h"
namespace hxa7241 { namespace win32 {
	using namespace hxa7241::primitives;

/**
 * Object oriented wrapper for win32 bitmaps.
 *
 * @see
 * Win32BackBuffer
 *
 * @implementation
 * just does all the work needed to create bitmaps of various kinds.
 */
class Win32Dib
{
public:
	enum EBitsPerPixel { e8BitsPerPixel  =  8,
	                     e16BitsPerPixel = 16,
	                     e24BitsPerPixel = 24,
	                     e32BitsPerPixel = 32 };
/// standard object services -----------------------------------------------------------------------
public:
                    /** make windib. */
	                Win32Dib( dword         width,
	                          dword         height,
	                          dword         bitsPerPixel,
	                          const RGBQUAD palette[256] =0 );
                    /** make 32bit windib. */
	                Win32Dib( dword width,
	                          dword height );
                    /** load image from resource into 32bit windib. */
	                Win32Dib( HINSTANCE hInstance,
	                          dword     resourceId );
                    /** read image from file into 32bit windib. */
	                Win32Dib( const TCHAR* pFilePathname );

	virtual        ~Win32Dib();
private:
	                Win32Dib( const Win32Dib& );
	      Win32Dib& operator=( const Win32Dib& );


/// commands ---------------------------------------------------------------------------------------
public:
	//virtual void    setFrom( dword width, dword height, const dword sheet[] );


/// queries ----------------------------------------------------------------------------------------
public:
	virtual dword   getWidth()                                                                const;
	virtual dword   getHeight()                                                               const;
	virtual void*   getPixels()                                                               const;
	virtual HBITMAP getBitmapHandle()                                                         const;

	virtual dword   getBitsPerPixel()                                                         const;
	virtual dword   getWidthInBytes()                                                         const;


/// construction implementation --------------------------------------------------------------------
protected:
	static  void    constructBitmap( dword         width,
	                                 dword         height,
	                                 dword         bitsPerPixel,
	                                 const RGBQUAD palette[256],
	                                 BITMAPINFO*&  pBitmapInfo,
	                                 HBITMAP&      bitmapHandle,
	                                 void*&        pPixels,
	                                 dword&        widthInBytes );
	static  void    loadBitmap32( HINSTANCE     hInstance,
	                              dword         resourceId,
	                              BITMAPINFO*&  pBitmapInfo,
	                              HBITMAP&      bitmapHandle,
	                              void*&        pPixels,
	                              dword&        widthInBytes );
	static  void    readBitmap32( const TCHAR* pFilePathname,
	                              BITMAPINFO*& pBitmapInfo,
	                              HBITMAP&     bitmapHandle,
	                              void*&       pPixels,
	                              dword&       widthInBytes );
	static  void    readBitmap( const TCHAR* pFilePathname,
	                            BITMAPINFO*& pBitmapInfo,
	                            HBITMAP&     bitmapHandle,
	                            void*&       pPixels,
	                            dword&       widthInBytes );


/// fields -----------------------------------------------------------------------------------------
private:
	BITMAPINFO* pBitmapInfo_m;
	HBITMAP     bitmapHandle_m;
	void*       pPixels_m;
	bool        isPixelsAllocated_m;

	dword       widthInBytes_m;

	/// constants
	static const char CLASS_NAME[];
	static const char EXCEPTION_MESSAGE_1[];
	static const char EXCEPTION_MESSAGE_2[];
	static const char EXCEPTION_MESSAGE_3[];
};


}}




#endif//Win32Dib_h
