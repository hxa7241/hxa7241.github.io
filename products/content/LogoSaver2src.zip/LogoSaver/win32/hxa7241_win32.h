/*--------------------------------------------------------------------

   win32 library
   Copyright (c) 2003-2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef hxa7241_win32_p
#define hxa7241_win32_p




namespace hxa7241
{
	namespace win32
	{
		class Win32BackBuffer;
		class Win32Dib;
	}
}




#endif//hxa7241_win32_p
