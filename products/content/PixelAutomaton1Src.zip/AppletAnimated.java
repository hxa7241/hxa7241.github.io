import java.applet.*;
import java.awt.*;
import java.awt.image.*;




abstract class AppletAnimated
	extends Applet
	implements Runnable
{
/// customization interface ------------------------------------------------------------------------
	public void initDerived( int width, int height, int[] pixels )
	{
	}

	public void startDerived()
	{
	}

	public void stopDerived()
	{
	}

	public void destroyDerived()
	{
	}

	abstract protected void drawFrame( int width, int height, int[] pixels );

	//abstract protected long getSleepPeriodMillisecs();

	abstract public String getAppletInfo();
	abstract public String[][] getParameterInfo();
	//{	/// of the form:
	//	return  new String[][] { {"name",  "type",  "comment"},
	//	                         {"name",  "type",  "comment"}  };
	//}


/// construction -----------------------------------------------------------------------------------
	public AppletAnimated()
	{
		super();

//		if( IS_THREAD_USED )
//		{
//			drawThread_m = new Thread( this );
//		}
	}


/// AppletAnimated services interface --------------------------------------------------------------
	protected final int getFrameCount()
	{
		return frameCount_m;
	}

	protected final float getFrameRate()
	{
		return framesPerSecond_m;
	}


/// Applet overrides -------------------------------------------------------------------------------
	public final void init()
	{
		System.out.println( "\n--- " + getClass().getName() + " ---" );

		/// set width and height
		Dimension widhei = getSize();   /// jdk1.1
		width_m  = widhei.width;
		height_m = widhei.height;
		//width_m  = getWidth();   /// jdk1.2
		//height_m = getHeight();

		/// create pixel surface
		outputPixels_m = new int[ width_m * height_m ];

		/// create image
		//ColorModel cm    = ColorModel.getRGBdefault();
		memImageSource_m = new MemoryImageSource( width_m, height_m, outputPixels_m, 0, width_m );
		memImageSource_m.setAnimated( true );
		memImageSource_m.setFullBufferUpdates( true );
		outputImage_m = createImage( memImageSource_m );


		/// init derived object
		initDerived( width_m, height_m, outputPixels_m );
	}


	public final void start()
	{
		startDerived();

		//startThread();
	}


	public final void stop()
	{
		try
		{
			stopDerived();
		}
		finally
		{
			//stopThread();
		}
	}


	public final void destroy()
	{
		destroyDerived();
	}


	public final void update( Graphics g )
	{
		try
		{
			drawFrame( width_m, height_m, outputPixels_m );
		}
		catch( RuntimeException e )
		{
			//requestThreadStop();
			throw e;
		}

		paint( g );


		trackFrameRate();
	}


	public final void paint( Graphics g )
	{
		outputImage_m.flush();
		g.drawImage( outputImage_m, 0, 0, this );
	}


/// thread control ---------------------------------------------------------------------------------
	/*private void startThread()
	{
		if( IS_THREAD_USED )
		{
			drawThreadPermission_m = true;
			drawThread_m.start();
		}
	}


	private void stopThread()
	{
		if( IS_THREAD_USED )
		{
			try
			{
				requestThreadStop();
				drawThread_m.join();
			}
			catch( InterruptedException e )
			{
			}
		}
	}


	private void requestThreadStop()
	{
		drawThreadPermission_m = false;
	}*/


	public final void run()
	{
		/*final long sleepPeriodMillisecs = getSleepPeriodMillisecs();

		while( drawThreadPermission_m )
		{
			/// request redrawing
			repaint();

			try
			{
				drawThread_m.sleep( sleepPeriodMillisecs );
			}
			catch( InterruptedException e )
			{
				return;
			}

			memImageSource_m.newPixels( 0, 0, width_m, height_m );
		}*/
	}


/// frame rate measurement -------------------------------------------------------------------------
	private void trackFrameRate()
	{
		/*final long currentTime = System.currentTimeMillis();

		if( frameCount_m == 0 )
		{
			startTime_m = currentTime;
			lastTime_m  = currentTime;
		}
		else
		{
			final double frameRateMean      = ((double)frameCount_m * 1000.0) /
			                                  (double)(currentTime - startTime_m);
			//final double frameRateMeanShort = Math.floor( frameRateMean * 1000.0 ) / 1000.0;

			framesPerSecond_m = (float)frameRateMean;
			lastTime_m = currentTime;
		}

		++frameCount_m;*/


		final long currentTime = System.currentTimeMillis();
		final int  power  = 5;
		final int  number = 1 << power;
		final int  mask   = number - 1;

		if( frameCount_m == 0 )
		{
			startTime_m = currentTime;
			lastTime_m  = currentTime;
		}
		else if( (frameCount_m & mask) == 0 )
		{
			final double frameRateAve      = ((double)frameCount_m * 1000.0) /
			                                  (double)(currentTime - startTime_m);
			final double frameRateAveShort = Math.floor( frameRateAve * 1000.0 ) / 1000.0;
			final double frameRate         = ((double)number * 1000.0) /
			                                  (double)(currentTime - lastTime_m);
			final double frameRateShort    = Math.floor( frameRate * 1000.0 ) / 1000.0;

			if( frameCount_m == number )
			{
				System.out.println( "frames: " + frameCount_m + "  fps ave: " + frameRateAveShort + "  fps last: " + frameRateShort );
			}

			framesPerSecond_m = (float)frameRate;
			lastTime_m = currentTime;
		}

		++frameCount_m;
	}


/// fields -----------------------------------------------------------------------------------------
	/// image buffer
	private					int		width_m;
	private					int		height_m;
	private					int		outputPixels_m[];
	private					Image	outputImage_m;
	private					MemoryImageSource	memImageSource_m;

	/// other
	private	volatile		int		frameCount_m;
	private	volatile		float   framesPerSecond_m;
	private	                long	startTime_m;
	private	                long	lastTime_m;

	/// update thread
//	private static final	boolean	IS_THREAD_USED			= false;
//	private volatile		boolean	drawThreadPermission_m;
//	private 				Thread	drawThread_m;
}
