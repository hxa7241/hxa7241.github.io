import java.util.Random;




class Cells
{
/// construction
	public Cells( int[] argbPixels, int width, int height )
	{
		this( width, height );

		convertFromARGB( argbPixels );
	}

	public Cells( int width, int height )
	{
		/*/// enforce preconditions (let error be thrown otherwise)
		if( width < 0 )
		{
			width = 0;
		}
		if( height < 0 )
		{
			height = 0;
		}*/

		width_m  = width;
		height_m = height;

		final int length = width * height;

		cells_m            =  new int[ length ];
		cellsBackBuffer_m  =  new int[ length ];
	}


/// assignment & conversion
	public int[] convertFromARGB( final int[] argbPixels )
	{
		return  traverseLength( argbPixels, cells_m, KernelARGBtoGray.instance );
	}

	public int[] convertToARGB( final int[] argbPixels )
	{
		colorMapper_m.revolveColors();

		return traverseLength( cells_m, argbPixels, colorMapper_m );
	}

	public int[] getCells()
	{
		return cells_m;
	}

	public int getStepCount()
	{
		return stepCount_m;
	}


/// command interface
	public void initialize( final int[] argbPixels )
	{
		convertFromARGB( argbPixels );

		opTotals_m[0] = 0;
		opTotals_m[1] = 0;
		opTotals_m[2] = 0;
		opTotals_m[3] = 0;
		stepCount_m   = 0;
	}

	public void setFailProbability( float failProbability )
	{
		Kernel3.setFailProbability( failProbability );
	}

	public void step()
	{
		Kernel3 operation = null;

		/// choose an operation
		final int o = (randSeries_m.nextInt() & 0x7F) % 4;
		/// should stop erode and dilate counts from differing by more than 8ish, to stop the
		/// image from becoming too light or dark

		//System.out.print( o );   /// DEBUG ///

		switch( o )
		{
		case 0 :
			operation = KernelBlur.instance;      //System.out.print( "b" );
			break;
		case 1 :
			operation = KernelSharpen.instance;   //System.out.print( "s" );
			opTotals_m[ 1 ] += 4;
			break;
		case 2 :
			if( (opTotals_m[2] - opTotals_m[3]) < 8 )
			{
				operation = KernelDilate.instance;    //System.out.print( "d" );
				++(opTotals_m[ 2 ]);
			}
			else
			{
				operation = KernelErode.instance;     //System.out.print( "e" );
				++(opTotals_m[ 3 ]);
			}
			break;
		case 3 :
			if( (opTotals_m[3] - opTotals_m[2]) < 8 )
			{
				operation = KernelErode.instance;     //System.out.print( "e" );
				++(opTotals_m[ 3 ]);
			}
			else
			{
				operation = KernelDilate.instance;    //System.out.print( "d" );
				++(opTotals_m[ 2 ]);
			}
			break;
		default:  break;
		}


		//int i = (o == 1) && (((randSeries_m.nextInt() >> 0) & 0x00)) == 0) ? 4 : 1;
//if( i != 1 ) System.out.print( "x" );
		for( int i = (o == 1) ? 4 : 1;  i-- > 0; )
		{
			/// apply horizontally
			traverseLines( cells_m, cellsBackBuffer_m, operation, true );

			/// apply vertically
			traverseLines( cellsBackBuffer_m, cells_m, operation, false );
		}


		if( o != 0 )
		{
			/// apply horizontally
			traverseLines( cells_m, cellsBackBuffer_m, KernelBlur.instance, true );

			/// apply vertically
			traverseLines( cellsBackBuffer_m, cells_m, KernelBlur.instance, false );
		}

		++(opTotals_m[ 0 ]);
		++stepCount_m;

//System.out.print( ":" + opTotals_m[ 0 ] + ":" + opTotals_m[ 1 ] + ":" + opTotals_m[ 2 ] + ":" + opTotals_m[ 3 ] + "  " );

		/*if( (randSeries_m.nextInt() & 15) == 0 )
		{
			if( (randSeries_m.nextInt() & 128) == 0 )
			{
				operation = KernelErode.instance;
				System.out.print( "e" );   /// DEBUG ///
			}
			else
			{
				operation = KernelDilate.instance;
				System.out.print( "d" );   /// DEBUG ///
			}
			for( int i = 8;  i-- > 0; )
			{
				traverseLines( cells_m, cellsBackBuffer_m, operation, true );
				traverseLines( cellsBackBuffer_m, cells_m, operation, false );
			}
		}

		int i = 1;//(randSeries_m.nextInt() & 3) + 1;
		System.out.print( "" + i + " " );   /// DEBUG ///
		for( ;  i-- > 0;  )
		{
			/// apply horizontally
			traverseLines( cells_m, cellsBackBuffer_m, operation, true );

			/// apply vertically
			traverseLines( cellsBackBuffer_m, cells_m, operation, false );
		}*/
	}


/// implementation
	private void traverseLines( int[] in, int[] out, Kernel3 operation, boolean isHoriz )
	{
		int iEnd  =  width_m*height_m;
		int iInc  =  width_m;
		int jEnd  =  width_m;
		int jInc  =  1;
		if( !isHoriz )
		{
			int tmp1 = iEnd;   iEnd = jEnd;  jEnd = tmp1;
			int tmp2 = iInc;   iInc = jInc;  jInc = tmp2;
		}

		for( int i = iEnd-iInc;  i >= 0;  i -= iInc )
		{
			int j   = jEnd - jInc;
			int pos = i + j;

			out[pos] = operation.calculateEdge( in, pos, jInc, i, i+jEnd );

			//System.out.print( "" + i + " -   " );   /// DEBUG ///
			//System.out.print( "   (" + pos + ")" );   /// DEBUG ///
			for( ; (j -= jInc) > 0; )
			{
				pos = i + j;
				out[pos] = operation.calculate( in, pos, jInc );
				//System.out.print( "   " + pos );   /// DEBUG ///
			}
			pos = i + j;
			//System.out.print( "   (" + pos + ")" );   /// DEBUG ///
			//System.out.print( "\n" );   /// DEBUG ///

			out[pos] = operation.calculateEdge( in, pos, jInc, i, i+jEnd );
		}
	}

	private int[] traverseLength( int[] in, int[] out, Kernel3 operation )
	{
		final int length = in.length;

		/// enforce preconditions (let error be thrown otherwise)
		//if( length > out.length )
		//{
		//	length = out.length;
		//}


		for( int i = length;  i-- > 0; )
		{
			out[i] = operation.calculate( in, i, 0 );
		}

		return out;
	}

	/*private void flipBuffers()
	{
		int[] tmp         = cells_m;
		cells_m           = cellsBackBuffer_m;
		cellsBackBuffer_m = tmp;
	}*/


/// fields -----------------------------------------------------------------------------------------
	private final	int		width_m;
	private final	int		height_m;

	private 		int[]	cells_m;
	private 		int[]	cellsBackBuffer_m;

	private final	Random	randSeries_m	= new Random();

	private			KernelGrayToARGB	colorMapper_m	= new KernelGrayToARGB();

	private         int[]   opTotals_m = new int[ 4 ];
	private         int     stepCount_m;

}
