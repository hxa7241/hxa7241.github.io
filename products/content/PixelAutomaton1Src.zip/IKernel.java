



interface IKernel
{

	int calculate    ( int[] array, int pos, int inc );
	int calculateEdge( int[] array, int pos, int inc, int leftEnd, int rightEnd );

}
