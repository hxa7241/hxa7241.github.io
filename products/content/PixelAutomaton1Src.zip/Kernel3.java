import java.util.Random;




abstract class Kernel3
	implements IKernel
{
/// main interface
	public int calculate( int[] array, int pos, int inc )
	{
		int out = 0;

		if( rand_s.nextInt() < failRate_s )
		{
			out = array[pos];
		}
		else
		{
			out = calculate( array[pos-inc], array[pos], array[pos+inc] );
		}

		return out;

		//return calculate( array[pos-inc], array[pos], array[pos+inc] );
	}

	public int calculateEdge( int[] array, int pos, int inc, int leftEnd, int rightEnd )
	{
		final int width    = rightEnd-leftEnd;
		final int leftPos  = (((pos - leftEnd - inc) + width) % width) + leftEnd;
		final int rightPos = ( (pos - leftEnd + inc)          % width) + leftEnd;

		edgeWrap_m[0] = array[leftPos];
		edgeWrap_m[1] = array[pos];
		edgeWrap_m[2] = array[rightPos];

		return calculate( edgeWrap_m, 1, 1 );
		//return calculate( array[leftPos], array[pos], array[rightPos] );
	}


/// implementation interface
	abstract protected int calculate( int left, int middle, int right );


/// extra
	public static void setFailProbability( float failProbability )
	{
		double a  =  (((double)failProbability * 2.0) - 1.0) * -((double)Integer.MIN_VALUE);

		if( a > (double)Integer.MAX_VALUE )
		{
			a = (double)Integer.MAX_VALUE;
		}
		else if( a < (double)Integer.MIN_VALUE )
		{
			a = (double)Integer.MIN_VALUE;
		}

		failRate_s  =  (int)a;
	}

	protected static final int clamp( int p )
	{
		if( p < MIN )
		{
			p = MIN;
		}
		else if( p > MAX )
		{
			p = MAX;
		}

		return p;
	}


/// fields -----------------------------------------------------------------------------------------
	private						int[]		edgeWrap_m				= new int[ 3 ];

	private static				int		failRate_s				= Integer.MIN_VALUE;
	private static final		Random	rand_s					= new Random();

	protected static final	int		MIN						= 0x00000000;
	protected static final	int		MAX						= 0x0000FFFF;
	protected static final	int		MAX_BITMASK				= MAX;
	protected static final	int		FRACTION_BIT_SHIFT	= 8;

}
