



class KernelARGBtoGray
	extends Kernel3
{
/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		final int argb = middle;

		final int rr =  (argb & 0x00FF0000);
		final int r  =  (rr >>> 8) | (rr >>> 16);
		final int gg =  (argb & 0x0000FF00);
		final int g  =  (gg) | (gg >>> 8);
		final int bb =  (argb & 0x000000FF);
		final int b  =  (bb << 8) | (bb);
		/*final int LEAST_SIG_BYTE = 0x000000FF;
		final int r  =  (argb >>> 16) & LEAST_SIG_BYTE;
		final int g  =  (argb >>>  8) & LEAST_SIG_BYTE;
		final int b  =  (argb       ) & LEAST_SIG_BYTE;*/

		final int gray  =  (r + g + b) / 3;

		return gray;
	}

	public int calculate( int[] array, int pos, int inc )
	{
		return calculate( array[pos-inc], array[pos], array[pos+inc] );
	}


/// fields
	public static final	KernelARGBtoGray	instance	= new KernelARGBtoGray();

}
