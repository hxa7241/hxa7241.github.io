



class KernelBlur
	extends Kernel3
{
/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		return (left + (middle << 1) + right) >> 2;
	}


/// fields
	public static final	KernelBlur	instance	= new KernelBlur();

}
