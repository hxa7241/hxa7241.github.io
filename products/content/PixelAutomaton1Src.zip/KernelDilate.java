



class KernelDilate
	extends Kernel3
{
/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		return (left ^ right) | middle;
		//return (left | right) | middle;
	}


/// fields
	public static final	KernelDilate	instance	= new KernelDilate();

}
