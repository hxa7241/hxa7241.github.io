import java.util.*;




class KernelGrayToARGB
	extends Kernel3
{
/// construction
	public KernelGrayToARGB()
	{
		setPalette( palette_m );
	}


/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		/*final int gray  =  clamp( middle ) >> FRACTION_BIT_SHIFT;
		//final int gray  =  (middle & MAX_BITMASK) >> 8;   /// rollover

		final int ALPHA_OPAQUE = 0xFF000000;
		final int argb = (gray << 16) | (gray << 8) | (gray) | ALPHA_OPAQUE;*/




		int gray  =  clamp( middle ) >> FRACTION_BIT_SHIFT;

		/// remove discontinuity -
		/// map [0-255] onto [0-254 even, then 255-1 odd]  -  graphically: / -> /\
		//gray  =  (gray << 1) ^ ((int)((byte)gray) >> 31);
		//gray  =  (gray << 1) ^ ((gray << 24) >> 31);

		final int r = (palette_m[0][gray] + offset_m) & CHANNEL_MASK;
		final int g = (palette_m[1][gray] + offset_m) & CHANNEL_MASK;
		final int b = (palette_m[2][gray] + offset_m) & CHANNEL_MASK;

		final int ALPHA_OPAQUE = 0xFF000000;   /// IE5 needs opaque images, appletviewer doesnt
		final int argb = (r << 16) | (g << 8) | (b) | ALPHA_OPAQUE;



		return argb;
	}

	public int calculate( int[] array, int pos, int inc )
	{
		return calculate( array[pos-inc], array[pos], array[pos+inc] );
	}

	public void revolveColors()
	{
		offset_m += revolveRate_m;
	}


	private void setPalette( int[][] palette )
	{
		/// set color points

		final int     colorPointsShift           = 1;
		final int     colorPointsShiftComplement = 8 - colorPointsShift;
		final int[][] colorPoints                = new int[ 3 ][ (1 << colorPointsShift) + 1];
      {
         final int[]   color = new int[3];
   		for( int i = colorPoints[0].length;  i-- > 0; )
   		{
   			makeColor( randSeries_m, i << colorPointsShiftComplement, color );
   			colorPoints[0][i] = color[0];
   			colorPoints[1][i] = color[1];
   			colorPoints[2][i] = color[2];
   		}
   	}

		/// interpolate color points
      {
   		final int distBetweenColorPoints = palette[0].length >>> colorPointsShift;

   		for( int i = palette[0].length;  i-- > 0; )
   		{
   			/// calc last and next color point indexes
   			final int lastColorPoint = i >>> colorPointsShiftComplement;
   			final int nextColorPoint = lastColorPoint + 1;

   			/// set palette entry as linear interpolation of last and next color points
   			final int posBetweenColorPoints = i & (distBetweenColorPoints - 1);
   			palette[ 0 ][ i ] = interpolateLinearly( colorPoints[0][lastColorPoint], colorPoints[0][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
   			palette[ 1 ][ i ] = interpolateLinearly( colorPoints[1][lastColorPoint], colorPoints[1][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
   			palette[ 2 ][ i ] = interpolateLinearly( colorPoints[2][lastColorPoint], colorPoints[2][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
   		}
      }
	}

	private void makeColor( Random rands, int index, int[] color )
	{
		/*/// choose randomly
		int red   = rands.nextInt() & CHANNEL_MASK;
		int green = rands.nextInt() & CHANNEL_MASK;
		int blue  = rands.nextInt() & CHANNEL_MASK;

		/// analyse
		final int value      =  red + green + blue;
		final int saturation = Math.max( Math.max( red - value, green - value ), blue - value );

		/// desaturate

		/// make HSV value equal index
		red   = (red   * index * 3) / value;
		green = (green * index * 3) / value;
		blue  = (blue  * index * 3) / value;

		/// set color entries
		color[ 0 ]  =  red;//   & CHANNEL_MASK;
		color[ 1 ]  =  green;// & CHANNEL_MASK;
		color[ 2 ]  =  blue;//  & CHANNEL_MASK;*/



		final int value      = index;
		final int saturation = 100;

		int red   = value + (rands.nextInt() % saturation);
		int green = value + (rands.nextInt() % saturation);
		int blue  = value + (rands.nextInt() % saturation);

		red    =  clampColorChannel( red );
		green  =  clampColorChannel( green );
		blue   =  clampColorChannel( blue );

		/// set color entries
		color[ 0 ]  =  red;
		color[ 1 ]  =  green;
		color[ 2 ]  =  blue;
	}

	private int clampColorChannel( int channel )
	{
		if( channel > MAX_CHANNEL )
		{
			channel = MAX_CHANNEL;
		}
		else if( channel < MIN_CHANNEL )
		{
			channel = MIN_CHANNEL;
		}

		return channel;
	}

	private int interpolateLinearly( int left, int right, int pos, int range )
	{
		return  left + (((right - left) * pos) / range);
		//return  ( (left * leftDist) + (right * rightDist) ) / (rightDist - leftDist);
	}


/// fields -----------------------------------------------------------------------------------------
	public static final	KernelGrayToARGB	instance	= new KernelGrayToARGB();


	///
	private final	      Random	randSeries_m	   = new Random();

	/// color mapping
	private	            int	   offset_m		      = 0;
	private	            int	   revolveRate_m	   = 0;

	/// palette
	private static final int	   CHANNEL_MASK	   = 0x000000FF;
	private static final int	   MAX_CHANNEL		   = 255;
	private static final int	   MIN_CHANNEL		   = 0;
	private static final int	   PALETTE_LENGTH	   = 256;

	private		         int[][]	palette_m		   = new int[ 3 ][ PALETTE_LENGTH ];

}
