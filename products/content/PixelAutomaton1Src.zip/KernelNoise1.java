import java.util.Random;




class KernelNoise1
	extends Kernel3
{
/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		return ((rand_s.nextInt() & 0x3F) == 0) ? (rand_s.nextInt() & MAX_BITMASK) : middle;
	}


/// fields
	public static final		KernelNoise1	instance	= new KernelNoise1();

	private static final	Random			rand_s		= new Random();

}
