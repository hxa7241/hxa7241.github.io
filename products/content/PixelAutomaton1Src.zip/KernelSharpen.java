



class KernelSharpen
	extends Kernel3
{
/// implementation interface
	protected int calculate( int left, int middle, int right )
	{
		//final int out = (middle << 2) - ((left + (middle << 1) + right) >> 2);
		final int out = middle + ((middle - ((left + (middle << 1) + right) >> 2)) >> 0);

		return clamp( out );
		//return out;
	}


/// fields
	public static final	KernelSharpen	instance	= new KernelSharpen();

}
