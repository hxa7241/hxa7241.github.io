import java.util.Random;
import java.awt.Image;
import java.awt.image.PixelGrabber;




public class PixelAutomaton1
	extends AppletAnimated
{
/// construction
	/*protected PixelAutomaton1()
	{
		super();
	}*/


/// AppletAnimated overrides
	public void initDerived( final int width, final int height, final int[] pixels )
	{
		retrieveParameters();


		/// make palette
		palette_m = new int[ 256 ];
		setPalette( palette_m );

		/// draw start image
		drawStartImage( startImageName_m, pixels, width, height );

		/// create cells
		activeCells_m = new Cells( pixels, width, height );
		activeCells_m.setFailProbability( opFailProbability_m );

		/// init image interpolation
		interpolatedCells_m = new short[ width * height ];
		cellsIncrement_m    = new short[ width * height ];
		final int[] cells = activeCells_m.getCells();
		for( int i = interpolatedCells_m.length;  i-- > 0; )
		{
			interpolatedCells_m[ i ] = (short)(cells[ i ] << frameInterpolationPower_m);
			pixels[ i ] = palette_m[ interpolatedCells_m[ i ] >> frameInterpolationPower_m ];
		}


		/// init input support
		addKeyListener( userInputHandler_m );
	}

	/*public void startDerived()
	{
	}

	public void stopDerived()
	{
	}

	public void destroyDerived()
	{
	}*/

	protected void drawFrame( final int width, final int height, final int[] pixels )
	{
		/*(non interpolated version)
		activeCells_m.step();

		//activeCells_m.convertToARGB( pixels );

		final int[] cells = activeCells_m.getCells();

		/// mono value to rgba
		for( int i = pixels.length;  i-- > 0; )
		{
			int value = (cells[ i ] + 0x80) >> 8;

			/// clamp
			value &= ~(value >> 31);
			value += (((0xFF - value) >> 31) & (0xFF - value));

			pixels[ i ] = palette_m[ value ];
		}*/


		capFrameRate();


		/// handle new palette
		if( userInputHandler_m.isNewPalette() )
		{
			setPalette( palette_m );

			/// redraw here if paused
			if( userInputHandler_m.isPaused() )
			{
				for( int i = pixels.length;  i-- > 0; )
				{
					pixels[ i ] = palette_m[ interpolatedCells_m[ i ] >> frameInterpolationPower_m ];
				}
			}

			userInputHandler_m.resetNewPaletteKey();
		}


		/// if not paused
		if( !userInputHandler_m.isPaused() )
		{
			/// handle restart
			if( userInputHandler_m.isRestart() )
			{
				setPalette( palette_m );
				drawStartImage( userInputHandler_m.getKey(), pixels, width, height );

				activeCells_m.initialize( pixels );

				drawnFrameCount_m = 0;

				userInputHandler_m.resetRestartKey();
			}


			/// interpolate cell values
			for( int i = interpolatedCells_m.length;  i-- > 0; )
			{
				interpolatedCells_m[ i ] += cellsIncrement_m[ i ];
			}

			/// periodically take cell update step
			if( ( drawnFrameCount_m & ((1 << frameInterpolationPower_m) - 1) ) == 0 )
			{
				activeCells_m.step();
				final int[] cells = activeCells_m.getCells();

				/// set interpolation increment to move toward updated cell values over the next several frames
				for( int i = interpolatedCells_m.length;  i-- > 0; )
				{
					int value = (cells[ i ] + 0x80) >> 8;

					/// clamp
					value &= ~(value >> 31);
					value += (((0xFF - value) >> 31) & (0xFF - value));

					cellsIncrement_m[ i ] = (short)( value - (interpolatedCells_m[ i ] >> frameInterpolationPower_m) );
				}

				/*{
					final int stepCount = activeCells_m.getStepCount();
					if( ((stepCount-1) & 0x0F) == 0 )
					{
						System.out.print( "\n");
					}
					System.out.print( "" + stepCount + " " );
				}*/
			}

			/// draw interpolated cell values
			for( int i = pixels.length;  i-- > 0; )
			{
				pixels[ i ] = palette_m[ interpolatedCells_m[ i ] >> frameInterpolationPower_m ];
			}

			++drawnFrameCount_m;
		}

	}

	public String getAppletInfo()
	{
		return "PixelAutomaton1 class";
	}

	public String[][] getParameterInfo()
	{
		return  new String[][] { { IMAGE_PARAM_NAME,          "string",        "noise, rect, dot, or an image filename" },
		                         { FAIL_PARAM_NAME,           "float, 0-1",    "0.0 = no failures,  1.0 = always fail  (0.0 - 0.01 give best results...)" },
		                         { MAX_FRAME_RATE_PARAM_NAME, "int, 0-intmax", "max frames per second to allow" } };
	}


/// implementation
	private void capFrameRate()
	{
		final float frameRate = getFrameRate();
		if( frameRate != lastFrameRate_m )
		{
			final int timeDiff = (int)( (float)minFrameDuration_m - (1000.0f / frameRate) );
			waitTime_m += timeDiff;
			if( waitTime_m < 0 )
			{
				waitTime_m = 0;
			}
			lastFrameRate_m = frameRate;
			//System.out.println( "frameRate: " + frameRate + "  timeDiff: " + timeDiff + "  waitTime_m: " + waitTime_m );
		}

		if( waitTime_m > 0 )
		{
			final Thread thisThread = Thread.currentThread();
			try
			{
				/// round to tens of millisecs, and use periodically, since sleep only works to centisecs precision
				final int waitTimeMod10 = waitTime_m % 10;
				final int waitTime = waitTime_m - waitTimeMod10 + ((getFrameCount() % 10) < waitTimeMod10 ? 10 : 0);
				thisThread.sleep( waitTime );
			}
			catch( InterruptedException e )
			{
				thisThread.interrupt();
			}
		}
	}

	private void retrieveParameters()
	{
		/// get image name
		final String startImage = getParameter( IMAGE_PARAM_NAME );
		if( startImage != null )
		{
			startImageName_m = startImage;
		}

		/// get fail probability
		final String opFailProbabilityString = getParameter( FAIL_PARAM_NAME );
		if( opFailProbabilityString != null )
		{
			try
			{
				opFailProbability_m = Float.valueOf( opFailProbabilityString ).floatValue();
			}
			catch( NumberFormatException leaveAsDefaultInitValue )  {}
		}

		/// get max frame rate
		final String maxFrameRateString = getParameter( MAX_FRAME_RATE_PARAM_NAME );
		if( maxFrameRateString != null )
		{
			try
			{
				int maxFrameRate = Integer.parseInt( maxFrameRateString );
				if( maxFrameRate < 1 )
				{
					maxFrameRate = 1;
				}
				minFrameDuration_m = (int)(1000.0f / (float)maxFrameRate);
			}
			catch( NumberFormatException leaveAsDefaultInitValue )  {}
		}
	}

	private void drawStartImage( String s, int[] pixels, int width, int height )
	{
		if( s.equals("\n") )
		{
			s = startImageName_m;
		}

		/// noise
		if( s.equals( "noise" ) || s.equals("1") )
		{
			final Random  randSeries = new Random();

			//for( int i = pixels.length >> 2;  i-- > 0; )
			for( int i = pixels.length;  i-- > 0; )
			{
				/// randomly positioned white spots
				//pixels[ (randSeries.nextInt() & 0x7F) % pixels.length ] = 0xFFFFFFFF;

				/// fill with random values
				pixels[i] = randSeries.nextInt() | 0xFF000000;
			}
		}
		/// single centered pixel
		else if( s.equals( "dot" ) || s.equals("2") )
		{
			for( int i = pixels.length;  i-- > 0; )
			{
				pixels[i]  =  0xFFC0C0C0;
			}

			pixels[ (width/2) + ((height/2)*width) ]  =  0xFF404040;
		}
		/// dark square on light ground
		else if( s.equals( "rect" ) || s.equals("3") )
		{
			for( int i = pixels.length;  i-- > 0; )
			{
				pixels[i]  =  0xFFC0C0C0;
				//pixels[i]  =  0xFFFFFFFF;
			}

			/*for( int y = height;  y-- > 0; )
			{
				for( int x = (width/10);  x-- > 0; )
				{
					//pixels[x +y*width]  =  0xFF000000;
					final int g = (int)((254.0f / height) * y);
					pixels[x +y*width]  =  (g<<16) | (g<<8) | g | 0xFF000000;
				}
			}*/

			/*final Random  randSeries = new Random();
			for( int i = pixels.length >> 4;  i-- > 0; )
			{
				pixels[ (randSeries.nextInt() & 0x7F) % pixels.length ] = 0xFF000000;
			}*/

			for( int y = height*2/3;  y-- > (height/3); )
			{
				for( int x = width*2/3;  x-- > (width/3); )
				{
					pixels[x +y*width]  =  0xFF404040;
					//pixels[x +y*width]  =  0xFF000000;
				}
			}
		}
		else
		{
			loadStartImage( startImageName_m, width, height, pixels );
		}
	}

	private int[] loadStartImage( final String startImageName,
	                              final int width, final int height, int[] pixels )
	{
		if( pixels == null )
		{
			pixels = new int[ width * height ];
		}

		if( startImageName != null )
		{
			Image startImage = getImage( getDocumentBase(), startImageName );

			PixelGrabber pg = new PixelGrabber( startImage, 0, 0, width, height, pixels, 0, width );
			try
			{
				pg.grabPixels();
			}
			catch( InterruptedException e )
			{
				throw new Error( e.getMessage() );
			}

			/// convert to byte grayscale
			convertARGBtoByteGray( pixels, pixels );
		}

		return pixels;
	}

	private static void convertARGBtoByteGray( final int[] argbPixels, final int[] grayPixels )
	{
		for( int i = grayPixels.length; i-- != 0; )
		{
			final int argb = argbPixels[ i ];

			final int r = (argb >>> 16) & 0xFF;
			final int g = (argb >>>  8) & 0xFF;
			final int b = (argb       ) & 0xFF;

			final int gray = (r + g + b) / 3;

			grayPixels[ i ] = gray;
		}
	}


/// palette
	private static void setPalette( final int[] palette )
	{
		/// set color points
		final Random  randSeries                 = new Random();
		final int     colorPointsShift           = 3;
		final int     colorPointsShiftComplement = 8 - colorPointsShift;
		final int[][] colorPoints                = new int[ 3 ][ (1 << colorPointsShift) + 1];
		{
			final int[] color = new int[3];
			for( int i = colorPoints[0].length;  i-- > 0; )
			{
				makeColor( randSeries, i << colorPointsShiftComplement, color );
				colorPoints[0][i] = color[0];
				colorPoints[1][i] = color[1];
				colorPoints[2][i] = color[2];
			}
		}

		/// interpolate color points
		{
			final int distBetweenColorPoints = palette.length >>> colorPointsShift;

			for( int i = palette.length;  i-- > 0; )
			{
				/// calc last and next color point indexes
				final int lastColorPoint = i >>> colorPointsShiftComplement;
				final int nextColorPoint = lastColorPoint + 1;

				/// set palette entry as linear interpolation of last and next color points
				final int posBetweenColorPoints = i & (distBetweenColorPoints - 1);
				final int r = interpolateLinearly( colorPoints[0][lastColorPoint], colorPoints[0][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
				final int g = interpolateLinearly( colorPoints[1][lastColorPoint], colorPoints[1][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
				final int b = interpolateLinearly( colorPoints[2][lastColorPoint], colorPoints[2][nextColorPoint], posBetweenColorPoints, distBetweenColorPoints );
				palette[ i ] = (r << 16) | (g << 8) | (b) | 0xFF000000;

				// greyscale
				//palette[ i ] = (i << 16) | (i << 8) | (i) | 0xFF000000;
			}
		}
	}

	private static void makeColor( final Random rands, final int index, final int[] color )
	{
		/*/// choose randomly
		int red   = rands.nextInt() & CHANNEL_MASK;
		int green = rands.nextInt() & CHANNEL_MASK;
		int blue  = rands.nextInt() & CHANNEL_MASK;

		/// analyse
		final int value      =  red + green + blue;
		final int saturation = Math.max( Math.max( red - value, green - value ), blue - value );

		/// desaturate

		/// make HSV value equal index
		red   = (red   * index * 3) / value;
		green = (green * index * 3) / value;
		blue  = (blue  * index * 3) / value;

		/// set color entries
		color[ 0 ]  =  red;//   & CHANNEL_MASK;
		color[ 1 ]  =  green;// & CHANNEL_MASK;
		color[ 2 ]  =  blue;//  & CHANNEL_MASK;*/



		final int value      = index;
		final int saturation = 100;

		int red   = value + (rands.nextInt() % saturation);
		int green = value + (rands.nextInt() % saturation);
		int blue  = value + (rands.nextInt() % saturation);

		red    =  clampColorChannel( red );
		green  =  clampColorChannel( green );
		blue   =  clampColorChannel( blue );

		/// set color entries
		color[ 0 ]  =  red;
		color[ 1 ]  =  green;
		color[ 2 ]  =  blue;
	}

	private static int clampColorChannel( int channel )
	{
		if( channel > 0xFF )
		{
			channel = 0xFF;
		}
		else if( channel < 0 )
		{
			channel = 0;
		}

		return channel;
	}

	private static int interpolateLinearly( int left, int right, int pos, int range )
	{
		return  left + (((right - left) * pos) / range);
		//return  ( (left * leftDist) + (right * rightDist) ) / (rightDist - leftDist);
	}


/// fields -----------------------------------------------------------------------------------------
	/// tag parameters
	private					String	startImageName_m		= "";
	private					float	opFailProbability_m		= 0.0f;
	private					int		minFrameDuration_m		= 33;

	private static final	String	IMAGE_PARAM_NAME			= "StartImage";
	private static final	String	FAIL_PARAM_NAME				= "OpFailProbability";
	private static final	String	MAX_FRAME_RATE_PARAM_NAME	= "MaxFrameRate";


	/// image calculator
	private			Cells	activeCells_m;

	private int     drawnFrameCount_m;
	private int     frameInterpolationPower_m = 4;
	private short[] interpolatedCells_m;
	private short[] cellsIncrement_m;

	private int[]   palette_m;


	private float lastFrameRate_m;
	private int   waitTime_m;



	/*
	possible parameterisations:
		palette things (KernelGrayToARGB)
		start image (PixelAutomaton1)
		start image size (PixelAutomaton1)
		operations probabilities (Cells)

		sharpen clamping or not (KernelSharpen)
		dilate limitation (KernelDilate)
		erode limitation (KernelErode)
	*/


	/// input
	private UserInput userInputHandler_m = new UserInput();

	private static class UserInput
		implements java.awt.event.KeyListener
	{
	/// queries
		public boolean isPaused()
		{
			return isPaused_m;
		}

		public boolean isRestart()
		{
			return isRestart_m;
		}

		public boolean isNewPalette()
		{
			return isNewPalette_m;
		}

		public String getKey()
		{
			return key_m;
		}


	/// commands
		public void resetRestartKey()
		{
			key_m       = "";
			isRestart_m = false;
		}

		public void resetNewPaletteKey()
		{
			isNewPalette_m = false;
		}


	/// event handlers
		public void keyPressed( java.awt.event.KeyEvent e )
		{
			final char c = e.getKeyChar();

			key_m       = "" + c;
			isPaused_m ^= (c == ' ');
		}

		public void keyTyped( java.awt.event.KeyEvent e )
		{
			final char c = e.getKeyChar();

			key_m          = "" + c;
			isRestart_m    = (c == '\n') || (c == '1') || (c == '2') || (c == '3');
			isNewPalette_m = (c == 'p');
		}

		public void keyReleased( java.awt.event.KeyEvent e ) {}


		private String  key_m;
		private boolean isPaused_m;
		private boolean isRestart_m;
		private boolean isNewPalette_m;
	}

}
