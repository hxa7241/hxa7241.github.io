///  artifex@computer.org  ///




/**
 * Simplest fastest random number generator.
 *
 * a signed dword in the range [MIN_VALUE, MAX_VALUE],
 * or a float in the range 0 to 1 (i would think [0, 1) but not sure...)
 *
 * <br/><br/>Not very random, but it is fast.
 *
 * <br/><br/><cite>'Numerical Recipes In C', ch7 p284-285</cite>
 * <br/><a href="www.nr.com">www.nr.com</a>
 */
final public class RandomFast
{
/// construction
	public RandomFast()
	{
		this( (int)System.currentTimeMillis() );
	}

	public RandomFast( final int seed )
	{
		random_m = seed;
	}


/// commands
	final public void setSeed( final int seed )
	{
		random_m = seed;
	}

	final public void next()
	{
		random_m = 1664525 * random_m + 1013904223;
	}


/// queries
	final public int getInt()
	{
		return random_m;
	}

	final public float getFloat()
	{
		final int itemp = 0x3F800000 | (0x007FFFFF & random_m);
		return java.lang.Float.intBitsToFloat( itemp ) - 1.0f;
	}


/// fields
	/// current value of sequence and seed of the rest of the sequence
	private int random_m;

};




/*
test sequence of 32-bit values (hex):
00000000, 3C6EF35F, 47502932, D1CCF6E9,
AAF95334, 6252E503, 9F2EC686, 57FE6C2D,
A3D95FA8, 81FDBEE7, 94F0AF1A, CBF633B1
*/
