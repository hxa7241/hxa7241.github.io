/*------------------------------------------------------------------------------

   HXA7241 Image library.
   Copyright (c) 2005-2007,  Harrison Ainsworth / HXA7241.

   http://www.hxa7241.org/

------------------------------------------------------------------------------*/


#ifndef hxa7241_image_p
#define hxa7241_image_p


#include "Primitives.hpp"




namespace hxa7241_image
{
   using namespace hxa7241;

   //namespace ppm;
   //namespace rgbe;
   //namespace quantizing
}




#endif//hxa7241_image_p
