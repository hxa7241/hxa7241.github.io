//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  CMemMapFile.cpp
//------------------------------------------------




#include "stdwin.h"

#include "CMemMapFile.h"








/// standard class management //////////////////////////////////////////////////////////////////////

/*CMemMapFile::CMemMapFile
(
)
{
}*/


/*inline
CMemMapFile::~CMemMapFile
(
)
{

   Destruct();

}*/


CMemMapFile::CMemMapFile
(
   const CMemMapFile&
)  /// private
{
}


CMemMapFile&  CMemMapFile::operator=
(
   const CMemMapFile&
)  /// private
{
   return  *this;
}








/// new temporary
/*CMemMapFile::CMemMapFile
(
   DWORD    LengthInBytes,
   LPCTSTR  pNamePrefix,
   DWORD    Attributes
)
{

   InvalidateAllMembers();
   ConstructTemp( pNamePrefix,  LengthInBytes,  Attributes,  0 );

}


CMemMapFile::CMemMapFile
(
   DWORD    LengthInBytes,
   LPCTSTR  pNamePrefix
)
{

   InvalidateAllMembers();
   ConstructTemp( LengthInBytes,  pNamePrefix,  FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,  0 );

}


CMemMapFile::CMemMapFile
(
   DWORD                   LengthInBytes,
   LPCTSTR                 pNamePrefix,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)
{

   InvalidateAllMembers();
   ConstructTemp( LengthInBytes,  pNamePrefix,  Attributes,  pSecurity );

}*/


/// new
/*CMemMapFile::CMemMapFile
(
   LPCTSTR  pFilePathName,
   DWORD    LengthInBytes,
   BOOL     OverwriteExisting,
   DWORD    Attributes
)
{

   InvalidateAllMembers();
   ConstructNew( pFilePathName,  LengthInBytes,  OverwriteExisting,  Attributes,  0 );

}


CMemMapFile::CMemMapFile
(
   LPCTSTR  pFilePathName,
   DWORD    LengthInBytes,
   BOOL     OverwriteExisting
)
{

   InvalidateAllMembers();
   ConstructNew( pFilePathName,  LengthInBytes,  OverwriteExisting,  FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,  0 );

}


CMemMapFile::CMemMapFile
(
   LPCTSTR                 pFilePathName,
   DWORD                   LengthInBytes,
   BOOL                    OverwriteExisting
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)
{

   InvalidateAllMembers();
   ConstructNew( pFilePathName,  LengthInBytes,  OverwriteExisting,  Attributes,  pSecurity );

}*/


/*/// open
inline
CMemMapFile::CMemMapFile
(
   LPCTSTR  pFilePathName,
   BOOL     ReadOnly,
   DWORD    Attributes
)
{

   InvalidateAllMembers();
   ConstructOpen( pFilePathName,  ReadOnly,  Attributes,  0 );

}*/


/*CMemMapFile::CMemMapFile
(
   LPCTSTR  pFilePathName,
   BOOL     ReadOnly
)
{

   InvalidateAllMembers();
   ConstructOpen( pFilePathName,  ReadOnly,  FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,  0 );

}


CMemMapFile::CMemMapFile
(
   LPCTSTR                 pFilePathName,
   BOOL                    ReadOnly,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)
{

   InvalidateAllMembers();
   ConstructOpen( pFilePathName,  ReadOnly,  Attributes,  pSecurity );

}*/








/// construction ///////////////////////////////////////////////////////////////////////////////////

/// specialised construction -----------------------------------------------------------------------

/*VOID  CMemMapFile::ConstructTemp
(
   LPCTSTR                 pNamePrefix,
   DWORD                   LengthInBytes,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)  /// pseudo static
{

   /// set the 'temp' specific choices
   TCHAR  FilePathName[ MAX_PATH + 1 ];
   FilePathName[ MAX_PATH ]  =  TEXT('\0');
   MakeTempFilePathName( pNamePrefix, FilePathName );

   DWORD  Access       =  GENERIC_READ | GENERIC_WRITE;
   DWORD  Create       =  OPEN_ALWAYS;
          Attributes  &=  ~FILE_ATTRIBUTE_READONLY;
          Attributes  |=  FILE_FLAG_DELETE_ON_CLOSE;


   /// call the general constructor
   Construct( FilePathName,  Access,  Create,  Attributes,  pSecurity,  LengthInBytes );

}


VOID  CMemMapFile::MakeTempFilePathName
(
   LPCTSTR  pNamePrefix,
   LPTSTR   pFilePathName   /// length needs to be >= MAX_PATH
)  /// static
{

   BOOL  Succeeded  =  FALSE;


   /// get temp path
   TCHAR  TempPath[ MAX_PATH + 1 ];
   TempPath[ MAX_PATH ]  =  TEXT('\0');

   const DWORD  TempPathLength  =  ::GetTempPath( MAX_PATH, TempPath );

   if( ( TempPathLength <= MAX_PATH )  &&  ( TempPathLength != 0 ) )
   {
      /// get temp path+name
      /// ( creates then closes a file with the temp pathname )
      if( ::GetTempFileName( TempPath, pNamePrefix, 0, pFilePathName ) )
      {
         Succeeded  =  TRUE;
      }
   }


   if( !Succeeded )
   {
      throw  ::GetLastError();
   }

}*/


/*VOID  CMemMapFile::ConstructNew
(
   LPCTSTR                 pFilePathName,
   DWORD                   LengthInBytes,
   BOOL                    OverwriteExisting,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)  /// pseudo static
{

   /// set the 'new' specific choices
   DWORD  Access       =  GENERIC_READ | GENERIC_WRITE;
   DWORD  Create       =  OverwriteExisting  ?  CREATE_ALWAYS : CREATE_NEW;
          Attributes  &=  ~FILE_ATTRIBUTE_READONLY;
          Attributes  &=  ~FILE_FLAG_DELETE_ON_CLOSE;


   /// call the general constructor
   Construct( pFilePathName,  Access,  Create,  Attributes,  pSecurity,  LengthInBytes );

}*/


VOID  CMemMapFile::ConstructOpen
(
   LPCTSTR                 pFilePathName,
   BOOL                    ReadOnly,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity
)  /// pseudo static
{

   /// set the 'open' specific choices
   DWORD  Access       =  ReadOnly  ?  GENERIC_READ  :  ( GENERIC_READ | GENERIC_WRITE );
   DWORD  Create       =  OPEN_EXISTING;
          Attributes  &=  ~FILE_FLAG_DELETE_ON_CLOSE;


   /// call the general constructor
   Construct( pFilePathName,  Access,  Create,  Attributes,  pSecurity,  0 );

}




/// general construction ---------------------------------------------------------------------------

///-------------------------------------------------------------------------------------------------
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    Set each member to a defined state that indicates it is unused.
///-------------------------------------------------------------------------------------------------

VOID  CMemMapFile::InvalidateAllMembers
(
)
{

   /// set file members to defined invalid values
   FileHandle_m       =  INVALID_HANDLE_VALUE;
   ::FillMemory( static_cast<VOID*>(FilePathName_m),  sizeof(FilePathName_m),  BYTE(0xFF) );
   FilePathName_m[ MAX_PATH ]  =  TEXT('\0');
   LengthInBytes_m    =  0;
   IsReadOnly_m       =  FALSE;

   /// set map/view members to defined invalid values
   MapHandle_m        =  0;
   MemoryAsVoidPtr_m  =  0;

}


///-------------------------------------------------------------------------------------------------
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    General overall construction function - construct the file, then the mapping,
///               and destruct and throw if something fails.
///-------------------------------------------------------------------------------------------------

VOID  CMemMapFile::Construct
(
   LPCTSTR                 pFilePathName,
   DWORD                   Access,
   DWORD                   Create,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity,
   DWORD                   LengthInBytes
)
{

   BOOL  CompletedAllSteps  =  FALSE;


   /// construct file part
   if( ConstructFile( pFilePathName, Access, Create, Attributes, pSecurity, LengthInBytes ) )
   {
      /// construct map-view part
      if( ConstructMapView( FileHandle_m, IsReadOnly_m, LengthInBytes_m ) )
      {
         CompletedAllSteps  =  TRUE;
      }
   }


   if( !CompletedAllSteps )
   {
      /// save error code
      const DWORD  WinErrorCode  =  ::GetLastError();

      /// undo partial work
      Destruct();

      /// throw exception
      throw  WinErrorCode;
   }

}




///-------------------------------------------------------------------------------------------------
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    Construct a win32 file, and set the class members that represent it.
///               Destructs the file and leaves the members as they were on entry if something fails.
///-------------------------------------------------------------------------------------------------

BOOL  CMemMapFile::ConstructFile
(
   LPCTSTR                 pFilePathName,
   DWORD                   Access,
   DWORD                   Create,
   DWORD                   Attributes,
   LPSECURITY_ATTRIBUTES   pSecurity,
   DWORD                   LengthInBytes
)
{

   BOOL  CompletedAllSteps  =  FALSE;


   /// call windows to create the file
   HANDLE  FileHandle  =  ::CreateFile( pFilePathName,  Access,  0,  pSecurity,  Create,  Attributes,  NULL );
   if( FileHandle  !=  INVALID_HANDLE_VALUE )
   {
      /// either set or get the length of the file
      if( LengthInBytes != 0 )
      {
         if( SetFileLengthInternal( FileHandle,  LengthInBytes ) )
         {
            CompletedAllSteps  =  TRUE;
         }
      }
      else
      {
         if( GetFileLengthInternal( FileHandle,  LengthInBytes ) )
         {
            CompletedAllSteps  =  TRUE;
         }
      }
   }


   if( CompletedAllSteps )
   {
      /// set member variables
      if(     ( ::lstrlen( FilePathName_m )  >=  ::lstrlen( pFilePathName ) )
          &&  ( ::lstrcpy( FilePathName_m,  pFilePathName )  !=  0          )  )
      {
         FileHandle_m     =  FileHandle;
         LengthInBytes_m  =  LengthInBytes;
         IsReadOnly_m     =  !( BOOL( Access & GENERIC_WRITE ) );
      }
      else
      {
         CompletedAllSteps  =  FALSE;
      }
   }

   if( !CompletedAllSteps )
   {
      /// save error code
      const DWORD  WinErrorCode  =  ::GetLastError();
      /// undo partial work
      DestructFile( FileHandle );
      /// restore error code
      ::SetLastError( WinErrorCode );
   }

   return  CompletedAllSteps;

}


///-------------------------------------------------------------------------------------------------
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    Construct the win32 mapping and view, and set the class members that represent
///               them.
///               Destructs the mapping and view, and leaves the members as they were on entry if
///               something fails.
///               If the file length is zero, then map/view creation will fail, so the map/view
///               members are set to their defined unused state instead.
///-------------------------------------------------------------------------------------------------

BOOL  CMemMapFile::ConstructMapView
(
   HANDLE   FileHandle,
   BOOL     ReadOnly,
   DWORD    FileLength
)
{

   BOOL  CompletedAllSteps  =  FALSE;


   /// check file
   if( FileHandle != INVALID_HANDLE_VALUE )
   {
      HANDLE  MapHandle        =  0;
      VOID*   MemoryAsVoidPtr  =  0;

      /// memory mapping doesnt accept zero length files
      if( FileLength != 0 )
      {
         const DWORD  MapAccess  =  ReadOnly  ?  PAGE_READONLY : PAGE_READWRITE;

         /// create mapping
         MapHandle  =  ::CreateFileMapping( FileHandle, NULL, MapAccess, 0,0, NULL );
         if( MapHandle != 0 )
         {
            const DWORD  ViewAccess  =  ReadOnly  ?  FILE_MAP_READ : FILE_MAP_WRITE;

            /// create view
            MemoryAsVoidPtr  =  ::MapViewOfFile( MapHandle, ViewAccess, 0,0,0 );
            if( MemoryAsVoidPtr != 0 )
            {
               CompletedAllSteps  =  TRUE;
            }
         }
      }
      else
      {
         CompletedAllSteps  =  TRUE;
      }


      if( CompletedAllSteps )
      {
         /// set member variables
         MapHandle_m        =  MapHandle;
         MemoryAsVoidPtr_m  =  MemoryAsVoidPtr;
      }
      else
      {
         /// save error code
         const DWORD  WinErrorCode  =  ::GetLastError();
         /// undo partial work
         DestructMapView( MemoryAsVoidPtr,  MapHandle );
         /// restore error code
         ::SetLastError( WinErrorCode );
      }
   }


   return  CompletedAllSteps;

}




/// destruction ////////////////////////////////////////////////////////////////////////////////////

///-------------------------------------------------------------------------------------------------
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    Destructs all resources.
///-------------------------------------------------------------------------------------------------

//inline
VOID  CMemMapFile::Destruct
(
)
{

   DestructMapView( MemoryAsVoidPtr_m, MapHandle_m );
   DestructFile( FileHandle_m );

}


VOID  CMemMapFile::DestructMapView
(
   VOID*&   MemoryAsVoidPtr,   /// out
   HANDLE&  MapHandle          /// out
)
{

   //BOOL  Succeeded  =  TRUE;

   if( MemoryAsVoidPtr  !=  0 )
   {
      if( ::UnmapViewOfFile( MemoryAsVoidPtr ) )
      {
         MemoryAsVoidPtr  =  0;
      }
      #ifdef DEBUG
      else
      {
         DWORD  WinErrorCode  =  ::GetLastError();   /// trace info
         //Succeeded  =  FALSE;
      }
      #endif//DEBUG
   }

   if( MapHandle  !=  0 )
   {
      if( ::CloseHandle( MapHandle ) )
      {
         MapHandle  =  0;
      }
      #ifdef DEBUG
      else
      {
         DWORD  WinErrorCode  =  ::GetLastError();   /// trace info
         //Succeeded  =  FALSE;
      }
      #endif//DEBUG
   }

   //return  Succeeded;

}


VOID  CMemMapFile::DestructFile
(
   HANDLE&  FileHandle   /// out
)
{

   //BOOL  Succeeded  =  TRUE;

   if( FileHandle != INVALID_HANDLE_VALUE )
   {
      if( ::CloseHandle( FileHandle ) )
      {
         FileHandle  =  INVALID_HANDLE_VALUE;
      }
      #ifdef DEBUG
      else
      {
         DWORD  WinErrorCode  =  ::GetLastError();   /// trace info
         //Succeeded  =  FALSE;
      }
      #endif//DEBUG
   }

   //return  Succeeded;

}




/// file length get/set ////////////////////////////////////////////////////////////////////////////

BOOL  CMemMapFile::GetFileLengthInternal
(
   HANDLE   FileHandle,
   DWORD&   LengthInBytes
)  /// static
{

   BOOL  Succeeded  =  FALSE;

   DWORD  ByteLength  =  ::GetFileSize( FileHandle,  0 );
   if( ByteLength  !=  0xFFFFFFFF )
   {
      LengthInBytes  =  ByteLength;
      Succeeded      =  TRUE;
   }

   return  Succeeded;


   /* old version
   DWORD  LoDWord;
   DWORD  HiDWord;

   LoDWord  =  ::GetFileSize( FileHandle,  &HiDWord );


   if(  ( LoDWord == 0xFFFFFFFF )  &&  ( ::GetLastError() != NO_ERROR )  )
   {
      return  FALSE;
   }
   else if( HiDWord  !=  0 )
   {
      ::SetLastError( NO_ERROR );

      return  FALSE;
   }
   else
   {
      LengthInBytes  =  LoDWord;

      return  TRUE;
   }*/

}


BOOL  CMemMapFile::SetFileLengthInternal
(
   HANDLE   ,//FileHandle,
   DWORD    //LengthInBytes
)  /// static
{

   BOOL  Succeeded  =  FALSE;

   /*if( ::SetFilePointer( FileHandle, (LONG)LengthInBytes, NULL, FILE_BEGIN )  !=  0xFFFFFFFF )
   {
      if( ::SetEndOfFile( FileHandle )  !=  FALSE )
      {
         Succeeded  =  TRUE;
      }
   }*/

   return  Succeeded;

}








/// public interface ///////////////////////////////////////////////////////////////////////////////

/*inline
VOID*  CMemMapFile::GetMemory
(
)   const
{

   return  MemoryAsVoidPtr_m;

}


inline
DWORD  CMemMapFile::GetLengthInBytes
(
)   const
{

   return  LengthInBytes_m;

}*/


/* too hard to make exception safe
VOID  CMemMapFile::SetLengthInBytes
(
   DWORD    LengthInBytes
)
{

   /// un-view, un-map
   if( DestructMapView() )
   {
      /// change length
      SetFileLengthInternal( FileHandle_m,  LengthInBytes ) )

         /// re-map, re-view
         if( ConstructMapView( FileHandle_m, IsReadOnly_m ) )
         {
            CompletedAllSteps  =  TRUE;
         }
   }


   if( !CompletedAllSteps )
   {
      DWORD  WinErrorCode  =  ::GetLastError();   /// trace info
      throw  WinErrorCode;
      //throw  TEXT("Couldn't set length");
   }

}*/


/*LPTSTR  CMemMapFile::GetFilePathName
(
   LPTSTR   pFileName
)  const
{

   return  ::lstrcpy( pFileName,  FilePathName_m );

}


BOOL  CMemMapFile::IsReadOnly
(
)   const
{

   return  IsReadOnly_m;

}*/
