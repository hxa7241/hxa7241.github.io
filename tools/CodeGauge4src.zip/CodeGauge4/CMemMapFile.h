//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  CMemMapFile.h
//------------------------------------------------




#ifndef  included_CMemMapFile_h
#define  included_CMemMapFile_h








///-------------------------------------------------------------------------------------------------
///
///   Author:     HA
///   Date:       16/01/99
///   Purpose:    Encapsulate usage of a Win32 memory-mapped file.
///               There are constructors for:
///               a). creating a new temporary file,
///               b). creating a new file,
///               c). opening an existing file.
///               Attributes, flags and security params as for the Win32 function ::CreateFile().
///               If construction cannot succeed an exception will be thrown (either a LPCTSTR or
///               a DWORD).
///               Access to the file's content is through a VOID*, obtained from GetMemory(), and
///               the size from GetLengthInBytes().
///   Implemen-   The construction sequence passes through two main stages:
///   tation:     1). constructors, then ConstructTemp/ConstructNew/ConstructOpen - this stage in
///               essence acts like a set of default parameters, they fill in a general set of
///               params that are passed to the next, general stage of construction.
///               2). Construct, ConstructFile, ConstructMapView - this stage constructs a general
///               memory mapped file, first the file then the map-view. Each function either
///               succeeds and sets its relevant member variables to a valid state, or fails and
///               leaves the members as they were and releases any resources it has aquired in its
///               course of operation. If this stage cannot succeed completely an exception is
///               thrown.
///   Invariants: FileHandle_m        - validly refers to a file resource
///               MapHandle_m
///               MemoryAsVoidPtr_m   - both validly refer to memory mapping resources,
///                                     or, if file length == 0, both equal 0 - since no attempt should
///                                     sensibly made to address the memory (length being zero) this is ok.
///               FilePathName_m[]    - equals the file's full pathname,
///                                     contains a null char
///               LengthInBytes_m     - equals the file's length in bytes,
///                                     ( must be > 0 ( for file mapping ) )
///               IsReadOnly_m        - equals the file's read-only permission
///
///-------------------------------------------------------------------------------------------------

class CMemMapFile
{

public: ///-----------------------------------------------------------------------------------------

   /// standard object management ----------------

                     //CMemMapFile ();
                     ~CMemMapFile ();
                     //CMemMapFile ( const CMemMapFile& );                  /// private
                     //CMemMapFile&  operator= ( const CMemMapFile& );      ///


                     /// new temporary ( fdwAttrsAndFlags as in Win32 ::CreateFile() )
                     //CMemMapFile ( DWORD LengthInBytes,  LPCTSTR pNamePrefix,  DWORD fdwAttrsAndFlags );
                     //CMemMapFile ( DWORD LengthInBytes,  LPCTSTR pNamePrefix );
                     //CMemMapFile ( DWORD LengthInBytes,  LPCTSTR pNamePrefix,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );

                     /// new ( " )
                     //CMemMapFile ( LPCTSTR pFilePathName,  DWORD LengthInBytes,  BOOL OverwriteExisting,  DWORD fdwAttrsAndFlags );
                     //CMemMapFile ( LPCTSTR pFilePathName,  DWORD LengthInBytes,  BOOL OverwriteExisting );
                     //CMemMapFile ( LPCTSTR pFilePathName,  DWORD LengthInBytes,  BOOL OverwriteExisting,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );

                     /// open ( " )
                     CMemMapFile ( LPCTSTR pFilePathName,  BOOL ReadOnly,  DWORD fdwAttrsAndFlags );
                     //CMemMapFile ( LPCTSTR pFilePathName,  BOOL ReadOnly );
                     //CMemMapFile ( LPCTSTR pFilePathName,  BOOL ReadOnly,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );

   /// -------------------------------------------


   /// file content
            VOID*    GetMemory ()                                                            const;

   /// file length
            DWORD    GetLengthInBytes ()                                                     const;
   //       VOID     SetLengthInBytes ( DWORD );

   /// file name
//            LPTSTR   GetFilePathName ( LPTSTR )                                              const;

   /// file access permission
//            BOOL     IsReadOnly ()                                                           const;


protected: ///--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--

   /// construction implementation
            /// pseudo static
//            VOID     ConstructTemp ( LPCTSTR pNamePrefix,  DWORD LengthInBytes,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );
//   static   VOID     MakeTempFilePathName ( LPCTSTR pNamePrefix,  LPTSTR pFilePathName );   /// pFilePathName length needs to be >= MAX_PATH
//            VOID     ConstructNew  ( LPCTSTR pFilePathName,  DWORD LengthInBytes,  BOOL OverwriteExisting,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );
            VOID     ConstructOpen ( LPCTSTR pFilePathName,  BOOL ReadOnly,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity );

            VOID     InvalidateAllMembers ();
            VOID     Construct     ( LPCTSTR pFilePathName,  DWORD Access,  DWORD Create,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity,  DWORD LengthInBytes );
            BOOL     ConstructFile ( LPCTSTR pFilePathName,  DWORD Access,  DWORD Create,  DWORD fdwAttrsAndFlags,  LPSECURITY_ATTRIBUTES pSecurity,  DWORD LengthInBytes );
            BOOL     ConstructMapView ( HANDLE  FileHandle,  BOOL ReadOnly,  DWORD FileLength );

   /// destruction implementation
            VOID     Destruct ();
   static   VOID     DestructMapView ( VOID*& MemoryAsVoidPtr,  HANDLE& MapHandle );
   static   VOID     DestructFile    ( HANDLE& FileHandle );

   /// file length get/set
   static   BOOL     GetFileLengthInternal ( HANDLE FileHandle,  DWORD& LengthInBytes );
   static   BOOL     SetFileLengthInternal ( HANDLE FileHandle,  DWORD LengthInBytes );


private: ///////////////////////////////////////////////////////////////////////////////////////////

   /// file things
            HANDLE   FileHandle_m;
            TCHAR    FilePathName_m[ MAX_PATH + 1 ];
            DWORD    LengthInBytes_m;
            BOOL     IsReadOnly_m;

   /// map and view things
            HANDLE   MapHandle_m;
            VOID*    MemoryAsVoidPtr_m;


   /// disallowed
                           CMemMapFile ( const CMemMapFile& );
            CMemMapFile&   operator= ( const CMemMapFile& );

};







/// INLINES ///

inline
CMemMapFile::~CMemMapFile
(
)
{

   Destruct();

}


/// open
inline
CMemMapFile::CMemMapFile
(
   LPCTSTR  pFilePathName,
   BOOL     ReadOnly,
   DWORD    Attributes
)
{

   InvalidateAllMembers();
   ConstructOpen( pFilePathName,  ReadOnly,  Attributes,  0 );

}


inline
VOID*  CMemMapFile::GetMemory
(
)   const
{

   return  MemoryAsVoidPtr_m;

}


inline
DWORD  CMemMapFile::GetLengthInBytes
(
)   const
{

   return  LengthInBytes_m;

}








#endif//included_CMemMapFile_h
