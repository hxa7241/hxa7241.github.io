//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  CodeGauge.cpp
//------------------------------------------------




#include "stdwin.h"
#include <shellapi.h>   /// drag and drop things

#include "CodeGauge.h"

#include "resource.h"
#include "CMemMapFile.h"








/// the instance
//HINSTANCE    TheInstance_m  =  0;
HWND         hWndThis_m     =  0;




/// measuring thread handle
HANDLE       MeasuringThreadHandle_m  =  NULL;

/// measurements
DWORD        NoOfCodeLinesTotal_m   =  0;
DWORD        NoOfFilesTotal_m       =  0;

/// message IDs
const UINT   IDM_CPP                =  UINT(0xF000) - UINT(1);
const UINT   IDM_JAVA               =  UINT(0xF000) - UINT(2);
const UINT   IDM_CS                 =  UINT(0xF000) - UINT(3);
const UINT   IDM_ALL                =  UINT(0xF000) - UINT(4);
const UINT   IDM_COPY               =  UINT(0xF000) - UINT(5);
const UINT   IDM_ABOUT              =  UINT(0xF000) - UINT(6);
//const UINT   WM_COMMAND_LINE        =  WM_USER + UINT(1);

/// menu strings
const TCHAR  kCppMenuString_s[]     = TEXT("C+&+ files");
const TCHAR  kJavaMenuString_s[]    = TEXT("&Java files");
const TCHAR  kCsMenuString_s[]      = TEXT("C&# files");
const TCHAR  kAllMenuString_s[]     = TEXT("&All 3 types");
const TCHAR  kCopyMenuString_s[]    = TEXT("Cop&y");
const TCHAR  kAboutMenuString_s[]   = TEXT("A&bout...");

/// window title
const TCHAR  kCppTitleString_s[]    =  TEXT("C++Gauge");
const TCHAR  kJavaTitleString_s[]   =  TEXT("JavaGauge");
const TCHAR  kCsTitleString_s[]     =  TEXT("C#Gauge");
const TCHAR  kAllTitleString_s[]    =  TEXT("CodeGauge");
const TCHAR* pTitleString_m         =  kAllTitleString_s;

/// display labels
const TCHAR  kLinesOfCodeLabel_s[]  =  TEXT("Lines of code:");

/// error messages
const TCHAR  kErrorMessage_s[]      =  TEXT("Something interrupted normal working");

/// credit variables and constants
const TCHAR  kAboutBoxTitle_s[]     =  TEXT("About CodeGauge");
const TCHAR  kAboutBoxMessage_s[]   =  TEXT("CodeGauge counts lines of code in C++, Java or C#.\n\n1) choose a language filter with the right-click menu.\n2) drag and drop files or folders onto CodeGauge.\n\n* folders are looked in recursively for source files.\n\n* source files with the following name extensions are recognized:\nc cpp cxx h hpp hxx, java, cs\ndepending on which language filter is chosen.\n\n* a line is counted as code if it contains a char that is not:\na space, tab, return, newline, brace, parenthesis, or part of a\ncomment.\n\n---\n\nCodeGauge version 4.5\nCopyright (c) 1999-2006, Harrison Ainsworth / HXA7241.\n\nhttp://www.hxa7241.org/");








/// windows stuff //////////////////////////////////////////////////////////////////////////////////

int WINAPI  WinMain
(
   HINSTANCE  hInst,
   HINSTANCE  ,//hPrevInst,
   char*      ,//cmdParam,
   int        //cmdShow
)
{

   //TheInstance_m  =  hInst;


   int   ReturnValue;
   HWND  hDialog  =  ::CreateDialog( hInst,  MAKEINTRESOURCE(IDD_CODEGAUGE_DLG),  0,  DLGPROC(DialogProc) );

   if( hDialog )
   {
      AddMenuItems( hDialog );

      MSG  msg;
      int  status;

      while( status = ::GetMessage( &msg, 0, 0, 0 ),
             ( status != 0 )  &&  ( status != -1 )   )
      {
         //if( !::IsDialogMessage( hDialog, &msg ) )
         {
            ::TranslateMessage( &msg );
            ::DispatchMessage ( &msg );
         }
      }

      ReturnValue  =  ( status != int(-1) )  ?  int(msg.wParam)  :  int(-1);
   }
   else
   {
      ShowErrorMessage( 0,  ::GetLastError(),  LPCTSTR(0) );

      ReturnValue  =  int(1);
   }


   return  ReturnValue;

}




BOOL CALLBACK  DialogProc
(
   HWND    hWnd,
   UINT    Message,
   WPARAM  wParam,
   LPARAM  lParam
)
{

   BOOL  DidHandleMessage  =  TRUE;

   try
   {
      switch( Message )
      {
         case WM_INITDIALOG :
         {
            InitialiseDialog( hWnd );
            break;
         }
         case WM_SETCURSOR :
         {
            OnSetCursor( wParam, lParam );
            break;
         }
         case WM_LBUTTONDOWN :
         {
            OnPrimaryClick( hWnd,  lParam );
            break;
         }
         case WM_RBUTTONDOWN :
         {
            OnSecondaryClick( hWnd,  lParam );
            break;
         }
         case WM_KEYDOWN :
         {
            const bool isRepeat = ((lParam >> 30) & 1) == 1;
            switch( TCHAR(wParam) )
            {
            case TEXT('C') :
               if( !isRepeat )
               {
                  OnCopy( hWnd );
               }
               break;
            default :
               DidHandleMessage = FALSE;
               break;
            }
            break;
         }
         case WM_HELP :
         {
            OnAbout( hWnd );
            break;
         }
         case WM_SYSCOMMAND :
         case WM_COMMAND    :
         {
            switch( wParam )
            {
               case  IDM_CPP   :
               case  IDM_JAVA  :
               case  IDM_CS    :
               case  IDM_ALL   :  OnChangeFileType( hWnd, wParam );  break;
               case  IDM_COPY  :  OnCopy( hWnd );                    break;
               case  IDM_ABOUT :  OnAbout( hWnd );                   break;
               default         :  DidHandleMessage  =  FALSE;        break;
            }
            break;
         }
         case WM_DROPFILES :
         {
            OnDropFiles( hWnd,  HANDLE(wParam) );
            break;
         }
         /*case WM_COMMAND_LINE :
         {
            OnCommandLine( hWnd,  LPCTSTR(lParam) );
            break;
         }*/
         case WM_INITMENU :
         {
            SetMenuItems( hWnd );
            break;
         }
         case WM_DESTROY :
         {
            FinaliseDialog( hWnd );
            ::PostQuitMessage( 0 );
            break;
         }
         case WM_CLOSE :
         {
            ::DestroyWindow( hWnd );
            break;
         }
         default :
         {
            DidHandleMessage  =  FALSE;
            break;
         }
      }
   }
   catch( DWORD ErrorCode )
   {
      ShowErrorMessage( hWnd,  ErrorCode,  LPCTSTR(0) );
   }
   catch( ... )
   {
      ShowErrorMessage( hWnd,  0,  LPCTSTR(0) );
   }

   return  DidHandleMessage;

}




/// initialisation /////////////////////////////////////////////////////////////////////////////////

inline
VOID  InitialiseDialog
(
   HWND  hWndThis
)
{

   ::SetWindowText( hWndThis,  LPCTSTR(pTitleString_m) );

   ::DragAcceptFiles( hWndThis,  TRUE );

   //::PostMessage( hWndThis,  WM_COMMAND_LINE,  0,  LPARAM(::GetCommandLine()) );

}


inline
VOID  FinaliseDialog
(
   HWND  hWndThis
)
{

   ::DragAcceptFiles( hWndThis,  FALSE );

}


VOID  AddMenuItems
(
   HWND  hWndThis
)
{

   HMENU  hMenu  =  ::GetSystemMenu( hWndThis, FALSE );

   ::InsertMenu( hMenu,  0,  MF_BYPOSITION | MF_STRING,  IDM_CPP,    0 );
   ::InsertMenu( hMenu,  1,  MF_BYPOSITION | MF_STRING,  IDM_JAVA,   0 );
   ::InsertMenu( hMenu,  2,  MF_BYPOSITION | MF_STRING,  IDM_CS,     0 );
   ::InsertMenu( hMenu,  3,  MF_BYPOSITION | MF_STRING,  IDM_ALL,    0 );
   ::InsertMenu( hMenu,  4,  MF_BYPOSITION | MF_SEPARATOR,  0,  NULL );
   ::InsertMenu( hMenu,  5,  MF_BYPOSITION | MF_STRING,  IDM_COPY,   0 );
   ::InsertMenu( hMenu,  6,  MF_BYPOSITION | MF_SEPARATOR,  0,  NULL );
   ::InsertMenu( hMenu,  7,  MF_BYPOSITION | MF_STRING,  IDM_ABOUT,  0 );
   ::InsertMenu( hMenu,  8,  MF_BYPOSITION | MF_SEPARATOR,  0,  NULL );

}


VOID  SetMenuItems
(
   HWND hWndThis
)
{

   SetMenuItems( ::GetSystemMenu( hWndThis, FALSE ) );

}


VOID  SetMenuItems
(
   HMENU hMenu
)
{

   /// decide on status of items
   const UINT  SELECTED    =  MF_CHECKED   | MF_DISABLED;
   const UINT  UNSELECTED  =  MF_UNCHECKED | MF_ENABLED;

   const UINT  CppStatus   =  ( pTitleString_m  ==  kCppTitleString_s )   ?  SELECTED : UNSELECTED;
   const UINT  JavaStatus  =  ( pTitleString_m  ==  kJavaTitleString_s )  ?  SELECTED : UNSELECTED;
   const UINT  CsStatus    =  ( pTitleString_m  ==  kCsTitleString_s )    ?  SELECTED : UNSELECTED;
   const UINT  AllStatus   =  ( pTitleString_m  ==  kAllTitleString_s )   ?  SELECTED : UNSELECTED;


   const UINT  BusyStatus  =  IsBusy()  ?  MF_GRAYED : MF_ENABLED;


   /// set the menu with the statuses
   ::ModifyMenu( hMenu, IDM_CPP,    CppStatus    | BusyStatus,  IDM_CPP,    kCppMenuString_s   );
   ::ModifyMenu( hMenu, IDM_JAVA,   JavaStatus   | BusyStatus,  IDM_JAVA,   kJavaMenuString_s  );
   ::ModifyMenu( hMenu, IDM_CS,     CsStatus     | BusyStatus,  IDM_CS,     kCsMenuString_s    );
   ::ModifyMenu( hMenu, IDM_ALL,    AllStatus    | BusyStatus,  IDM_ALL,    kAllMenuString_s   );
   ::ModifyMenu( hMenu, IDM_COPY,   MF_UNCHECKED | BusyStatus,  IDM_COPY,   kCopyMenuString_s  );
   ::ModifyMenu( hMenu, IDM_ABOUT,  MF_UNCHECKED | MF_ENABLED,  IDM_ABOUT,  kAboutMenuString_s );

}




/// message handlers ///----------------------------------------------------------------------------

VOID  OnSetCursor
(
   WPARAM  wParam,
   LPARAM  lParam
)
{

   /// choose busy cursor if busy
   LPCTSTR  Cursor  =  LPCTSTR(IDC_ARROW);
   if( IsBusy() )
   {
      Cursor  =  LPCTSTR(IDC_APPSTARTING);
   }

   ::SetCursor( ::LoadCursor( NULL, Cursor ) );


   /// do the things windows should do automatically
   if( ( LOWORD(lParam) == LOWORD(HTERROR) )  &&
       ( ( HIWORD(lParam) == WM_LBUTTONDOWN ) || ( HIWORD(lParam) == WM_RBUTTONDOWN ) ) )
   {
      ::SetForegroundWindow( ::GetLastActivePopup( HWND(wParam) ) );
   }

}


VOID  OnPrimaryClick
(
   HWND    hWndThis,
   LPARAM  lParam
)
{

   const POINT  CursorPosition  =  { LONG( LOWORD(lParam) ),  LONG( HIWORD(lParam) ) };

   /// check if the cursor was in the icon area when the button down happened
   const HWND  hWnd   =  ::ChildWindowFromPoint( hWndThis,  CursorPosition );
   const HWND  hIcon  =  ::GetDlgItem( hWndThis,  IDS_LOGO );

   if( hWnd == hIcon )
   {
      /// delegate to about handler
      OnAbout( hWndThis );
   }

}


VOID  OnSecondaryClick
(
   HWND    hWndThis,
   LPARAM  lParam
)
{

   /// make a popup menu
   HMENU  hMenu = ::CreatePopupMenu();
   {
      const UINT  ids[]  =  { IDM_CPP, IDM_JAVA, IDM_CS, IDM_ALL, 0, IDM_COPY, 0, IDM_ABOUT };
      for( int i = 0;  i < int(sizeof(ids)/sizeof(ids[0]));  ++i )
      {
         ::InsertMenu( hMenu,  i,  MF_BYPOSITION | (ids[i] == 0 ? MF_SEPARATOR : MF_STRING),  ids[i],  0 );
      }

      SetMenuItems( hMenu );
   }

   /// execute menu
   POINT  CursorPosition  =  { LONG( LOWORD(lParam) ),  LONG( HIWORD(lParam) ) };
   ::ClientToScreen( hWndThis, &CursorPosition );

   ::TrackPopupMenu( hMenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON,
                     CursorPosition.x, CursorPosition.y, 0, hWndThis, 0 );

   /// destruct menu
   ::DestroyMenu( hMenu );

}


VOID  OnChangeFileType
(
   HWND  hWndThis,
   UINT  wParam
)
{

   if( !IsBusy() )
   {
      /// change modes
      switch( wParam )
      {
         case  IDM_CPP   :  pTitleString_m  =  kCppTitleString_s;   break;
         case  IDM_JAVA  :  pTitleString_m  =  kJavaTitleString_s;  break;
         case  IDM_CS    :  pTitleString_m  =  kCsTitleString_s;    break;
         case  IDM_ALL   :  pTitleString_m  =  kAllTitleString_s;   break;
         default         :  break;
      }

      /// reset display
      ResetOutputFields( hWndThis );
   }

}


VOID  OnCopy
(
   HWND hWndThis
)
{
   static const INT LINES_STRING_LENGTH = 12;

   BOOL isSucceeded = FALSE;

   if( 0 != ::OpenClipboard( hWndThis ) )
   {
      HGLOBAL hText = ::GlobalAlloc( GMEM_MOVEABLE | GMEM_DDESHARE, LINES_STRING_LENGTH );
      if( hText != 0 )
      {
         TCHAR*const pNoOfLinesString = static_cast<TCHAR*>(::GlobalLock( hText ));
         if( pNoOfLinesString != 0 )
         {
            UINT count = ::GetDlgItemText( hWndThis,  IDS_LINESOFCODE,  pNoOfLinesString,  LINES_STRING_LENGTH );

            ::GlobalUnlock( hText );

            if( count > 0 )
            {
               ::EmptyClipboard();

               isSucceeded = (::SetClipboardData( CF_TEXT, hText ) != 0);
            }
         }

         if( !isSucceeded )
         {
            ::GlobalFree( hText );
         }
      }

      ::CloseClipboard();
   }

   if( !isSucceeded )
   {
      ShowErrorMessage( hWndThis, ::GetLastError(), TEXT("copy failed") );
   }
}


VOID  OnAbout
(
   HWND  hWndThis
)
{

   /// prevent WM_HELP causing multiple about boxs (since it is sent even when child message boxs have focus)
   static BOOL b = FALSE;
   if( !b )
   {
      b = TRUE;

      ::MessageBox( hWndThis,  kAboutBoxMessage_s,  LPCTSTR(kAboutBoxTitle_s),  MB_ICONINFORMATION | MB_OK );

      b = FALSE;
   }

}


VOID  OnDropFiles
(
   HWND    hWndThis,
   HANDLE  hDropInfo
)
{

   if( !IsBusy() )
   {
      /// clear away previous other thread
      if( MeasuringThreadHandle_m  !=  NULL )
      {
         if( !::CloseHandle( MeasuringThreadHandle_m ) )
         {
            throw  ::GetLastError();
         }
      }

      /// make parameter available to other thread
      hWndThis_m  =  hWndThis;

      /// start other thread
      DWORD  MeasuringThreadID;
      MeasuringThreadHandle_m  =  ::CreateThread( 0, 0, OnDropFilesThread, LPVOID(hDropInfo), 0, &MeasuringThreadID );
      if( MeasuringThreadHandle_m  ==  NULL )
      {
         throw  ::GetLastError();
      }
   }

}


/*VOID  OnCommandLine
(
   HWND     hWndThis,
   LPCTSTR  CommandLineString
)
{
   /// (win95 and winNT4 both have a problem when a moderate to large number of files are dropped)


   /// build list of file pathnames

   /// find start of file list

   /// step through file pathnames

   /// delegate to thread starter

}*/




/// measurement ////////////////////////////////////////////////////////////////////////////////////

DWORD  __stdcall OnDropFilesThread
(
   LPVOID  arg
)
{

   /// retrieve 'input parameters'
   HWND    hWndThis   =  hWndThis_m;
   HANDLE  hDropInfo  =  HANDLE(arg);


   /// reset display
   ResetOutputFields( hWndThis );

   /// bring window to front
   ::SetForegroundWindow( hWndThis );

   try
   {
      /// do the measurement
      MeasureDroppedItems( hWndThis, hDropInfo );

      /// bring window to front again
      ::SetForegroundWindow( hWndThis );
   }
   catch( DWORD ErrorCode )
   {
      ShowErrorMessage( hWndThis,  ErrorCode,  LPCTSTR(0) );
   }
   catch( ... )
   {
      ShowErrorMessage( hWndThis,  0,  LPCTSTR(0) );
   }


   /// release drag thing
   ::DragFinish( HDROP(hDropInfo) );


   return  DWORD(TRUE);

}


VOID  MeasureDroppedItems
(
   HWND    hWndThis,
   HANDLE  hDropInfo
)
{

   TCHAR  FilePathName[ MAX_PATH + 1 ];

   /// zero measurement accumulators
   NoOfCodeLinesTotal_m  =  0;
   NoOfFilesTotal_m      =  0;


   /// get number of files
   const UINT  NoOfFiles  =  ::DragQueryFile( HDROP(hDropInfo), UINT(0xFFFFFFFF), 0, 0 );

   /// step through file list
   for( UINT FileIndex = NoOfFiles;  FileIndex-- > 0; )
   {
      /// get one file name
      const UINT  LengthOfName  =  ::DragQueryFile( HDROP(hDropInfo), FileIndex, 0, 0 );
      ::DragQueryFile( HDROP(hDropInfo), FileIndex, LPTSTR(FilePathName), UINT(MAX_PATH + 1) );
      if( LengthOfName > MAX_PATH )
      {
         throw  DWORD(ERROR_FILENAME_EXCED_RANGE);
      }

      /// measure the item referred to by the file name
      MeasureDirectoryOrFile( hWndThis, FilePathName );
   }

}


VOID  MeasureDirectoryOrFile
(
   HWND     hWndThis,
   LPCTSTR  pFilePathName
)
{

   const DWORD  FileAttribute =  ::GetFileAttributes( LPCTSTR(pFilePathName) );
   if( FileAttribute  ==  0xFFFFFFFF )
   {
      throw  ::GetLastError();
   }

   /// act according to the filename being of a file or directory
   if( FileAttribute & FILE_ATTRIBUTE_DIRECTORY )
   {
      MeasureDirectory( hWndThis, pFilePathName );
   }
   else
   {
      MeasureFile( hWndThis, pFilePathName );
   }

}


VOID  MeasureDirectory
(
   HWND     hWndThis,
   LPCTSTR  pFilePathName
)
{

   /// make a filtering string for find
   static const TCHAR  kAllFiles[]  =  TEXT("\\*");
   TCHAR  FindString[ MAX_PATH + 1 ];
   if( ::lstrlen( pFilePathName )  <=  ( MAX_PATH - ::lstrlen( kAllFiles ) ) )
   {
      ::lstrcpy( FindString, pFilePathName );
      ::lstrcat( FindString, kAllFiles );
   }
   else
   {
      throw  DWORD(ERROR_FILENAME_EXCED_RANGE);
   }


   /// do find
   WIN32_FIND_DATA  FindData;
   HANDLE           FindHandle;
   FindHandle  =  ::FindFirstFile( LPCTSTR(FindString), &FindData );

   try
   {
      BOOL  FindSucceeded  =  ( FindHandle != INVALID_HANDLE_VALUE );
      for( ;; )
      {
         /// decide whether to exit from loop
         if( !FindSucceeded )
         {
            const DWORD  LastError  =  ::GetLastError();
            if( LastError  ==  ERROR_NO_MORE_FILES )
            {
               break;
            }
            else
            {
               throw  LastError;
            }
         }

         /// pick out file/subdirectory items
         if( *(FindData.cFileName)  !=  TEXT('.') )
         {
            /// append found name to directory path
            TCHAR  FoundPathName[ MAX_PATH + 1 ];
            if( ::lstrlen( pFilePathName )  <=  ( MAX_PATH - ::lstrlen( FindData.cFileName ) - 1 ) )
            {
               ::lstrcpy( FoundPathName, pFilePathName );
               ::lstrcat( FoundPathName, TEXT("\\") );
               ::lstrcat( FoundPathName, FindData.cFileName );
            }
            else
            {
               throw  DWORD(ERROR_FILENAME_EXCED_RANGE);
            }

            /// measure found item
            MeasureDirectoryOrFile( hWndThis, FoundPathName );
         }

         FindSucceeded  =  ::FindNextFile( FindHandle, &FindData );
      }
   }
   catch( ... )
   {
      /// destruct find
      if( FindHandle  !=  INVALID_HANDLE_VALUE )
      {
         ::FindClose( FindHandle );
      }

      throw;
   }

   /// destruct find
   if( FindHandle  !=  INVALID_HANDLE_VALUE )
   {
      if( !::FindClose( FindHandle ) )
      {
         throw  ::GetLastError();
      }
   }

}


VOID  MeasureFile
(
   HWND     hWndThis,
   LPCTSTR  pFilePathName
)
{

   /// check if it's the right kind of file
   if( IsFileNameExtensionAcceptable( pFilePathName ) )
   {
      DWORD  NoOfCodeLines;
      DWORD  NoOfCommentLines;   /// ignored

      /// open and measure the file
      {
         CMemMapFile  File( LPCTSTR(pFilePathName),  TRUE,  FILE_FLAG_SEQUENTIAL_SCAN );
         MeasureCode( File.GetMemory(),  File.GetLengthInBytes(),  NoOfCodeLines,  NoOfCommentLines );
      }

      /// accumulate measurement totals
      NoOfCodeLinesTotal_m  +=  NoOfCodeLines;
      NoOfFilesTotal_m++;

      /// display results so far
      DisplayMeasurements( hWndThis,  NoOfCodeLinesTotal_m,  NoOfFilesTotal_m );
   }

}


VOID  MeasureCode
(
   const VOID*  pFileInMemory,
   DWORD        LengthInBytes,
   DWORD&       NoOfCodeLines,     /// out
   DWORD&       NoOfCommentLines   /// out
)
{

   /// init char pointers
   const char*        pCharCursor  =  static_cast<const char*>(pFileInMemory);
   const char* const  pEndOfFile   =  pCharCursor + ( LengthInBytes / sizeof(*pCharCursor) );

   /// init counters
   DWORD  CodeLineCounter     =  0;
   DWORD  CommentLineCounter  =  0;
   BOOL   EndOfFileReached    =  FALSE;

   /// init classification flags
   enum { eInCode, eInQuote, eInLineComment, eInBlockComment }  State  =  eInCode;
   BOOL   CodeFound     =  FALSE;
   BOOL   CommentFound  =  FALSE;


   /// read through each char
   do
   {
      /// ( would it be more efficient to convert these to int ? )
      char  Char      =  ( pCharCursor        <  pEndOfFile )  ?  *pCharCursor        :  '\0';
      char  CharNext  =  ( (pCharCursor + 1)  <  pEndOfFile )  ?  *(pCharCursor + 1)  :  '\0';

      switch( Char )
      {
         case  '{'  :
         case  '}'  :
         case  '('  :
         case  ')'  :
         case  ' '  :
         case  '\t' :
         case  '\r' :
         {
            /// ignore empty space
            break;
         }
         case  '\0' :
         {
            EndOfFileReached  =  TRUE;
            /// fall through to newline...
         }
         case  '\n' :
         {
            /// sum up line counts
            CodeLineCounter     +=  DWORD(CodeFound);
            CommentLineCounter  +=  DWORD( CommentFound && !CodeFound );   /// code takes precedence
            /// reset classification flags
            CodeFound            =  FALSE;
            CommentFound         =  ( State == eInBlockComment );
            if( ( State == eInQuote )  ||  ( State == eInLineComment ) )
            {
               State  =  eInCode;
            }
            break;
         }
         case  '"' :
         {
            /// entering or leaving quotes
            if( State == eInCode )
            {
               State  =  eInQuote;
            }
            else if( State == eInQuote )
            {
               State  =  eInCode;
            }
            goto  code;   /// go to code
         }
         case  '*' :
         {
            /// check if leaving block comment
            if( State == eInBlockComment )
            {
               if( CharNext  ==  '/' )
               {
                  ++pCharCursor;
                  State  =  eInCode;
               }
               break;
            }
            goto  code;   /// go to code
         }
         case  '/' :
         {
            /// check if entering line or block comment
            if( State == eInCode )
            {
               if( CharNext  ==  '/' )
               {
                  ++pCharCursor;
                  State  =  eInLineComment;
                  CommentFound  =  TRUE;
               }
               else if( CharNext  ==  '*' )
               {
                  ++pCharCursor;
                  State  =  eInBlockComment;
                  CommentFound  =  TRUE;
               }
            }
            /// fall through to code
         }
         default :   /// code
         code    :
         {
            /// check if code character isn't in a comment
            if( ( State == eInCode )  ||  ( State == eInQuote ) )
            {
               CodeFound  =  TRUE;
            }
            break;
         }
      }

   } while( ++pCharCursor,  !EndOfFileReached );


   /// set the output values
   NoOfCodeLines     =  CodeLineCounter;
   NoOfCommentLines  =  CommentLineCounter;

}




/// utitities //////////////////////////////////////////////////////////////////////////////////////

BOOL  IsBusy()
{

   DWORD  Status  =  WAIT_OBJECT_0;

   if( MeasuringThreadHandle_m  !=  NULL )
   {
      Status  =  ::WaitForSingleObject( MeasuringThreadHandle_m, 0 );
      if( Status  ==  WAIT_FAILED )
      {
         throw  ::GetLastError();
      }
   }

   return  BOOL( Status == WAIT_TIMEOUT );

}


VOID  ResetOutputFields
(
   HWND  hWndThis
)
{

   /// reset the label text
   ::SetDlgItemText( hWndThis,  IDS_LINESOFCODE_LABEL,  LPCTSTR(kLinesOfCodeLabel_s) );

   /// make the number field visible
   const HWND  hLinesOfCodeOutput  =  ::GetDlgItem( hWndThis,  IDS_LINESOFCODE );
   if( hLinesOfCodeOutput  !=  NULL )
   {
      ::ShowWindow( hLinesOfCodeOutput,  SW_HIDE );   /// why is it necessary to hide first ?
      ::ShowWindow( hLinesOfCodeOutput,  SW_SHOW );
   }


   /// zero display
   DisplayMeasurements( hWndThis, 0, 0 );

}


VOID  DisplayMeasurements
(
   HWND   hWndThis,
   DWORD  NoOfCodeLines,
   DWORD  NoOfFiles
)
{

   /// lines of code
   ::SetDlgItemInt( hWndThis,  IDS_LINESOFCODE,  UINT(NoOfCodeLines),  FALSE );


   /// number of files
   if( NoOfFiles  >  0 )
   {
      TCHAR  NoOfFilesString[ 32 ];
      const TCHAR  Plural  =  NoOfFiles > DWORD(1)  ?  TEXT('s') : TEXT(' ');

      ::wsprintf( NoOfFilesString,  TEXT("%sd %lu file%c"),  pTitleString_m, NoOfFiles, Plural );
      ::SetWindowText( hWndThis,  LPCTSTR(NoOfFilesString) );
   }
   else
   {
      ::SetWindowText( hWndThis,  LPCTSTR(pTitleString_m) );
   }

}


bool  IsFileNameExtensionAcceptable
(
   LPCTSTR  pFilePathName
)
{

   const int           LengthOfName     =  ::lstrlen( pFilePathName );
   const TCHAR* const  pLastChar        =  pFilePathName + LengthOfName - int(1);
   TCHAR               LastFiveChars[]  =  TEXT("-----");
   bool                IsAcceptable;//     =  FALSE;


   switch( LengthOfName )
   {
      /// make a copy of the last 5 chars
      default :
      {
         LastFiveChars[ 0 ]  =  pLastChar[ -4 ];
      }
      case  4 :
      {
         LastFiveChars[ 1 ]  =  pLastChar[ -3 ];
      }
      case  3 :
      {
         LastFiveChars[ 2 ]  =  pLastChar[ -2 ];
         LastFiveChars[ 3 ]  =  pLastChar[ -1 ];
         LastFiveChars[ 4 ]  =  pLastChar[  0 ];


         /// test the last 5 chars for matches

         ::CharLower( LPTSTR(LastFiveChars) );
         const TCHAR*const  pChar  =  LastFiveChars + int(4);


         bool isCpp = false;
         {
            const TCHAR* pc = pChar;
            if(    ( ( *pc == TEXT('p') )  &  ( *(pc-1) == TEXT('p') ) )
                |  ( ( *pc == TEXT('x') )  &  ( *(pc-1) == TEXT('x') ) )  )
            {
               --pc;
               --pc;
            }

            if(    ( ( *pc == TEXT('h') )  |  ( *pc == TEXT('c') ) )
                &  ( *(pc-1) == TEXT('.') )                               )
            {
               isCpp  =  true;
            }
         }

         bool isJava = false;
         {
            const TCHAR* pc = pChar;
            if(    ( *pc     == TEXT('a') )  &  ( *(pc-1) == TEXT('v') )
                &  ( *(pc-2) == TEXT('a') )  &  ( *(pc-3) == TEXT('j') )
                &  ( *(pc-4) == TEXT('.') )                                  )
            {
               isJava  =  true;
            }
         }

         bool isCs = false;
         {
            const TCHAR* pc = pChar;
            if(    ( *pc     == TEXT('s') )  &  ( *(pc-1) == TEXT('c') )
                &  ( *(pc-2) == TEXT('.') )                                  )
            {
               isCs  =  true;
            }
       }

         IsAcceptable  =  ((isCpp | isJava | isCs) & (pTitleString_m == kAllTitleString_s)) ||
                          ((isCpp  & (pTitleString_m == kCppTitleString_s))  |
                           (isJava & (pTitleString_m == kJavaTitleString_s)) |
                           (isCs   & (pTitleString_m == kCsTitleString_s))     );

         break;
      }
      /// name too short to contain a match
      case  2 :
      case  1 :
      case  0 :
      {
         IsAcceptable  =  false;
         break;
      }
   }


   return  IsAcceptable;




   /* this version is actually larger !

   /// static file name extensions
   static const INT     kNoOfExtensionsCpp_s     =  6;
   static const TCHAR*  kFileExtensionsCpp_s[]   =  { TEXT(".h"),   TEXT(".c"),
                                                      TEXT(".hpp"), TEXT(".cpp"),
                                                      TEXT(".hxx"), TEXT(".cxx")  };

   static const INT     kNoOfExtensionsJava_s    =  1;
   static const TCHAR*  kFileExtensionsJava_s[]  =  { TEXT(".java") };

   static const INT     kNoOfExtensionsCs_s      =  1;
   static const TCHAR*  kFileExtensionsCs_s[]    =  { TEXT(".cs") };


   /// choose which extensions to use
   INT      NoOfExtensions;
   TCHAR**  FileExtensions;
   if( pTitleString_m  ==  kCppTitleString_s )
   {
      NoOfExtensions  =  kNoOfExtensionsCpp_s;
      FileExtensions  =  kFileExtensionsCpp_s;
   }
   else if( pTitleString_m  ==  kJavaTitleString_s )
   {
      NoOfExtensions  =  kNoOfExtensionsJava_s;
      FileExtensions  =  kFileExtensionsJava_s;
   }
   else
   {
      NoOfExtensions  =  kNoOfExtensionsCs_s;
      FileExtensions  =  kFileExtensionsCs_s;
   }


   /// compare file name with extensions
   BOOL  IsAcceptable  =  FALSE;

   const INT  LengthOfName  =  ::lstrlen( pFilePathName );
   for( INT i = NoOfExtensions;  i-- & !IsAcceptable; )
   {
      const INT  LengthOfExtension  =  ::lstrlen( FileExtensions[ i ] );

      if( LengthOfName > LengthOfExtension )
      {
         const LPCTSTR  pEndOfFileName  =  pFilePathName + LengthOfName - LengthOfExtension;
         IsAcceptable  =  ( ::lstrcmpi( pEndOfFileName, FileExtensions[ i ] ) == 0 );
      }
   }


   return  IsAcceptable;*/

}


VOID  ShowErrorMessage
(
   HWND     hWndThis,
   DWORD    Code,
   LPCTSTR  pDetailMessage
)
{

   /// bring window to front
   ::SetForegroundWindow( hWndThis );


   /// translate code into message
   static const DWORD  CodeMessageLen  =  127;
   TCHAR  pCodeMessage[ CodeMessageLen + 1 ];
   if( Code  !=  0 )
   {
      ::FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, 0, Code, 0, pCodeMessage, CodeMessageLen, 0 );
      pDetailMessage  =  pCodeMessage;
   }


   /// concatenate detail message with default message
   static const DWORD  CompleteMessageLen  =  255;
   TCHAR  pCompleteMessage[ CompleteMessageLen + 1 ];

   LPCTSTR  pMessageParts[]  =  { kErrorMessage_s, pDetailMessage };
   ::FormatMessage( FORMAT_MESSAGE_FROM_STRING | FORMAT_MESSAGE_ARGUMENT_ARRAY,
                    TEXT("%1\n\n%2"), 0, 0, pCompleteMessage, CompleteMessageLen, const_cast<TCHAR**>(pMessageParts) );


   /// display the whole thing
   ::MessageBox( hWndThis,  pCompleteMessage,  LPCTSTR(pTitleString_m),  MB_ICONEXCLAMATION | MB_OK );

}
