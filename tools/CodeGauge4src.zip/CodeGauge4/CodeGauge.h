//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  CodeGauge.h
//------------------------------------------------




#ifndef included_CodeGauge_h
#define included_CodeGauge_h








/// windows stuff
int WINAPI     WinMain( HINSTANCE hInst,  HINSTANCE hPrevInst,  char* cmdParam,  int  cmdShow );
BOOL CALLBACK  DialogProc( HWND hWnd,  UINT Message,  WPARAM wParam,  LPARAM lParam );


/// initialisation
VOID  InitialiseDialog( HWND hWndThis );
VOID  FinaliseDialog( HWND hWndThis );
VOID  AddMenuItems( HWND hWndThis );
VOID  SetMenuItems( HWND hWndThis );
VOID  SetMenuItems( HMENU hMenu );


/// message handlers
VOID  OnSetCursor( WPARAM wParam,  LPARAM lParam );
VOID  OnPrimaryClick( HWND hWndThis,  LPARAM lParam );
VOID  OnSecondaryClick( HWND hWndThis,  LPARAM lParam );
VOID  OnChangeFileType( HWND hWndThis, UINT wParam );
VOID  OnCopy( HWND hWndThis );
VOID  OnAbout( HWND hWndThis );
VOID  OnDropFiles( HWND hWndThis,  HANDLE hDropInfo );
//VOID  OnCommandLine( HWND hWndThis,  LPCTSTR CommandLineString );


/// measurement
DWORD __stdcall OnDropFilesThread( LPVOID );
VOID  MeasureDroppedItems( HWND hWndThis,  HANDLE hDropInfo );
VOID  MeasureDirectoryOrFile( HWND hWndThis,  LPCTSTR  pFilePathName );
VOID  MeasureDirectory      ( HWND hWndThis,  LPCTSTR  pFilePathName );
VOID  MeasureFile           ( HWND hWndThis,  LPCTSTR  pFilePathName );
VOID  MeasureCode( const VOID* pFileInMemory,  DWORD LengthInBytes,  DWORD& NoOfCodeLines,  DWORD& NoOfCommentLines );


/// utilities
BOOL  IsBusy();
VOID  ResetOutputFields( HWND hWndThis );
VOID  DisplayMeasurements( HWND hWndThis,  DWORD NoOfCodeLines,  DWORD NoOfFiles );
bool  IsFileNameExtensionAcceptable( LPCTSTR pFilePathName );
VOID  ShowErrorMessage( HWND hWndThis,  DWORD Code,  LPCTSTR Message );








#endif//included_CodeGauge_h
