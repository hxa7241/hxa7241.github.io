//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  resource.h
//------------------------------------------------




#ifndef included_resource_h
#define included_resource_h




#define IDD_CODEGAUGE_DLG       200
#define IDI_CODEGAUGE_ICON      300

#define IDS_LOGO               1000
#define IDS_LINESOFCODE        1001
#define IDS_LINESOFCODE_LABEL  1002
#define IDC_STATIC               -1




#endif//included_resource_h
