//================================================================================================//
//                                                                                                //
//                                     - C o d e G a u g e -                                      //
//                                                                                                //
//                 Copyright (c) 1999,  Harrison Ainsworth.  All rights reserved.                 //
//                                                                                                //
//================================================================================================//

//------------------------------------------------
//  stdwin.h
//------------------------------------------------




#ifndef included_stdwin_h
#define included_stdwin_h




//#define WIN32_LEAN_AND_MEAN

#include <windows.h>




#endif//included_stdwin_h
