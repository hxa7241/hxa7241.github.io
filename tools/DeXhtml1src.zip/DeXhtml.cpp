/*--------------------------------------------------------------------

   DeXhtml, version 1
   Copyright (c) 2004,  Harrison Ainsworth.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/

/*--------------------------------------------------------------------

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston,
   MA 02111-1307, USA

--------------------------------------------------------------------*/


/**
 * implementation description
 * --------------------------
 *
 * simple console/command-line program
 * all procedural
 * uses c++ std library
 *
 * basic execution sequence:
 *    read switches, execute two functions, terminate
 *
 * more detailed execution sequence:
 *    main()
 *       readParameters()
 *          /// get params from command line
 *       convert()
 *          /// strip tags, translate entitys, copy text
 *       wrapLines()
 *          /// wrap and break lines
 *
 * convert recognises individual xhtml tags and name-entities, and
 * performs simple deletion or translation on them.
 *
 * wrapLines wraps and breaks lines at spaces or tabs, but char sequences
 * with no blanks and longer than the limit are left unbroken.
 *
 * [hmmm, c++ is not really the right language for this sort of
 * string-processing job...]
 */




#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <stdlib.h>




/// constants
static const char HELP_MESSAGE[] =
"\n-------------------------------------------------------------\n"
"DeXhtml v1\n"
"Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.\n\n"
"2004-07-01\n\nhttp://www.hxa7241.org/\n"
"-------------------------------------------------------------\n\n"
"\n"
"DeXhtml transforms an xhtml1 file (encoded as ascii or 8859-1) into a plain-text ascii or 8859-1 file in a simple way.\n"
"\n"
"the transform is:\n"
"* translates name entities into ascii or 8859-1 chars\n"
"* translates italic tags into single chars (optionally)\n"
"* strips out all other tags\n"
"* wraps and breaks lines\n"
"\n"
"* 'lat1', 'special' and most of 'symbol' entities supported by default\n"
"* 'symbol': mathematical, technical, geometric and miscellaneous groups unsupported by default\n"
"\n"
"usage:\n"
"   DeXhtml [-e...] [-i...] [-w...] [-o...] filepathname\n"
"\n"
"switches:\n"
"   -e<filepathname>  set extra/overriding entity translations\n"
"   -i[char]          set italic tag translation character (defaults to strip)\n"
"   -w<32-256 | 0>    set line wrap length, 0 = no wrap (defaults to no wrap)\n"
"   -o<filepathname>  set output filepathname (defaults to inputfilepathname.txt)\n"
"\n"
"example:\n"
"   DeXhtml -eentityfile.txt -i_ -w70 -oanotherfile.txt somefile.html\n"
"\n"
"entity translation file must contain lines of name and string pairs, for example:\n"
"\n"
"aelig  \"ae\"\n"
"nbsp   \" \"\n"
"ldquo  \"\"\"\n"
"shy    \"\"\n\n";

static const char SWITCH_HELP1[] = "?";
static const char SWITCH_HELP2[] = "help";
static const char ITALIC_DEFAULT = '\0';
static const int  WRAP_DEFAULT   = 0;
static const int  WRAP_MIN       = 32;
static const int  WRAP_MAX       = 256;

static const char EXCEPTION_PREFIX[]        = "*** execution failed:  ";
static const char EXCEPTION_ABSTRACT[]      = "cause not noted";
static const char EXCEPTION_IN_OPEN[]       = "couldnt open input file";
static const char EXCEPTION_OUT_OPEN[]      = "couldnt open output file";
static const char EXCEPTION_ENTITY_OPEN[]   = "couldnt open entity file";
static const char EXCEPTION_ENTITY_STREAM[] = "entity stream fault";
static const char EXCEPTION_STREAM[]        = "stream fault";


/// entity-chars translation tables data - must be same length
/// 'symbol': mathematical, technical, geometric and miscellaneous arent included
static const char* ENTITYS[] =
{
	"nbsp", "iexcl", "cent", "pound", "curren", "yen", "brvbar", "sect", "uml", "copy", "ordf", "laquo", "not", "shy", "reg", "macr", "deg", "plusmn", "sup2", "sup3", "acute", "micro", "para", "middot", "cedil", "sup1", "ordm", "raquo", "frac14", "frac12", "frac34", "iquest", "Agrave", "Aacute", "Acirc", "Atilde", "Auml", "Aring", "AElig", "Ccedil", "Egrave", "Eacute", "Ecirc", "Euml", "Igrave", "Iacute", "Icirc", "Iuml", "ETH", "Ntilde", "Ograve", "Oacute", "Ocirc", "Otilde", "Ouml", "times", "Oslash", "Ugrave", "Uacute", "Ucirc", "Uuml", "Yacute", "THORN", "szlig", "agrave", "aacute", "acirc", "atilde", "auml", "aring", "aelig", "ccedil", "egrave", "eacute", "ecirc", "euml", "igrave", "iacute", "icirc", "iuml", "eth", "ntilde", "ograve", "oacute", "ocirc", "otilde", "ouml", "divide", "oslash", "ugrave", "uacute", "ucirc", "uuml", "yacute", "thorn", "yuml",
	"quot", "amp", "lt", "gt", "apos", "OElig", "oelig", "Scaron", "scaron", "Yuml", "circ", "tilde", "ensp", "emsp", "thinsp", "zwnj", "zwj", "lrm", "rlm", "ndash", "mdash", "lsquo", "rsquo", "sbquo", "ldquo", "rdquo", "bdquo", "dagger", "Dagger", "permil", "lsaquo", "rsaquo", "euro",
	"fnof", "Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta", "Theta", "Iota", "Kappa", "Lambda", "Mu", "Nu", "Xi", "Omicron", "Pi", "Rho", "Sigma", "Tau", "Upsilon", "Phi", "Chi", "Psi", "Omega", "alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta", "theta", "iota", "kappa", "lambda", "mu", "nu", "xi", "omicron", "pi", "rho", "sigmaf", "sigma", "tau", "upsilon", "phi", "chi", "psi", "omega", "thetasym", "upsih", "piv", "bull", "prime", "Prime", "oline", "frasl", "weierp", "image", "real", "trade", "alefsym", "larr", "uarr", "rarr", "darr", "harr", "crarr", "lArr", "uArr", "rArr", "dArr", "hArr"
};
static const char* CHARS[]  =
{

	" ", "!", "c", "L", "S", "Y", "|", " ", " ", "(c)", "", "<<", "-", "", "(R)", "-", "deg", "+/-", "^2", "^3", "", "u", " ", ".", "", "^1", "", ">>", "1/4", "1/2", "3/4", "?", "A", "A", "A", "A", "A", "A", "AE", "C", "E", "E", "E", "E", "I", "I", "I", "I", "D", "N", "O", "O", "O", "O", "O", "x", "O", "U", "U", "U", "U", "Y", "TH", "sz", "a", "a", "a", "a", "a", "a", "ae", "c", "e", "e", "e", "e", "i", "i", "i", "i", "d", "n", "o", "o", "o", "o", "o", "/", "o", "u", "u", "u", "u", "y", "th", "y",
	"\"", "&", "<", ">", "'", "OE", "oe", "S", "s", "Y", "^", "~", " ", "  ", "", "", "", "", "", "-", "--", "'", "'", "'", "\"", "\"", "\"", "+", "++", "0/00", "<", ">", "E",
	"f", "A", "B", "G", "D", "E", "Z", "AE", "TH", "I", "K", "L", "M", "N", "X", "O", "P", "R", "S", "T", "U", "PH", "CH", "PS", "O", "a", "b", "g", "d", "e", "z", "ae", "th", "i", "k", "l", "m", "n", "x", "o", "p", "r", "s", "s", "t", "u", "ph", "ch", "ps", "o", "th", "u", "p", "*", "'", "\"", "-", "/", "P", "J", "R", "(tm)", "N", "<-", "^", "->", "|", "<->", "(ret)", "<=", "^", "=>", "|", "<=>"
};




/// method prototypes
void readParameters
(
	int          argc,
	char*const   argv[],
	std::string& inputFilepathname,
	std::string& outputFilepathname,
	std::string& entityFilepathname,
	char&        italicChar,
	int&         wrapLength
);

void convert
(
	std::istream&      in,
	const std::string& entityFilepathname,
	const char         italicChar,
	std::ostream&      out
);

void setEntityTranslation
(
	const std::string&                  entityFilepathname,
	std::map<std::string, std::string>& entityTable
);

void wrapLines
(
	std::istream& in,
	const int     wrapLength,
	std::ostream& out
);




/// root procedure ---------------------------------------------------------------------------------
int main
(
	int   argc,
	char* argv[]
)
{
	int returnValue = 1;

	try
	{
		/// check for help request
		if( (argc <= 1) || ((('-' == argv[1][0]) | ('/' == argv[1][0])) &&
		                    ( (std::string(SWITCH_HELP1) == std::string(argv[1] + 1)) |
		                      (std::string(SWITCH_HELP2) == std::string(argv[1] + 1)) )) )
		{
			/// output help
			std::cout << HELP_MESSAGE;

			returnValue = 0;
		}
		else
		{
			/// set transform parameters
			std::string inputFilepathname;
			std::string outputFilepathname;
			std::string entityFilepathname;
			char        italicChar = ITALIC_DEFAULT;
			int         wrapLength = WRAP_DEFAULT;

			readParameters( argc, argv, inputFilepathname, outputFilepathname, entityFilepathname, italicChar, wrapLength );


			/// make streams
			std::ifstream in( inputFilepathname.c_str(), std::ios_base::binary );
			in.exceptions( std::ifstream::badbit );//| std::ifstream::failbit | std::ifstream::eofbit );
			if( in.fail() )
			{
				throw EXCEPTION_IN_OPEN;
			}

			std::stringstream mem;

			std::ofstream out( outputFilepathname.c_str(), std::ios_base::binary );
			out.exceptions( std::ofstream::badbit );//| std::ofstream::failbit | std::ofstream::eofbit );
			if( out.fail() )
			{
				throw EXCEPTION_OUT_OPEN;
			}


			/// do transform
			convert( in, entityFilepathname, italicChar, mem );
			wrapLines( mem, wrapLength, out );


			returnValue = 0;
		}
	}
	catch( const char*const exceptionString )
	{
		/// display exception message
		std::cout << '\n' << EXCEPTION_PREFIX << exceptionString << '\n';
	}
	catch( ... )
	{
		/// display exception message
		std::cout << '\n' << EXCEPTION_PREFIX << EXCEPTION_ABSTRACT << '\n';
	}

	std::cout.flush();

	return returnValue;
}




void readParameters
(
	const int    argc,
	char*const   argv[],
	std::string& inputFilepathname,
	std::string& outputFilepathname,
	std::string& entityFilepathname,
	char&        italicChar,
	int&         wrapLength
)
{
	/// read input filepathname from last arg
	/// (let the stream opening validate it later)
	inputFilepathname = argv[argc - 1];


	/// make default output filepathname
	outputFilepathname = inputFilepathname;
	outputFilepathname.append( ".txt" );


	/// read switches from middle args
	for( int i = argc - 1;  i-- > 1; )
	{
		/// only read if first char identifies a switch
		const char first = argv[i][0];
		if( ('-' == first) | ('/' == first) )
		{
			const char       key    = argv[i][1];
			const char*const pValue = argv[i] + 2;
			switch( key )
			{
				/// entity filePathname
				case 'e' :
				{
					/// read string, let the stream opening validate it later
					entityFilepathname = pValue;

					break;
				}
				/// italic char
				case 'i' :
				{
					/// use value, if not empty
					//if( '\0' != *pValue )
					{
						italicChar = *pValue;
					}

					break;
				}
				/// wrap length
				case 'w' :
				{
					/// read int, defaults to 0
					wrapLength = std::atoi( pValue );

					/// clamp to range
					if( 0 != wrapLength )
					{
						wrapLength = wrapLength < WRAP_MIN ? WRAP_MIN : (wrapLength > WRAP_MAX ? WRAP_MAX : wrapLength);
					}

					break;
				}
				/// output filePathname
				case 'o' :
				{
					/// read string, let the stream opening validate it later
					outputFilepathname = pValue;

					break;
				}
				default  :
					break;
			}
		}
	}


	/// display parameters
	//if( isVerbose )
	//{
	//	std::cout << '\n';
	//	std::cout << "   inputFilepathname  = " << inputFilepathname << '\n';
	//	std::cout << "   outputFilepathname = " << outputFilepathname << '\n';
	//	std::cout << "   entityFilepathname = " << entityFilepathname << '\n';
	//	std::cout << "   wrap length        = " << wrapLength << (wrapLength == 0 ? " (nowrap)" : "") << '\n';
	//	std::cout << "   italic char        = " << italicChar << '\n';
	//}


//	/// test ///
//	/// display all args
//	std::cout << "argc    == " << argc << '\n';
//	for( int i = 0;  i < argc;  ++i )
//	{
//		std::cout << "argv[" << i << "] == " << argv[i] << '\n';
//	}
}




void convert
(
	std::istream&      in,
	const std::string& entityFilepathname,
	const char         italicChar,
	std::ostream&      out
)
{
	/// make entity translation mapping
	std::map<std::string, std::string> entityTable;
	setEntityTranslation( entityFilepathname, entityTable );

	/// step through chars, until stream ends or fails
	while( true )
	{
		/// read a char
		const char c = char(in.get());

		if( !in.good() | !out.good() )
		{
			break;
		}

		switch( c )
		{
			/// read tag
			case '<' :
			{
				/// check if italic translation is enabled
				if( '\0' != italicChar )
				{
					char c = char(in.get());
					if( !in.good() )
					{
						break;
					}

					/// skip closing tag marker, to treat all tags the same
					if( '/' == c )
					{
						c = char(in.get());
						if( !in.good() )
						{
							break;
						}
					}

					/// if italic tag, translate and write
					if( 'i' == c )
					{
						out.put( italicChar );
					}
				}

				/// skip rest of tag
				while( ('>' != char(in.get())) && in.good() );

				break;
			}

			/// read entity
			case '&' :
			{
				/// make buffer enough for xhtml entity name
				char buffer[]       = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
				const int bufLength = sizeof(buffer) / sizeof(buffer[0]);

				/// read entity name
				for( int i = 0;  true; )
				{
					const char c = char(in.get());

					/// end loop when end of entity name found
					if( (';' == c) | !in.good() )
					{
						break;
					}

					/// only store chars until buffer is full
					if( i < bufLength )
					{
						buffer[i++] = c;
					}
				}

				/// translate and write entity name
				std::map<std::string, std::string>::const_iterator it = entityTable.find( buffer );
				out << it->second;

				break;
			}

			/// read text
			default :
			{
				/// just copy char
				out.put( c );

				break;
			}
		}
	}

	/// if loop ended by stream failing, throw exception
	if( (in.fail() & !in.eof()) | !out.good() )
	{
		throw EXCEPTION_STREAM;
	}
}


void setEntityTranslation
(
	const std::string&                  entityFilepathname,
	std::map<std::string, std::string>& entityTable
)
{
	/// default
	for( int i = sizeof(ENTITYS)/sizeof(ENTITYS[0]);  i-- > 0; )
	{
		entityTable[ std::string(ENTITYS[i]) ] = std::string(CHARS[i]);
		//entityTable.insert( entityTable::value_type( ENTITYS[i], CHARS[i] ) );
	}

	/// custom
	if( !entityFilepathname.empty() )
	{
		std::ifstream entityStream( entityFilepathname.c_str(), std::ios_base::binary );
		entityStream.exceptions( std::ifstream::badbit );//| std::ifstream::failbit | std::ifstream::eofbit );
		if( entityStream.fail() )
		{
			throw EXCEPTION_ENTITY_OPEN;
		}

		/// step through chars, until stream ends or fails
		while( true )
		{
			/// read next word to get name
			std::string name;
			entityStream >> name;
			if( !entityStream.good() )
			{
				break;
			}

			std::string chars;
			{
				std::string buffer( 8, ' ' );

				/// read till newline
				while( true )
				{
					const char c = char(entityStream.get());
					if( ('\n' == c) | ('\r' == c) | !entityStream.good() )
					{
						break;
					}
					buffer += c;
				}

				if( entityStream.fail() & !entityStream.eof() )
				{
					break;
				}

				/// find quote delimiters
				const std::string::size_type firstQuotePos = buffer.find( "\"" );
				const std::string::size_type lastQuotePos  = buffer.rfind( "\"" );

				/// if syntax error, skip and go to next pair
				if( (chars.npos == firstQuotePos) | (firstQuotePos == lastQuotePos) )
				{
					continue;
				}

				chars = buffer.substr( firstQuotePos + 1, (lastQuotePos - firstQuotePos) - 1 );
			}


			/// put pair in table
			entityTable[ name ] = chars;
		}

		/// if loop ended by stream failing, throw exception
		if( entityStream.fail() & !entityStream.eof() )
		{
			throw EXCEPTION_ENTITY_STREAM;
		}
	}
}




void wrapLines
(
	std::istream& in,
	const int     wrapLength,
	std::ostream& out
)
{
	/// check wrapping is switched on
	if( wrapLength > 0 )
	{
		/// find which line end encoding is used in the file
		/// look at first one, default to DOS 0xOD 0xOA
		char newline[] = "\r\n";
		{
			char c = 0;
			do
			{
				c = char(in.get());
			}
			while( ('\r' != c) & ('\n' != c) & in.good() );

			/// if endline found
			if( in.good() )
			{
				newline[0] = c;
				newline[1] = '\0';

				/// check for paired endline char
				const char c2 = char(in.get());
				if( (c2 != c) & (('\r' == c2) | ('\n' == c2)) & in.good() )
				{
					newline[1] = c2;
				}
			}

			if( in.fail() & !in.eof() )
			{
				throw EXCEPTION_STREAM;
			}

			in.seekg( 0 );
		}


		/// step thru chars, until stream ends or fails
		int widthCount   = 0;
		int lastSpacePos = INT_MAX;
		while( true )
		{
			char c = 0;
			const int pos = in.tellg();

			/// copy char
			{
				c = char(in.get());
				if( !in.good() )
				{
					break;
				}
				out.put( c );
				if( !out.good() )
				{
					break;
				}
			}

			/// if char is space, note position in lastSpacePos
			if( (' ' == c) | ('\t' == c) )
			{
				lastSpacePos = pos;
			}

			const bool isLineEnd = ('\n' == c) | ('\r' == c);

			/// if linebreak position reached
			if( isLineEnd |
				((widthCount >= wrapLength) & (lastSpacePos <= pos)) )
			{
				/// if char isnt newline, add linebreak
				if( !isLineEnd )
				{
					/// move stream pointers back to lastSpacePos
					in.seekg(  lastSpacePos - pos - 1, std::ios_base::cur );
					out.seekp( lastSpacePos - pos - 1, std::ios_base::cur );

					/// read char, write newline
					{
						in.get();
						if( !in.good() )
						{
							break;
						}
						out << newline;
						if( !out.good() )
						{
							break;
						}
					}
				}

				/// reset line counters
				widthCount   = 0;
				lastSpacePos = INT_MAX;
			}
			else
			{
				/// inc widthCount
				++widthCount;
			}
		}
	}
	/// simply copy chars, until stream ends or fails
	else
	{
		while( true )
		{
			const char c = char(in.get());
			if( !in.good() )
			{
				break;
			}
			out.put( c );
			if( !out.good() )
			{
				break;
			}
		}
	}

	/// if loop ended by stream failing, throw exception
	if( (in.fail()  & !in.eof()) |
		(out.fail() & !out.eof()) )
	{
		throw EXCEPTION_STREAM;
	}
}
