/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Primitives_h
#define Primitives_h




namespace hxa7241
{
/// types ------------------------------------------------------------------------------------------

	typedef  signed   char   byte;
	typedef  unsigned char   ubyte;

	typedef  signed   short  word;
	typedef  unsigned short  uword;

	typedef  signed   int    dword;
	typedef  unsigned int    udword;

}




#endif//Primitives_h
