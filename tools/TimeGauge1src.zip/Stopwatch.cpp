/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "stdwin.h"   /// for ::GetTickCount()

#include "Stopwatch.h"   /// own header is included last


using namespace hxa7241_timegauge;




/// statics
/// must be < DWORD_MAX  (2147483647)
/// 24 hours == 86400000 millisecs
const udword Stopwatch::RANGE = 86400000;




/// standard object services -----------------------------------------------------------------------
Stopwatch::Stopwatch()
{
	Stopwatch::reset();
}


Stopwatch::~Stopwatch()
{
}


Stopwatch::Stopwatch
(
	const Stopwatch& other
)
{
	Stopwatch::operator=( other );
}


Stopwatch& Stopwatch::operator=
(
	const Stopwatch& other
)
{
	if( &other != this )
	{
		isRunning_m     = other.isRunning_m;
		timeLastStart_m = other.timeLastStart_m;
		durationSum_m   = other.durationSum_m;
	}

	return *this;
}




/// commands ---------------------------------------------------------------------------------------
void Stopwatch::startStop()
{
	/// toggle running state
	if( isRunning_m )
	{
		stop();
	}
	else
	{
		start();
	}
}


void Stopwatch::start()
{
	/// only start if not already started
	if( !isRunning_m )
	{
		/// note start time point
		timeLastStart_m = ::GetTickCount();

		isRunning_m     = true;
	}
}


void Stopwatch::stop()
{
	/// only stop if not already stopped
	if( isRunning_m )
	{
		/// absorb current duration into cumulative duration
		durationSum_m   = getDuration();

		timeLastStart_m = 0;
		isRunning_m     = false;
	}
}


void Stopwatch::reset()
{
	isRunning_m     = false;
	timeLastStart_m = 0;
	durationSum_m   = 0;
}




/// queries ----------------------------------------------------------------------------------------
bool  Stopwatch::isRunning() const
{
	return isRunning_m;
}


dword Stopwatch::getDuration() const
{
	dword duration = durationSum_m;

	if( isRunning_m )
	{
		/// add current duration (modulo RANGE) to cumulative duration
		const dword durationCurrent = dword((::GetTickCount() - timeLastStart_m) % RANGE);
		duration += durationCurrent;

		/// rollover to constrain within range
		if( duration >= dword(RANGE) )
		{
			duration -= dword(RANGE);
		}
	}

	return duration;
}
