/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef Stopwatch_h
#define Stopwatch_h


#include "Primitives.h"




namespace hxa7241_timegauge
{
	using namespace hxa7241;


/**
 * a simple stopwatch.<br/><br/>
 *
 * works like a digital watch chronograph (but without lap-time). reset
 * method stops and zeros. duration value is millisecs. wraps around
 * at 24 hours.<br/><br/>
 *
 * duration value wont be modulo 24 hours if left running for longer than
 * udword max millisecs (~49.7 days).<br/><br/>
 *
 * @implementation
 * uses win32 ::GetTickCount() function
 */
class Stopwatch
{
/// standard object services -----------------------------------------------------------------------
public:
	         Stopwatch();

	        ~Stopwatch();
	         Stopwatch( const Stopwatch& );
	Stopwatch& operator=( const Stopwatch& );


/// commands ---------------------------------------------------------------------------------------
	         void  startStop();
	         void  start();
	         void  stop();
	         void  reset();


/// queries ----------------------------------------------------------------------------------------
	         bool  isRunning()   const;
	         dword getDuration() const;


/// fields -----------------------------------------------------------------------------------------
private:
	bool   isRunning_m;
	udword timeLastStart_m;

	dword  durationSum_m;

	static const udword RANGE;
};


} //namespace




#endif//Stopwatch_h
