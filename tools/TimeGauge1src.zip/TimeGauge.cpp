/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#include "stdwin.h"

#include "resource.h"
#include "Stopwatch.h"

#include "TimeGauge.h"


using namespace hxa7241_timegauge;




/// 'member' variables
static HINSTANCE hInstance_m = 0;

static HFONT     hFont_m     = 0;
static dword     margin_m    = 0;

static Stopwatch stopwatch_m;




/// constants
const UINT  IDM_ABOUT              = UINT(0xF000) - UINT(1);
const UINT  IDM_COPY               = UINT(0xF000) - UINT(2);
const dword TIMER_PERIOD_MILLISECS = 250;
const dword BACKGROUND_COLOR       = 0x00E0E0E0;
const dword FOREGROUND_COLOR       = 0x00202020;
const TCHAR TIME_FORMAT[]          = TEXT("%02u:%02u:%02u");   /// 00:00:00
const dword TIME_STRING_LENGTH     = 10;




/// windows stuff ----------------------------------------------------------------------------------
int WINAPI WinMain
(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR     ,//lpszCmdLine,
	int       nCmdShow
)
{
	const TCHAR WND_CLASS_NAME[] = TEXT("TimeGaugeWndClass");


	hInstance_m = hInstance;


	/// register the window class for the main window
	WNDCLASSEX wc;

	if( hPrevInstance == 0 )
	{
		wc.cbSize        = sizeof(WNDCLASSEX);
		wc.style         = CS_OWNDC | CS_SAVEBITS;
		wc.lpfnWndProc   = WindowProc;
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = hInstance;
		wc.hIcon         = ::LoadIcon( hInstance, MAKEINTRESOURCE(IDI_TIMEGAUGE_ICON) );
		wc.hCursor       = ::LoadCursor( 0, IDC_ARROW );
		wc.hbrBackground = 0;//static_cast<HBRUSH>(::GetStockObject( WHITE_BRUSH ));
		wc.lpszMenuName  = 0;
		wc.lpszClassName = WND_CLASS_NAME;
		wc.hIconSm       = 0;

		if( ::RegisterClassEx( &wc ) == 0 )
		{
			return FALSE;
		}
	}


	/// calculate window size
	dword windowWidth;
	dword windowHeight;
	preInitialize( windowWidth, windowHeight );


	/// create the main window
	TCHAR pTitleString[16] = TEXT("");
	::LoadString( hInstance_m, IDS_TITLE_STRING, pTitleString, sizeof(pTitleString)/sizeof(TCHAR) );
	HWND hWndMain = ::CreateWindowEx( WS_EX_TOPMOST, //WS_EX_CLIENTEDGE,
	                                  WND_CLASS_NAME, pTitleString,
	                                  WS_SYSMENU | WS_CAPTION | WS_MINIMIZEBOX | WS_VISIBLE,
	                                  CW_USEDEFAULT, CW_USEDEFAULT, windowWidth, windowHeight,
	                                  0, 0, hInstance, 0 );
	if( hWndMain == 0 )
	{
		return FALSE;
	}


	::ShowWindow( hWndMain, nCmdShow );
	::UpdateWindow( hWndMain );

	MSG msg;
	int status;

	while( status = ::GetMessage( &msg, 0, 0, 0 ),
	       (status != 0) && (status != -1) )
	{
		//if( !::TranslateAccelerator( hWndMain, hAccel, &msg ) )
		{
			::TranslateMessage( &msg );
			::DispatchMessage( &msg );
		}
	}

	return msg.wParam;
}


LRESULT CALLBACK WindowProc
(
	HWND   hWnd,
	UINT   message,
	WPARAM wParam,
	LPARAM lParam
)
{
	bool didHandleMessage = true;

	try
	{
		switch( message )
		{
			case WM_CREATE :
			{
				addMenuItems( hWnd );
				break;
			}
			case WM_LBUTTONDOWN :
			{
				onStartStop( hWnd );
				break;
			}
			case WM_RBUTTONDOWN :
			{
				onReset( hWnd );
				break;
			}
			case WM_KEYDOWN :
			{
				const bool isRepeat = ((lParam >> 30) & 1) == 1;
				switch( TCHAR(wParam) )
				{
				case VK_SPACE :
					if( !isRepeat )
					{
						onStartStop( hWnd );
					}
					break;
				case VK_DELETE :
					if( !isRepeat )
					{
						onReset( hWnd );
					}
					break;
				case TEXT('C') :
					if( !isRepeat )
					{
						onCopy( hWnd );
					}
					break;
				default :
					didHandleMessage = false;
					break;
				}
				break;
			}
			case WM_HELP :
			{
				onAbout( hWnd );
				break;
			}
			case WM_SYSCOMMAND :
			{
				switch( wParam )
				{
				case  IDM_ABOUT :
					onAbout( hWnd );
					break;
				case  IDM_COPY :
					onCopy( hWnd );
					break;
				default :
					didHandleMessage = false;
					break;
				}
				break;
			}
			case WM_TIMER :
			{
				onUpdateDisplay( hWnd );
				break;
			}
			case WM_PAINT :
			{
				onPaint( hWnd );
				break;
			}
			case WM_DESTROY :
			{
				::KillTimer( hWnd, 1 );
				::DeleteObject( hFont_m );

				::PostQuitMessage( 0 );
				break;
			}
			default :
			{
				didHandleMessage = false;
				break;
			}
		}
	}
	catch( const TCHAR* pExceptionMessage )
	{
		showErrorMessage( hWnd, 0, pExceptionMessage );
	}
	catch( DWORD errorCode )
	{
		showErrorMessage( hWnd, errorCode, 0 );
	}
	catch( ... )
	{
		showErrorMessage( hWnd, 0, 0 );
	}


	/// default handling
	LRESULT lResult = 0;
	if( !didHandleMessage )
	{
		lResult = ::DefWindowProc( hWnd, message, wParam, lParam );
	}

	return lResult;
}




/// initialisation ---------------------------------------------------------------------------------
void hxa7241_timegauge::preInitialize
(
	dword& windowWidth,
	dword& windowHeight
)
{
	/// make the font
	{
		/// read configuration from resource strings

		TCHAR pFontName[64] = TEXT("");
		::LoadString( hInstance_m, IDS_FONT_NAME, pFontName, sizeof(pFontName)/sizeof(TCHAR) );

		TCHAR pFontBold[2] = TEXT("");
		::LoadString( hInstance_m, IDS_FONT_BOLD, pFontBold, sizeof(pFontBold)/sizeof(TCHAR) );
		const bool isBold = (TEXT('0') != pFontBold[0]);

		TCHAR pFontSize[4] = TEXT("");
		const bool isOk = (0 != ::LoadString( hInstance_m, IDS_FONT_SIZE, pFontSize, sizeof(pFontSize)/sizeof(TCHAR) ));
		float size = 2.0f;
		if( isOk )
		{
			size = pFontSize[0] - TEXT('0') + (0.1f * (pFontSize[2] - TEXT('0')));
			size = size < 1.0f ? 1.0f : (size > 4.0f ? 4.0f : size);
		}

		makeFont( pFontName, isBold, size, hFont_m );
	}

	/// calculate window size using font
	calcWindowSize(	hFont_m, windowWidth, windowHeight, margin_m );
}


void hxa7241_timegauge::makeFont
(
	const TCHAR* pFontName,
	const bool   isBold,
	const float  size,
	HFONT&       hFont
)
{
	/// get titlebar height
	dword titleBarHeight = ::GetSystemMetrics( SM_CYCAPTION );
	if( titleBarHeight == 0 )
	{
		titleBarHeight = 17;
	}

	/// set font height to tbh * size
	const dword letterHeight = dword((float(titleBarHeight) * size));

	const int weight = (isBold ? FW_BOLD : FW_REGULAR);

	hFont = ::CreateFont( letterHeight, 0, 0, 0, weight,
	                      false, false, false,
	                      DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
	                      FIXED_PITCH | FF_SWISS | 0x04, pFontName );
}


void hxa7241_timegauge::calcWindowSize
(
	HFONT  hFont,
	dword& width,
	dword& height,
	dword& margin
)
{
	/// get size of zero time text
	dword textWidth;
	dword textHeight;
	{
		TCHAR pTimeString[TIME_STRING_LENGTH];
		dword timeStringLen;
		getTimeString( 0, pTimeString, timeStringLen );

		calcTextSize( pTimeString, timeStringLen, hFont, textWidth, textHeight );
	}

	/// calculate client area size, as text plus proportional margin
	const dword margin2      = (textHeight / 4);
	const dword clientWidth  = textWidth  + margin2;
	const dword clientHeight = textHeight + margin2;

	dword titleBarHeight = ::GetSystemMetrics( SM_CYCAPTION );
	if( titleBarHeight == 0 )
	{
		titleBarHeight = 17;
	}
	dword borderWidth    = ::GetSystemMetrics( SM_CXFIXEDFRAME );
	if( borderWidth == 0 )
	{
		borderWidth = 3;
	}
	dword borderHeight   = ::GetSystemMetrics( SM_CYFIXEDFRAME );
	if( borderHeight == 0 )
	{
		borderHeight = 3;
	}

	/// calculate window size, as client plus window borders and titlebar
	width  = clientWidth  + (borderWidth * 2);
	height = clientHeight + (borderHeight * 2) + titleBarHeight;
	margin = margin2 / 2;
}


void hxa7241_timegauge::calcTextSize
(
	const TCHAR* pText,
	const dword  textLen,
	HFONT        hFont,
	dword&       width,
	dword&       height
)
{
	HDC   hDc      = ::CreateIC( TEXT("DISPLAY"), 0, 0, 0 );
	HFONT dfltFont = static_cast<HFONT>( ::SelectObject( hDc, hFont ) );


	/// call the main function
	/// for numerical text content, this overestimates the height, measuring extra space above and below
	SIZE size;
	::GetTextExtentPoint32( hDc, pText, textLen, &size );

	/// subtract some descender space - since its empty for capital or numerical text
	TEXTMETRIC tm;
	::GetTextMetrics( hDc, &tm );

	width  = size.cx;
	height = size.cy - (tm.tmDescent / 2);// - (tm.tmDescent / 4);


	::SelectObject( hDc, dfltFont );
	::DeleteDC( hDc );
}




/// message handlers -------------------------------------------------------------------------------
void hxa7241_timegauge::addMenuItems
(
	HWND hWndThis
)
{
	HMENU hMenu = ::GetSystemMenu( hWndThis, FALSE );

	TCHAR pAboutMenu[16] = TEXT("");
	::LoadString( hInstance_m, IDS_ABOUT_MENU_STRING, pAboutMenu, sizeof(pAboutMenu)/sizeof(TCHAR) );
	::InsertMenu( hMenu, 0, MF_BYPOSITION | MF_STRING, IDM_ABOUT, pAboutMenu );

	TCHAR pCopyMenu[16] = TEXT("");
	::LoadString( hInstance_m, IDS_COPY_MENU_STRING, pCopyMenu, sizeof(pCopyMenu)/sizeof(TCHAR) );
	::InsertMenu( hMenu, 1, MF_BYPOSITION | MF_STRING, IDM_COPY, pCopyMenu );

//	static const dword STRING_IDS[]  = { IDS_ABOUT_MENU_STRING, IDS_COPY_MENU_STRING };
//	static const UINT  MESSAGE_IDS[] = { IDM_ABOUT, IDM_COPY };
//
//	TCHAR pString[16] = TEXT("");
//	const dword end = sizeof(STRING_IDS)/sizeof(STRING_IDS[0]);
//	for( dword i = 0;  i < end;  ++i )
//	{
//		::LoadString( hInstance_m, STRING_IDS[i], pString, sizeof(pString)/sizeof(TCHAR) );
//		::InsertMenu( hMenu, i, MF_BYPOSITION | MF_STRING, MESSAGE_IDS[i], pString );
//	}

	::InsertMenu( hMenu, 2, MF_BYPOSITION | MF_MENUBREAK, 0, 0 );
}


void hxa7241_timegauge::onStartStop
(
	HWND hWndThis
)
{
	if( !stopwatch_m.isRunning() )
	{
		const bool isOk = (::SetTimer( hWndThis, 1, TIMER_PERIOD_MILLISECS, 0 ) != 0);
		if( isOk )
		{
			stopwatch_m.start();
		}
		else
		{
			showErrorMessage( hWndThis, ::GetLastError(), TEXT("::SetTimer failed") );
		}
	}
	else
	{
		stopwatch_m.stop();

		::KillTimer( hWndThis, 1 );

		onUpdateDisplay( hWndThis );
	}

	//::MessageBeep( 0xFFFFFFFF );
	::Beep( 1000, 25 );
}


void hxa7241_timegauge::onReset
(
	HWND hWndThis
)
{
	if( !stopwatch_m.isRunning() )
	{
		stopwatch_m.reset();

		::KillTimer( hWndThis, 1 );

		onUpdateDisplay( hWndThis );

		//::MessageBeep( 0xFFFFFFFF );
		::Beep( 500, 25 );
	}
}


void hxa7241_timegauge::onAbout
(
	HWND hWndThis
)
{
	/// prevent WM_HELP causing multiple about boxs (since it is received even when child message boxs have focus)
	static bool b = false;
	if( !b )
	{
		b = true;

		TCHAR pTitle[32] = TEXT("");
		::LoadString( hInstance_m, IDS_ABOUTBOX_TITLE, pTitle, sizeof(pTitle)/sizeof(TCHAR) );
		TCHAR pMessage[272] = TEXT("");
		::LoadString( hInstance_m, IDS_ABOUTBOX_MESSAGE, pMessage, sizeof(pMessage)/sizeof(TCHAR) );

		::MessageBox( hWndThis, pMessage, pTitle, MB_ICONINFORMATION | MB_OK );

		b = false;
	}
}


void hxa7241_timegauge::onCopy
(
	HWND hWndThis
)
{
	bool isSucceeded = false;

	if( 0 != ::OpenClipboard( hWndThis ) )
	{
		HGLOBAL hText = ::GlobalAlloc( GMEM_MOVEABLE | GMEM_DDESHARE, TIME_STRING_LENGTH );
		if( hText != 0 )
		{
			TCHAR*const pTimeString = static_cast<TCHAR*>(::GlobalLock( hText ));
			if( pTimeString != 0 )
			{
				dword timeStringLen;
				getTimeString( stopwatch_m.getDuration(), pTimeString, timeStringLen );

				::GlobalUnlock( hText );

				if( timeStringLen > 0 )
				{
					::EmptyClipboard();

					isSucceeded = (::SetClipboardData( CF_TEXT, hText ) != 0);
				}
			}

			if( !isSucceeded )
			{
				::GlobalFree( hText );
			}
		}

		::CloseClipboard();
	}

	if( !isSucceeded )
	{
		showErrorMessage( hWndThis, ::GetLastError(), TEXT("copy failed") );
	}
}


void hxa7241_timegauge::onUpdateDisplay
(
	HWND hWndThis
)
{
	static dword timeSecondsLast = 0;
	const  dword timeSeconds     = stopwatch_m.getDuration() / 1000;

	static bool  isIconicLast = false;
	const bool   isIconic     = (0 != ::IsIconic( hWndThis ));

	/// only do anything if the stopwatch has changed seconds since last here
	/// or if minimized/restored state has changed since last here
	if( (timeSeconds != timeSecondsLast) | (isIconic != isIconicLast) )
	{
		/// either induce client paint, or write titlebar text
		if( !isIconic )
		{
			::InvalidateRect( hWndThis, 0, FALSE );
			::UpdateWindow( hWndThis );

			/// reset titlebar text if needed
			{
				TCHAR pTitleStringCurrent[3];
				::GetWindowText( hWndThis, pTitleStringCurrent, 2 );

				TCHAR pTitleString[16] = TEXT("");
				::LoadString( hInstance_m, IDS_TITLE_STRING, pTitleString, sizeof(pTitleString)/sizeof(TCHAR) );
				if( pTitleStringCurrent[0] != pTitleString[0] )
				{
					::SetWindowText( hWndThis, pTitleString );
				}
			}
		}
		else
		{
			/// make time string
			TCHAR pTimeString[TIME_STRING_LENGTH];
			dword timeStringLen;
			getTimeString( stopwatch_m.getDuration(), pTimeString, timeStringLen );

			::SetWindowText( hWndThis, pTimeString );
		}

		timeSecondsLast = timeSeconds;
		isIconicLast    = isIconic;
	}
}


void hxa7241_timegauge::onPaint
(
	HWND hWndThis
)
{
	PAINTSTRUCT paintStruct;
	HDC paintDc = ::BeginPaint( hWndThis, &paintStruct );


	/// make string
	TCHAR pTimeString[TIME_STRING_LENGTH];
	dword timeStringLen;
	getTimeString( stopwatch_m.getDuration(), pTimeString, timeStringLen );


	/// paint
	{
		/// do background
		if( paintStruct.fErase )
		{
			HBRUSH hBrush = ::CreateSolidBrush( BACKGROUND_COLOR );
			::FillRect( paintDc, &(paintStruct.rcPaint), hBrush );
			::DeleteObject( hBrush );
		}

		/// set font and colors
		HFONT dfltFont = static_cast<HFONT>( ::SelectObject( paintDc, hFont_m ) );
		::SetBkColor( paintDc, COLORREF( BACKGROUND_COLOR ) );
		::SetTextColor( paintDc, COLORREF( FOREGROUND_COLOR ) );

		::TextOut( paintDc, margin_m, margin_m, pTimeString, DWORD(timeStringLen) );

		::SelectObject( paintDc, dfltFont );
	}


	::EndPaint( hWndThis, &paintStruct );
}




/// general ----------------------------------------------------------------------------------------
void hxa7241_timegauge::getTimeString
(
	const dword timeMillisecs,
	TCHAR*const pTimeString,
	dword&      timeStringLen
)
{
	/// convert millisecs to hours:mins:secs
	dword hours;
	dword minutes;
	dword seconds;
	convertMillisecsToHoursMinsSecs( timeMillisecs, hours, minutes, seconds );

	/// format to string
	timeStringLen = ::wsprintf( pTimeString, TIME_FORMAT, hours, minutes, seconds );

	/// enforce some failure postconditions
	if( timeStringLen == 0 )
	{
		if( pTimeString != 0 )
		{
			pTimeString[0] = 0;
		}
	}
}


void hxa7241_timegauge::convertMillisecsToHoursMinsSecs
(
	const dword durationMillisecs,
	dword&      hours,
	dword&      minutes,
	dword&      seconds
)
{
	const dword durationSeconds = durationMillisecs / 1000;

	const dword durationMinutes = durationSeconds / 60;
	seconds = durationSeconds - (durationMinutes * 60);

	const dword durationHours = durationMinutes / 60;
	minutes = durationMinutes - (durationHours * 60);

	hours = durationHours;
}


void hxa7241_timegauge::showErrorMessage
(
	HWND        hWndThis,
	const DWORD code,
	LPCTSTR     pDetailMessage
)
{
	/// bring window to front
	::SetForegroundWindow( hWndThis );


	/// get general message
	TCHAR pErrorMessageGeneral[64] = TEXT("");
	::LoadString( hInstance_m, IDS_ERROR_MESSAGE, pErrorMessageGeneral, sizeof(pErrorMessageGeneral)/sizeof(TCHAR) );

	/// translate code into message
	static const DWORD codeMessageLen = 127;
	TCHAR pCodeMessage[ codeMessageLen + 1 ] = TEXT("");
	if( code != 0 )
	{
		::FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, 0, code, 0, pCodeMessage, codeMessageLen, 0 );
	}

	/// replace null detail message with empty string
	static const TCHAR EMPTY_STRING[] = TEXT("");
	if( pDetailMessage == 0 )
	{
		pDetailMessage = EMPTY_STRING;
	}

	/// concatenate all messages
	static const DWORD completeMessageLen = 255;
	TCHAR pCompleteMessage[ completeMessageLen + 1 ];
	{
		LPCTSTR pMessageParts[] = { pErrorMessageGeneral, pDetailMessage, pCodeMessage };

		::FormatMessage( FORMAT_MESSAGE_FROM_STRING | FORMAT_MESSAGE_ARGUMENT_ARRAY,
		                 TEXT("%1\n\n%2\n%3"), 0, 0, pCompleteMessage, completeMessageLen, const_cast<TCHAR**>(pMessageParts) );
	}


	/// display the composite message
	{
		TCHAR pTitleString[16] = TEXT("");
		::LoadString( hInstance_m, IDS_TITLE_STRING, pTitleString, sizeof(pTitleString)/sizeof(TCHAR) );
		::MessageBox( hWndThis, pCompleteMessage, pTitleString, MB_ICONEXCLAMATION | MB_OK );
	}
}
