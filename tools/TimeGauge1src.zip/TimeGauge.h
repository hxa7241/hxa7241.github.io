/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef TimeGauge_h
#define TimeGauge_h


#include "Primitives.h"




/// windows stuff
int     WINAPI   WinMain( HINSTANCE hInst,  HINSTANCE hPrevInst,  char* cmdParam,  int  cmdShow );
LRESULT CALLBACK WindowProc( HWND hWnd,  UINT Message,  WPARAM wParam,  LPARAM lParam );


namespace hxa7241_timegauge
{
	using namespace hxa7241;


/// initialisation
void preInitialize( dword& windowWidth, dword& windowHeight );
void makeFont( const TCHAR* pFontName, bool isBold, float size, HFONT& font );
void calcWindowSize( HFONT hFont, dword& width, dword& height, dword& margin );
void calcTextSize( const TCHAR* pText, dword textLen, HFONT hFont, dword& width, dword& height );


/// message handlers
void addMenuItems( HWND );
void onStartStop( HWND );
void onReset( HWND );
void onAbout( HWND );
void onCopy( HWND );
void onUpdateDisplay( HWND );
void onPaint( HWND );


/// general
void getTimeString( const dword timeMillisecs, TCHAR*const pTimeString, dword& timeStringLen );
void convertMillisecsToHoursMinsSecs( dword durationMillisecs, dword& hours, dword& minutes, dword& seconds );
void showErrorMessage( HWND, DWORD Code, LPCTSTR Message );


} //namespace




#endif//TimeGauge_h
