/*--------------------------------------------------------------------

   TimeGauge v1.1
   Copyright (c) 2004, Harrison Ainsworth. Some rights reserved.

   http://www.hxa7241.org/

--------------------------------------------------------------------*/


#ifndef resource_h
#define resource_h




#define IDI_TIMEGAUGE_ICON      200

#define IDS_TITLE_STRING       2001
#define IDS_ABOUT_MENU_STRING  2002
#define IDS_COPY_MENU_STRING   2003
#define IDS_ABOUTBOX_TITLE     2004
#define IDS_ABOUTBOX_MESSAGE   2005
#define IDS_ERROR_MESSAGE      2006
#define IDS_FONT_NAME          2007
#define IDS_FONT_BOLD          2008
#define IDS_FONT_SIZE          2009





#endif//resource_h
